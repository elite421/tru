"use client"

import { useEffect, useState } from "react"

export default function DebugPage() {
  const [debugInfo, setDebugInfo] = useState<any>({})

  useEffect(() => {
    setDebugInfo({
      mode: 'Demo Mode - Authentication Disabled',
      defaultUserId: '1',
      message: 'All pages now use demo user ID for testing',
      timestamp: new Date().toISOString()
    })
  }, [])

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold mb-6">Authentication Debug Info</h1>
      
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mb-6">
        <h2 className="text-xl font-bold mb-4">localStorage</h2>
        <pre className="bg-gray-100 dark:bg-gray-900 p-4 rounded">
          {JSON.stringify(debugInfo.localStorage, null, 2)}
        </pre>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mb-6">
        <h2 className="text-xl font-bold mb-4">Cookies Status</h2>
        <pre className="bg-gray-100 dark:bg-gray-900 p-4 rounded">
          {JSON.stringify(debugInfo.hasCookies, null, 2)}
        </pre>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6">
        <h2 className="text-xl font-bold mb-4">Raw Cookies</h2>
        <pre className="bg-gray-100 dark:bg-gray-900 p-4 rounded whitespace-pre-wrap break-all">
          {debugInfo.cookies}
        </pre>
      </div>

      <div className="mt-6 p-4 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
        <h3 className="font-bold mb-2">🔍 What to check:</h3>
        <ul className="list-disc ml-6 space-y-1">
          <li>Both localStorage and cookies should have userToken</li>
          <li>Both should have userId</li>
          <li>If cookies are missing, login again</li>
          <li>If localStorage is missing, login again</li>
        </ul>
      </div>
    </div>
  )
}
