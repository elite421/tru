"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { 
  ArrowLeft, 
  Smartphone, 
  Briefcase, 
  TrendingUp, 
  Shield, 
  Building2,
  Search,
  ChevronRight,
  Sparkles
} from "lucide-react"
import { Button } from "@/component/ui/button"

type ServiceCategory = {
  id: string
  title: string
  description: string
  icon: any
  color: string
  services: Service[]
}

type Service = {
  id: string
  title: string
  description: string
  price: number
  endpoint: string
  fields: {
    name: string
    label: string
    type: string
    placeholder: string
    required: boolean
  }[]
}

export default function AdvancedServicesPage() {
  const router = useRouter()
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const [selectedService, setSelectedService] = useState<Service | null>(null)
  const [formData, setFormData] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<any>(null)
  const [viewMode, setViewMode] = useState<"normal" | "json">("normal")
  const [user, setUser] = useState<any>(null)
  const [walletBalance, setWalletBalance] = useState<number>(0)

  // Check authentication
  useEffect(() => {
    const userData = sessionStorage.getItem("user")
    if (!userData) {
      router.push("/login")
      return
    }
    
    try {
      const parsedUser = JSON.parse(userData)
      setUser(parsedUser)
    } catch (e) {
      router.push("/login")
    }
  }, [router])

  // Fetch wallet balance
  useEffect(() => {
    if (!user) return
    
    const fetchWalletBalance = async () => {
      try {
        const res = await fetch(`/api/wallet/balance?userId=${user.id}`)
        const data = await res.json()
        if (data.success) {
          setWalletBalance(data.balance)
        }
      } catch (error) {
        console.error("Error fetching wallet balance:", error)
      }
    }
    
    fetchWalletBalance()
  }, [user])

  const categories: ServiceCategory[] = [
    {
      id: "mobile-intelligence",
      title: "Mobile Intelligence",
      description: "Extract comprehensive data from mobile numbers",
      icon: <Smartphone className="w-8 h-8" />,
      color: "from-blue-500 to-cyan-500",
      services: [
        {
          id: "mobile-to-name",
          title: "Mobile to Name",
          description: "Get name associated with a mobile number",
          price: 6,
          endpoint: "/api/mobile-intelligence/mobile-to-name",
          fields: [
            { name: "mobileNumber", label: "Mobile Number", type: "tel", placeholder: "Enter 10-digit mobile", required: true }
          ]
        },
        {
          id: "mobile-to-pan",
          title: "Mobile to PAN",
          description: "Get PAN linked to a mobile number",
          price: 8,
          endpoint: "/api/mobile-intelligence/mobile-to-pan",
          fields: [
            { name: "mobileNumber", label: "Mobile Number", type: "tel", placeholder: "Enter 10-digit mobile", required: true }
          ]
        },
        {
          id: "mobile-to-dl",
          title: "Mobile to DL",
          description: "Get driving license from mobile number",
          price: 8,
          endpoint: "/api/mobile-intelligence/mobile-to-dl",
          fields: [
            { name: "mobileNumber", label: "Mobile Number", type: "tel", placeholder: "Enter 10-digit mobile", required: true }
          ]
        },
        {
          id: "mobile-to-uan",
          title: "Mobile to UAN",
          description: "Get UAN from mobile number",
          price: 7,
          endpoint: "/api/mobile-intelligence/mobile-to-uan",
          fields: [
            { name: "mobileNumber", label: "Mobile Number", type: "tel", placeholder: "Enter 10-digit mobile", required: true }
          ]
        },
        {
          id: "mobile-digital-age",
          title: "Mobile Digital Age",
          description: "Get digital age of a mobile number",
          price: 6,
          endpoint: "/api/mobile-intelligence/mobile-digital-age",
          fields: [
            { name: "mobileNumber", label: "Mobile Number", type: "tel", placeholder: "Enter 10-digit mobile", required: true }
          ]
        },
        {
          id: "mobile-network",
          title: "Mobile Network Details",
          description: "Get network operator and circle details",
          price: 4,
          endpoint: "/api/mobile-intelligence/mobile-network",
          fields: [
            { name: "mobileNumber", label: "Mobile Number", type: "tel", placeholder: "Enter 10-digit mobile", required: true }
          ]
        },
        {
          id: "mobile-to-upi",
          title: "Mobile to Multiple UPI",
          description: "Get all UPI IDs linked to mobile",
          price: 6,
          endpoint: "/api/mobile-intelligence/mobile-to-upi",
          fields: [
            { name: "mobileNumber", label: "Mobile Number", type: "tel", placeholder: "Enter 10-digit mobile", required: true }
          ]
        }
      ]
    },
    {
      id: "epfo",
      title: "EPFO Services",
      description: "Employment provident fund verification",
      icon: <Briefcase className="w-8 h-8" />,
      color: "from-green-500 to-emerald-500",
      services: [
        {
          id: "aadhaar-to-uan",
          title: "Aadhaar to UAN",
          description: "Get UAN from Aadhaar number",
          price: 7,
          endpoint: "/api/epfo/aadhaar-to-uan",
          fields: [
            { name: "aadhaarNumber", label: "Aadhaar Number", type: "text", placeholder: "Enter 12-digit Aadhaar", required: true }
          ]
        },
        {
          id: "pan-to-uan",
          title: "PAN to UAN",
          description: "Get UAN from PAN number",
          price: 7,
          endpoint: "/api/epfo/pan-to-uan",
          fields: [
            { name: "panNumber", label: "PAN Number", type: "text", placeholder: "Enter PAN", required: true }
          ]
        },
        {
          id: "uan-employment",
          title: "UAN to Employment History",
          description: "Get employment history from UAN",
          price: 9,
          endpoint: "/api/epfo/uan-employment",
          fields: [
            { name: "uanNumber", label: "UAN Number", type: "text", placeholder: "Enter 12-digit UAN", required: true }
          ]
        }
      ]
    },
    {
      id: "business",
      title: "Business Services",
      description: "Corporate and business verification",
      icon: <Building2 className="w-8 h-8" />,
      color: "from-purple-500 to-pink-500",
      services: [
        {
          id: "cin",
          title: "CIN Verification",
          description: "Verify Corporate Identification Number",
          price: 8,
          endpoint: "/api/verification/cin",
          fields: [
            { name: "cinNumber", label: "CIN Number", type: "text", placeholder: "Enter CIN", required: true }
          ]
        },
        {
          id: "din",
          title: "DIN Verification",
          description: "Verify Director Identification Number",
          price: 8,
          endpoint: "/api/verification/din",
          fields: [
            { name: "dinNumber", label: "DIN Number", type: "text", placeholder: "Enter DIN", required: true }
          ]
        },
        {
          id: "gstin-by-pan",
          title: "Search GSTIN by PAN",
          description: "Find all GSTINs linked to a PAN",
          price: 6,
          endpoint: "/api/verification/gstin-by-pan",
          fields: [
            { name: "panNumber", label: "PAN Number", type: "text", placeholder: "Enter PAN", required: true }
          ]
        },
        {
          id: "track-gstr",
          title: "Track GSTR",
          description: "Track GST return filing status",
          price: 8,
          endpoint: "/api/verification/track-gstr",
          fields: [
            { name: "gstinNumber", label: "GSTIN", type: "text", placeholder: "Enter GSTIN", required: true },
            { name: "financialYear", label: "Financial Year", type: "text", placeholder: "e.g., 2023-24", required: true }
          ]
        }
      ]
    },
    {
      id: "tax",
      title: "Tax Services",
      description: "Tax and compliance verification",
      icon: <TrendingUp className="w-8 h-8" />,
      color: "from-orange-500 to-red-500",
      services: [
        {
          id: "tan",
          title: "TAN Verification",
          description: "Verify Tax Deduction Account Number",
          price: 5,
          endpoint: "/api/verification/tan",
          fields: [
            { name: "tanNumber", label: "TAN Number", type: "text", placeholder: "Enter TAN", required: true }
          ]
        },
        {
          id: "tds-compliance",
          title: "TDS Compliance Check",
          description: "Check TDS compliance status (Section 206AB)",
          price: 7,
          endpoint: "/api/verification/tds-compliance",
          fields: [
            { name: "panNumber", label: "PAN Number", type: "text", placeholder: "Enter PAN", required: true }
          ]
        }
      ]
    },
    {
      id: "financial",
      title: "Financial Services",
      description: "Credit and financial verification",
      icon: <Shield className="w-8 h-8" />,
      color: "from-indigo-500 to-blue-500",
      services: [
        {
          id: "credit-report",
          title: "Credit Report",
          description: "Get comprehensive credit report and score",
          price: 50,
          endpoint: "/api/financial/credit-report",
          fields: [
            { name: "fullName", label: "Full Name", type: "text", placeholder: "Enter full name", required: true },
            { name: "panNumber", label: "PAN Number", type: "text", placeholder: "Enter PAN", required: true },
            { name: "mobileNumber", label: "Mobile Number", type: "tel", placeholder: "Enter mobile", required: true }
          ]
        }
      ]
    },
    {
      id: "biometric",
      title: "Biometric Services",
      description: "Face matching and liveness detection",
      icon: <Search className="w-8 h-8" />,
      color: "from-pink-500 to-rose-500",
      services: [
        {
          id: "face-match",
          title: "Face Match",
          description: "Compare two face images for matching",
          price: 15,
          endpoint: "/api/biometric/face-match",
          fields: [
            { name: "image1Url", label: "First Image URL", type: "text", placeholder: "Enter first image URL", required: true },
            { name: "image2Url", label: "Second Image URL", type: "text", placeholder: "Enter second image URL", required: true }
          ]
        },
        {
          id: "liveness-check",
          title: "Liveness Check",
          description: "Check if image is of a live person",
          price: 12,
          endpoint: "/api/biometric/liveness-check",
          fields: [
            { name: "imageUrl", label: "Image URL", type: "text", placeholder: "Enter image URL", required: true }
          ]
        }
      ]
    },
    {
      id: "msme",
      title: "MSME Services",
      description: "Udyam and Udyog verification",
      icon: <Sparkles className="w-8 h-8" />,
      color: "from-yellow-500 to-orange-500",
      services: [
        {
          id: "udyam",
          title: "Udyam Verification",
          description: "Get Udyam Aadhaar (MSME) details",
          price: 10,
          endpoint: "/api/verification/udyam",
          fields: [
            { name: "udyamNumber", label: "Udyam Number", type: "text", placeholder: "Enter Udyam registration number", required: true }
          ]
        },
        {
          id: "udyog",
          title: "Udyog Verification",
          description: "Get Udyog Aadhaar (MSME) details",
          price: 10,
          endpoint: "/api/verification/udyog",
          fields: [
            { name: "udyogNumber", label: "Udyog Number", type: "text", placeholder: "Enter Udyog Aadhaar number", required: true }
          ]
        }
      ]
    }
  ]

  const handleServiceSelect = (service: Service) => {
    setSelectedService(service)
    setFormData({})
    setResult(null)
  }

  const handleInputChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async () => {
    if (!selectedService) return

    const missingFields = selectedService.fields.filter(f => f.required && !formData[f.name])
    if (missingFields.length > 0) {
      alert(`Please fill: ${missingFields.map(f => f.label).join(", ")}`)
      return
    }

    setLoading(true)
    setResult(null)

    try {
      const response = await fetch(selectedService.endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...formData, userId: user.id })
      })

      const data = await response.json()

      if (data.success) {
        setResult(data.data)
      } else {
        alert(data.error || 'Verification failed')
      }
    } catch (error: any) {
      alert(error.message || 'Verification failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => router.push("/")}
            className="flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white mb-4"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Dashboard
          </button>

          <div className="flex items-center gap-3 mb-2">
            <Sparkles className="w-10 h-10 text-indigo-600 dark:text-indigo-400" />
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white">
              Advanced Services
            </h1>
          </div>
          <p className="text-gray-600 dark:text-gray-400">
            Premium verification and intelligence services powered by DeepVue
          </p>
        </div>

        {/* Category Selection */}
        {!selectedCategory && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setSelectedCategory(category.id)}
                className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 text-left group"
              >
                <div className={`w-16 h-16 bg-gradient-to-br ${category.color} rounded-2xl flex items-center justify-center text-white mb-6 group-hover:scale-110 transition-transform`}>
                  {category.icon}
                </div>
                <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
                  {category.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  {category.description}
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-semibold text-indigo-600 dark:text-indigo-400">
                    {category.services.length} Service{category.services.length > 1 ? 's' : ''}
                  </span>
                  <ChevronRight className="w-5 h-5 text-gray-400 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors" />
                </div>
              </button>
            ))}
          </div>
        )}

        {/* Service Selection */}
        {selectedCategory && !selectedService && (
          <div>
            <button
              onClick={() => setSelectedCategory(null)}
              className="flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white mb-6"
            >
              <ArrowLeft className="w-5 h-5" />
              Back to Categories
            </button>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {categories.find(c => c.id === selectedCategory)?.services.map((service) => (
                <button
                  key={service.id}
                  onClick={() => handleServiceSelect(service)}
                  className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 text-left group border-2 border-transparent hover:border-indigo-300 dark:hover:border-indigo-600"
                >
                  <div className="flex items-start justify-between mb-4">
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                      {service.title}
                    </h3>
                    <span className="bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-400 px-3 py-1 rounded-full text-sm font-bold">
                      ₹{service.price}
                    </span>
                  </div>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    {service.description}
                  </p>
                  <div className="flex items-center justify-end">
                    <ChevronRight className="w-5 h-5 text-indigo-600 dark:text-indigo-400 group-hover:translate-x-1 transition-transform" />
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Service Form */}
        {selectedService && (
          <div>
            <button
              onClick={() => setSelectedService(null)}
              className="flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white mb-6"
            >
              <ArrowLeft className="w-5 h-5" />
              Back to Services
            </button>

            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 mb-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
                    {selectedService.title}
                  </h2>
                  <p className="text-gray-600 dark:text-gray-400">
                    {selectedService.description}
                  </p>
                </div>
                <div className="flex gap-4">
                  {/* Wallet Balance Card */}
                  <div className="bg-gradient-to-br from-green-100 to-emerald-100 dark:from-green-900/30 dark:to-emerald-900/30 rounded-xl p-4 border-2 border-green-200 dark:border-green-800">
                    <p className="text-xs font-semibold text-green-700 dark:text-green-400 uppercase mb-1">Wallet Balance</p>
                    <p className="text-2xl font-bold text-green-900 dark:text-green-300">
                      ₹{walletBalance.toFixed(2)}
                    </p>
                    <a 
                      href="/wallet" 
                      className="text-xs text-green-700 dark:text-green-400 hover:underline mt-1 inline-block"
                    >
                      Recharge →
                    </a>
                  </div>
                  
                  {/* Price Card */}
                  <div className="bg-indigo-100 dark:bg-indigo-900/30 rounded-xl p-4">
                    <p className="text-xs font-semibold text-indigo-700 dark:text-indigo-400 uppercase mb-1">Price</p>
                    <p className="text-2xl font-bold text-indigo-900 dark:text-indigo-300">
                      ₹{selectedService.price}
                    </p>
                  </div>
                </div>
              </div>

              {/* Insufficient Balance Warning */}
              {walletBalance < selectedService.price && (
                <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border-2 border-red-200 dark:border-red-800 rounded-xl">
                  <div className="flex items-start gap-3">
                    <svg className="w-6 h-6 text-red-600 dark:text-red-400 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    <div>
                      <p className="font-bold text-red-900 dark:text-red-300 mb-1">Insufficient Wallet Balance</p>
                      <p className="text-sm text-red-700 dark:text-red-400">
                        You need ₹{selectedService.price.toFixed(2)} but have ₹{walletBalance.toFixed(2)}. 
                        <a href="/wallet" className="font-semibold underline ml-1 hover:text-red-900 dark:hover:text-red-300">
                          Recharge your wallet
                        </a>
                      </p>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-4 mb-6">
                {selectedService.fields.map((field) => (
                  <div key={field.name}>
                    <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                      {field.label} {field.required && <span className="text-red-500">*</span>}
                    </label>
                    <input
                      type={field.type}
                      placeholder={field.placeholder}
                      value={formData[field.name] || ""}
                      onChange={(e) => handleInputChange(field.name, e.target.value.toUpperCase())}
                      className="w-full px-4 py-3 border-2 border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white outline-none uppercase"
                    />
                  </div>
                ))}
              </div>

              <Button
                onClick={handleSubmit}
                disabled={loading || walletBalance < selectedService.price}
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:opacity-90 py-4 text-lg font-semibold rounded-xl disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? "Processing..." : walletBalance < selectedService.price 
                  ? `Insufficient Balance - Need ₹${selectedService.price.toFixed(2)}` 
                  : `Verify Now - ₹${selectedService.price}`}
              </Button>
            </div>

            {/* Results */}
            {result && (
              <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 border border-gray-100 dark:border-gray-700">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                    Verification Result
                  </h3>
                  <div className="flex items-center gap-2 bg-gray-100 dark:bg-gray-700 rounded-xl p-1">
                    <button
                      onClick={() => setViewMode("normal")}
                      className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                        viewMode === "normal"
                          ? "bg-white dark:bg-gray-600 text-indigo-600 dark:text-indigo-400 shadow-md"
                          : "text-gray-600 dark:text-gray-300"
                      }`}
                    >
                      Normal View
                    </button>
                    <button
                      onClick={() => setViewMode("json")}
                      className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                        viewMode === "json"
                          ? "bg-white dark:bg-gray-600 text-indigo-600 dark:text-indigo-400 shadow-md"
                          : "text-gray-600 dark:text-gray-300"
                      }`}
                    >
                      JSON View
                    </button>
                  </div>
                </div>

                {viewMode === "normal" && (
                  <div className="bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-800 rounded-xl p-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {Object.entries(result).map(([key, value]) => (
                        <div key={key} className="bg-white dark:bg-gray-600 rounded-lg p-4 shadow-sm">
                          <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1">
                            {key.replace(/_/g, ' ')}
                          </p>
                          <p className="text-base font-bold text-gray-900 dark:text-white break-words">
                            {typeof value === 'object' ? JSON.stringify(value, null, 2) : String(value)}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {viewMode === "json" && (
                  <div className="bg-gray-900 rounded-xl p-6">
                    <pre className="text-sm text-green-400 overflow-auto max-h-96 whitespace-pre-wrap font-mono">
                      {JSON.stringify(result, null, 2)}
                    </pre>
                  </div>
                )}

                <Button
                  onClick={() => {
                    navigator.clipboard.writeText(JSON.stringify(result, null, 2))
                    alert("JSON copied to clipboard")
                  }}
                  className="w-full mt-6 bg-gray-600 text-white hover:bg-gray-700"
                >
                  Copy JSON
                </Button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
