"use client"

import { FileText, AlertCircle, Scale, CreditCard, Ban, RefreshCw, ShieldCheck, Gavel } from "lucide-react"

export default function TermsOfServicePage() {
  const sections = [
    {
      icon: <FileText className="w-6 h-6" />,
      title: "Acceptance of Terms",
      content: [
        {
          text: "By accessing and using TruVerify's verification services, you accept and agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our services."
        },
        {
          text: "These terms apply to all users, including individuals, businesses, and organizations that access or use our platform."
        },
        {
          text: "We reserve the right to modify these terms at any time. Continued use of our services after changes constitutes acceptance of the modified terms."
        }
      ]
    },
    {
      icon: <ShieldCheck className="w-6 h-6" />,
      title: "Service Description",
      content: [
        {
          subtitle: "Verification Services",
          text: "TruVerify provides identity and document verification services through APIs and web interfaces. Our services include but are not limited to email, phone, Aadhar, PAN, passport, driving license, GST, bank account, and voter ID verification."
        },
        {
          subtitle: "Service Availability",
          text: "We strive to maintain 99.9% uptime but do not guarantee uninterrupted service. We may perform scheduled maintenance with advance notice."
        },
        {
          subtitle: "Service Accuracy",
          text: "While we maintain high accuracy standards, verification results depend on source data quality. We do not guarantee 100% accuracy for all verifications."
        }
      ]
    },
    {
      icon: <CreditCard className="w-6 h-6" />,
      title: "Account Registration & Usage",
      content: [
        {
          subtitle: "Account Creation",
          text: "You must create an account to use our services. You agree to provide accurate, current, and complete information during registration."
        },
        {
          subtitle: "Account Security",
          text: "You are responsible for maintaining the confidentiality of your account credentials. Notify us immediately of any unauthorized access."
        },
        {
          subtitle: "API Keys",
          text: "API keys are personal to your account. Do not share API keys publicly or with unauthorized parties. You are responsible for all activities under your API keys."
        },
        {
          subtitle: "Authorized Use",
          text: "You must use our services only for lawful purposes and in compliance with all applicable laws and regulations."
        }
      ]
    },
    {
      icon: <CreditCard className="w-6 h-6" />,
      title: "Pricing & Payment",
      content: [
        {
          subtitle: "Pay-As-You-Go Model",
          text: "Our services operate on a pay-per-verification basis. Pricing is displayed on our pricing page and may be updated periodically."
        },
        {
          subtitle: "Billing",
          text: "You will be charged for successful verifications only. Failed verifications due to invalid data or service errors are not charged."
        },
        {
          subtitle: "Payment Terms",
          text: "Payments are processed through secure payment gateways. All prices are in Indian Rupees (INR) unless otherwise specified."
        },
        {
          subtitle: "Refunds",
          text: "Refunds are provided for erroneous charges or service failures. Refund requests must be submitted within 30 days of the transaction."
        }
      ]
    },
    {
      icon: <Ban className="w-6 h-6" />,
      title: "Prohibited Activities",
      content: [
        {
          text: "You agree not to use our services for any illegal, fraudulent, or malicious activities."
        },
        {
          text: "Do not attempt to reverse engineer, decompile, or extract source code from our platform."
        },
        {
          text: "Do not circumvent rate limits, security measures, or authentication mechanisms."
        },
        {
          text: "Do not use automated systems to overload our infrastructure or perform denial-of-service attacks."
        },
        {
          text: "Do not resell or redistribute our services without written authorization."
        },
        {
          text: "Do not violate privacy rights or harvest personal information without consent."
        }
      ]
    },
    {
      icon: <Scale className="w-6 h-6" />,
      title: "Intellectual Property",
      content: [
        {
          subtitle: "Our Rights",
          text: "All content, features, and functionality of TruVerify, including but not limited to software, text, graphics, logos, and APIs, are owned by us and protected by intellectual property laws."
        },
        {
          subtitle: "License Grant",
          text: "We grant you a limited, non-exclusive, non-transferable license to access and use our services for your business purposes in accordance with these terms."
        },
        {
          subtitle: "Your Data",
          text: "You retain all rights to the data you submit for verification. By using our services, you grant us the right to process this data to provide verification services."
        }
      ]
    },
    {
      icon: <AlertCircle className="w-6 h-6" />,
      title: "Limitation of Liability",
      content: [
        {
          subtitle: "Service Limitations",
          text: "Our services are provided 'as is' without warranties of any kind. We do not warrant that our services will be error-free or uninterrupted."
        },
        {
          subtitle: "Liability Cap",
          text: "Our total liability for any claims arising from your use of our services shall not exceed the amount you paid us in the past 12 months."
        },
        {
          subtitle: "Consequential Damages",
          text: "We are not liable for any indirect, incidental, consequential, or punitive damages arising from your use of our services."
        },
        {
          subtitle: "Third-Party Services",
          text: "We are not responsible for errors or failures caused by third-party services or data sources."
        }
      ]
    },
    {
      icon: <RefreshCw className="w-6 h-6" />,
      title: "Service Modifications & Termination",
      content: [
        {
          subtitle: "Service Changes",
          text: "We reserve the right to modify, suspend, or discontinue any part of our services at any time with reasonable notice."
        },
        {
          subtitle: "Account Termination",
          text: "We may suspend or terminate your account for violations of these terms, illegal activities, or non-payment."
        },
        {
          subtitle: "Your Right to Terminate",
          text: "You may terminate your account at any time through your dashboard settings. Outstanding balances must be settled before closure."
        }
      ]
    },
    {
      icon: <Gavel className="w-6 h-6" />,
      title: "Governing Law & Disputes",
      content: [
        {
          subtitle: "Jurisdiction",
          text: "These terms are governed by the laws of India. Any disputes shall be subject to the exclusive jurisdiction of courts in Noida, Uttar Pradesh, India."
        },
        {
          subtitle: "Dispute Resolution",
          text: "We encourage resolving disputes amicably through good-faith negotiations before pursuing legal action."
        },
        {
          subtitle: "Arbitration",
          text: "Any disputes that cannot be resolved through negotiation may be submitted to binding arbitration in accordance with Indian Arbitration and Conciliation Act."
        }
      ]
    }
  ]

  const importantPoints = [
    "You must be 18 years or older to use our services",
    "You are responsible for compliance with local laws in your jurisdiction",
    "We may update these terms with 30 days notice for material changes",
    "Continued use after changes constitutes acceptance",
    "We reserve the right to refuse service to anyone at our discretion"
  ]

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-12 text-center">
          <div className="inline-block bg-purple-100 dark:bg-purple-900/30 rounded-full px-6 py-2 mb-6">
            <span className="text-purple-600 dark:text-purple-400 font-semibold">Effective Date: November 5, 2025</span>
          </div>
          <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-4">
            Terms of Service
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Please read these terms carefully before using TruVerify's verification services.
          </p>
        </div>

        {/* Introduction */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Welcome to TruVerify</h2>
          <p className="text-gray-600 dark:text-gray-400 leading-relaxed mb-4">
            These Terms of Service ("Terms") constitute a legally binding agreement between you and TruVerify 
            regarding your access to and use of our verification platform, APIs, and related services.
          </p>
          <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
            Please read these Terms carefully. By creating an account or using our services, you acknowledge 
            that you have read, understood, and agree to be bound by these Terms.
          </p>
        </div>

        {/* Detailed Sections */}
        {sections.map((section, index) => (
          <div key={index} className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 mb-8">
            <div className="flex items-start gap-4 mb-6">
              <div className="bg-purple-100 dark:bg-purple-900/30 rounded-xl p-3 text-purple-600 dark:text-purple-400">
                {section.icon}
              </div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white">
                {section.title}
              </h2>
            </div>
            
            <div className="space-y-6">
              {section.content.map((item, idx) => (
                <div key={idx}>
                  {'subtitle' in item && item.subtitle && (
                    <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                      {item.subtitle}
                    </h3>
                  )}
                  <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                    {item.text}
                  </p>
                </div>
              ))}
            </div>
          </div>
        ))}

        {/* Important Points */}
        <div className="bg-amber-50 dark:bg-amber-900/20 border-l-4 border-amber-500 rounded-xl p-8 mb-8">
          <h3 className="text-2xl font-bold text-amber-900 dark:text-amber-200 mb-4 flex items-center gap-2">
            <AlertCircle className="w-6 h-6" />
            Important Points to Remember
          </h3>
          <ul className="space-y-3">
            {importantPoints.map((point, index) => (
              <li key={index} className="flex items-start gap-3 text-amber-800 dark:text-amber-300">
                <span className="text-amber-600 dark:text-amber-400 mt-1">•</span>
                <span>{point}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Contact Section */}
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 rounded-2xl shadow-xl p-8 text-white">
          <h2 className="text-3xl font-bold mb-4">Questions About Terms?</h2>
          <p className="text-xl text-white/90 mb-6">
            If you have any questions or concerns about our Terms of Service, please contact our legal team.
          </p>
          <div className="space-y-2">
            <p className="flex items-center gap-2">
              <span className="font-semibold">Email:</span> legal@truverify.com
            </p>
            <p className="flex items-center gap-2">
              <span className="font-semibold">Phone:</span> +91 8279439828
            </p>
            <p className="flex items-center gap-2">
              <span className="font-semibold">Address:</span> Second Floor, Mind Mill Corporate Tower, Sector 16A, Noida, India
            </p>
          </div>
        </div>

        {/* Acceptance Statement */}
        <div className="mt-8 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-xl p-6 text-center">
          <p className="text-green-900 dark:text-green-200 font-semibold">
            By using TruVerify services, you acknowledge that you have read and understood these Terms of Service 
            and agree to be bound by them.
          </p>
        </div>
      </div>
    </div>
  )
}
