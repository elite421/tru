"use client"

import { useState, useEffect } from "react"
import { HelpCircle, Ticket, MessageCircle, Send, Clock, CheckCircle, AlertCircle, User } from "lucide-react"
import { Button } from "@/component/ui/button"
import { useRouter } from "next/navigation"

export default function HelpSupportPage() {
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<"tickets" | "chat">("tickets")
  const [ticketForm, setTicketForm] = useState({
    subject: "",
    category: "technical",
    priority: "medium",
    description: ""
  })
  const [userTickets, setUserTickets] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [submitSuccess, setSubmitSuccess] = useState(false)
  const [chatMessages, setChatMessages] = useState<any[]>([
    { from: "bot", message: "Hello! How can I help you today?", time: new Date() }
  ])
  const [chatInput, setChatInput] = useState("")

  useEffect(() => {
    fetchUserTickets()
  }, [])

  const fetchUserTickets = async () => {
    try {
      // Demo mode - use default user ID
      const userId = "1"
      const response = await fetch(`/api/tickets?userId=${userId}`)
      if (response.ok) {
        const data = await response.json()
        setUserTickets(data.tickets || [])
      }
    } catch (error) {
      console.error("Error fetching tickets:", error)
    }
  }

  const handleTicketSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    
    try {
      // Demo mode - use default values
      const userId = "1"
      const userEmail = "demo@truverify.com"
      
      const response = await fetch("/api/tickets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId,
          userEmail,
          ...ticketForm
        })
      })
      
      if (response.ok) {
        setSubmitSuccess(true)
        setTicketForm({ subject: "", category: "technical", priority: "medium", description: "" })
        fetchUserTickets()
        setTimeout(() => setSubmitSuccess(false), 5000)
      }
    } catch (error) {
      console.error("Error submitting ticket:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleChatSend = () => {
    if (chatInput.trim()) {
      setChatMessages([...chatMessages, { from: "user", message: chatInput, time: new Date() }])
      setChatInput("")
      
      setTimeout(() => {
        setChatMessages(prev => [...prev, { 
          from: "bot", 
          message: "Thank you for your message. Our support team will respond shortly. For immediate assistance, please check our FAQ section at /help or submit a support ticket.",
          time: new Date()
        }])
      }, 1000)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "open": return "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400"
      case "in-progress": return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400"
      case "closed": return "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400"
      default: return "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400"
    }
  }

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8 text-center animate-fade-in">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
            Help & Support
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Submit support tickets or chat with our team
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="flex justify-center gap-4 mb-8 animate-slide-in-down">
          <button
            onClick={() => setActiveTab("tickets")}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all transform hover:scale-105 ${
              activeTab === "tickets"
                ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg"
                : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:shadow-md"
            }`}
          >
            <Ticket size={20} />
            Support Tickets
          </button>
          <button
            onClick={() => setActiveTab("chat")}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-semibold transition-all transform hover:scale-105 ${
              activeTab === "chat"
                ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg"
                : "bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:shadow-md"
            }`}
          >
            <MessageCircle size={20} />
            Live Chat
          </button>
        </div>

        {/* Support Tickets Tab */}
        {activeTab === "tickets" && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Create Ticket Form */}
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 hover-lift animate-slide-in-left">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
                <Ticket className="text-blue-600" />
                Create New Ticket
              </h2>

              {submitSuccess && (
                <div className="mb-6 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-xl p-4 animate-bounce-in">
                  <p className="text-green-800 dark:text-green-200 font-semibold flex items-center gap-2">
                    <CheckCircle size={20} />
                    Ticket submitted successfully!
                  </p>
                </div>
              )}

              <form onSubmit={handleTicketSubmit} className="space-y-5">
                <div>
                  <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                    Subject *
                  </label>
                  <input
                    type="text"
                    value={ticketForm.subject}
                    onChange={(e) => setTicketForm({ ...ticketForm, subject: e.target.value })}
                    required
                    className="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    placeholder="Brief description of your issue"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                      Category *
                    </label>
                    <select
                      value={ticketForm.category}
                      onChange={(e) => setTicketForm({ ...ticketForm, category: e.target.value })}
                      className="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    >
                      <option value="technical">Technical Issue</option>
                      <option value="billing">Billing</option>
                      <option value="feature">Feature Request</option>
                      <option value="other">Other</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                      Priority *
                    </label>
                    <select
                      value={ticketForm.priority}
                      onChange={(e) => setTicketForm({ ...ticketForm, priority: e.target.value })}
                      className="w-full px-4 py-2.5 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
                    >
                      <option value="low">Low</option>
                      <option value="medium">Medium</option>
                      <option value="high">High</option>
                      <option value="urgent">Urgent</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                    Description *
                  </label>
                  <textarea
                    value={ticketForm.description}
                    onChange={(e) => setTicketForm({ ...ticketForm, description: e.target.value })}
                    required
                    rows={6}
                    className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white resize-none"
                    placeholder="Please provide detailed information about your issue..."
                  />
                </div>

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:opacity-90 hover:scale-105 transition-all py-2.5 h-11"
                >
                  {loading ? "Submitting..." : "Submit Ticket"}
                </Button>
              </form>
            </div>

            {/* My Tickets */}
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 hover-lift animate-slide-in-right">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">My Tickets</h2>
              
              <div className="space-y-4 max-h-[600px] overflow-y-auto custom-scrollbar">
                {userTickets.length > 0 ? (
                  userTickets.map((ticket, index) => (
                    <div
                      key={index}
                      className="border-2 border-gray-200 dark:border-gray-700 rounded-xl p-4 hover:border-blue-400 dark:hover:border-blue-600 transition-all"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-semibold text-gray-900 dark:text-white">{ticket.subject}</h3>
                        <span className={`px-3 py-1 rounded-full text-xs font-bold ${getStatusColor(ticket.status)}`}>
                          {ticket.status}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">{ticket.description}</p>
                      <div className="flex items-center gap-4 text-xs text-gray-500 dark:text-gray-500">
                        <span className="flex items-center gap-1">
                          <Clock size={14} />
                          {new Date(ticket.createdAt).toLocaleDateString()}
                        </span>
                        <span className="capitalize">{ticket.category}</span>
                        <span className="capitalize">{ticket.priority}</span>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-12">
                    <Ticket className="w-16 h-16 mx-auto mb-4 text-gray-400" />
                    <p className="text-gray-600 dark:text-gray-400">No tickets yet</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Live Chat Tab */}
        {activeTab === "chat" && (
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 max-w-4xl mx-auto animate-scale-in">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6 flex items-center gap-2">
              <MessageCircle className="text-blue-600" />
              Live Chat Support
            </h2>

            {/* Chat Messages */}
            <div className="bg-gray-50 dark:bg-gray-900 rounded-xl p-6 h-96 overflow-y-auto custom-scrollbar mb-4">
              <div className="space-y-4">
                {chatMessages.map((msg, index) => (
                  <div
                    key={index}
                    className={`flex ${msg.from === "user" ? "justify-end" : "justify-start"} animate-slide-in-${msg.from === "user" ? "right" : "left"}`}
                  >
                    <div className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl ${
                      msg.from === "user"
                        ? "bg-gradient-to-r from-blue-600 to-purple-600 text-white"
                        : "bg-white dark:bg-gray-800 text-gray-900 dark:text-white border-2 border-gray-200 dark:border-gray-700"
                    }`}>
                      <p className="text-sm">{msg.message}</p>
                      <span className="text-xs opacity-70 mt-1 block">
                        {new Date(msg.time).toLocaleTimeString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Chat Input */}
            <div className="flex gap-2">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleChatSend()}
                placeholder="Type your message..."
                className="flex-1 px-4 py-3 border-2 border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 dark:bg-gray-700 dark:text-white"
              />
              <Button
                onClick={handleChatSend}
                className="bg-gradient-to-r from-blue-600 to-purple-600 text-white hover:opacity-90 hover:scale-105 transition-all px-6"
              >
                <Send size={20} />
              </Button>
            </div>

            <p className="text-xs text-gray-500 dark:text-gray-400 mt-4 text-center">
              Our support team typically responds within 5-10 minutes during business hours
            </p>
          </div>
        )}

        {/* Quick Actions */}
        <div className="mt-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl shadow-2xl p-8 text-white text-center animate-fade-in">
          <h3 className="text-2xl font-bold mb-4">Need Quick Help?</h3>
          <p className="mb-6 text-white/90">Check out our FAQ section for instant answers</p>
          <Button
            onClick={() => router.push("/help")}
            className="bg-white text-blue-600 hover:bg-gray-100 px-8 py-3 rounded-xl font-bold border-2 border-white/20 shadow-lg hover:shadow-xl transition-all"
          >
            View FAQ
          </Button>
        </div>
      </div>
    </div>
  )
}
