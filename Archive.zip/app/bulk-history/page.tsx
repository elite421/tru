'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/component/ui/button'
import { FileText, Clock, CheckCircle, XCircle, Download, Upload, RefreshCw } from 'lucide-react'
import { useToast } from '@/component/ToastProvider'

export default function BulkHistoryPage() {
  const { showToast } = useToast()
  const router = useRouter()
  
  const [history, setHistory] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [pagination, setPagination] = useState({ total: 0, limit: 20, offset: 0 })

  useEffect(() => {
    // Bulk verification feature removed - API routes no longer available
    setLoading(false)
    showToast('Bulk verification feature is not available in this version', 'info')
  }, [])

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-600" />
      case 'failed':
        return <XCircle className="w-5 h-5 text-red-600" />
      case 'processing':
        return <RefreshCw className="w-5 h-5 text-blue-600 animate-spin" />
      default:
        return <Clock className="w-5 h-5 text-gray-600" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400'
      case 'failed':
        return 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400'
      case 'processing':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400'
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400'
    }
  }

  const handleViewStatus = (id: string) => {
    router.push(`/bulk-status/${id}`)
  }

  const handleDownloadResult = (id: string) => {
    showToast('Download feature coming soon!', 'info')
  }

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8 flex justify-between items-start">
          <div>
            <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
              Bulk Verification History
            </h1>
            <p className="text-gray-600 dark:text-gray-400">
              View and manage your bulk verification jobs
            </p>
          </div>
          
          <Button
            onClick={() => router.push('/')}
            className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:opacity-90"
          >
            <Upload className="w-4 h-4 mr-2" />
            Back to Dashboard
          </Button>
        </div>

        {/* Content */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-12 text-center">
          <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
            Bulk Verification Not Available
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Bulk verification feature has been removed. Please use manual verification for individual records.
          </p>
          <Button
            onClick={() => router.push('/')}
            className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white"
          >
            Go to Dashboard
          </Button>
        </div>
      </div>
    </div>
  )
}
