"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { 
  Key,
  Search,
  Copy,
  RefreshCw,
  CheckCircle,
  Shield,
  Users,
  Calendar
} from "lucide-react"
import { Button } from "@/component/ui/button"

type User = {
  id: number
  email: string
  full_name: string
  created_at: string
}

export default function AdminApiKeysPage() {
  const router = useRouter()
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [copiedText, setCopiedText] = useState("")

  useEffect(() => {
    checkAuth()
    fetchUsers()
  }, [])

  const checkAuth = () => {
    const adminUser = sessionStorage.getItem("admin_user")
    if (!adminUser) {
      router.push("/admin/login")
    }
  }

  const fetchUsers = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/admin/users")
      
      if (response.ok) {
        const data = await response.json()
        setUsers(data.users || [])
      }
    } catch (error) {
      console.error("Error fetching users:", error)
    } finally {
      setLoading(false)
    }
  }

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text)
    setCopiedText(text)
    setTimeout(() => setCopiedText(""), 2000)
  }

  const filteredUsers = users.filter(user => 
    user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.full_name?.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div className="min-h-screen bg-gray-950">
      <div className="flex-1 overflow-auto">
        <div className="p-4 md:p-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-4xl font-bold text-white mb-2">
                  API Key Management
                </h1>
                <p className="text-gray-400">
                  Manage API keys and access control
                </p>
              </div>
              <Button
                onClick={fetchUsers}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
            </div>
          </div>

          {/* Info Card */}
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-6 mb-6">
            <div className="flex items-start gap-3">
              <Shield className="w-6 h-6 text-blue-400 mt-1" />
              <div>
                <h3 className="text-lg font-semibold text-white mb-2">API Key System</h3>
                <p className="text-gray-400 mb-3">
                  The API key management system allows users to generate and manage their authentication keys for API access.
                </p>
                <div className="bg-white/5 rounded-lg p-4 space-y-2">
                  <p className="text-sm text-gray-300">
                    <span className="font-semibold text-white">Location:</span> Users can manage their API keys at <code className="bg-black/30 px-2 py-1 rounded text-blue-400">/account</code>
                  </p>
                  <p className="text-sm text-gray-300">
                    <span className="font-semibold text-white">Features:</span> Create, view, regenerate, and delete API keys
                  </p>
                  <p className="text-sm text-gray-300">
                    <span className="font-semibold text-white">Security:</span> Keys are hashed and stored securely in the database
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-white/5 border border-white/10 rounded-xl p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Total Users</p>
                  <p className="text-2xl font-bold text-white">{users.length}</p>
                </div>
                <Users className="w-8 h-8 text-blue-400" />
              </div>
            </div>
            
            <div className="bg-white/5 border border-white/10 rounded-xl p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">API Enabled</p>
                  <p className="text-2xl font-bold text-green-400">
                    <CheckCircle className="w-8 h-8" />
                  </p>
                </div>
                <Shield className="w-8 h-8 text-green-400" />
              </div>
            </div>
            
            <div className="bg-white/5 border border-white/10 rounded-xl p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Search Results</p>
                  <p className="text-2xl font-bold text-white">{filteredUsers.length}</p>
                </div>
                <Search className="w-8 h-8 text-purple-400" />
              </div>
            </div>
          </div>

          {/* Search Bar */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-4 mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search users by name or email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-400"
              />
            </div>
          </div>

          {/* Users Table */}
          <div className="bg-white/5 border border-white/10 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-white/10">
                  <tr>
                    <th className="p-4 text-left text-sm font-semibold text-gray-300">User</th>
                    <th className="p-4 text-left text-sm font-semibold text-gray-300">Email</th>
                    <th className="p-4 text-left text-sm font-semibold text-gray-300">User ID</th>
                    <th className="p-4 text-left text-sm font-semibold text-gray-300">Joined Date</th>
                    <th className="p-4 text-left text-sm font-semibold text-gray-300">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan={5} className="p-8 text-center">
                        <RefreshCw className="w-8 h-8 animate-spin text-white mx-auto mb-2" />
                        <p className="text-gray-400">Loading users...</p>
                      </td>
                    </tr>
                  ) : filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="p-8 text-center text-gray-400">
                        No users found
                      </td>
                    </tr>
                  ) : (
                    filteredUsers.map((user) => (
                      <tr key={user.id} className="border-t border-white/10 hover:bg-white/5 transition-colors">
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                              <span className="text-white font-bold">
                                {user.full_name?.charAt(0).toUpperCase() || 'U'}
                              </span>
                            </div>
                            <p className="font-semibold text-white">{user.full_name || 'Unnamed User'}</p>
                          </div>
                        </td>
                        <td className="p-4">
                          <p className="text-gray-300">{user.email}</p>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            <code className="text-sm bg-black/30 px-2 py-1 rounded text-blue-400">
                              {user.id}
                            </code>
                            <button
                              onClick={() => copyToClipboard(user.id.toString())}
                              className="p-1 hover:bg-white/10 rounded transition-colors"
                            >
                              {copiedText === user.id.toString() ? (
                                <CheckCircle className="w-4 h-4 text-green-400" />
                              ) : (
                                <Copy className="w-4 h-4 text-gray-400" />
                              )}
                            </button>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-2 text-gray-300">
                            <Calendar className="w-4 h-4 text-gray-400" />
                            <span className="text-sm">{new Date(user.created_at).toLocaleDateString()}</span>
                          </div>
                        </td>
                        <td className="p-4">
                          <Button
                            onClick={() => router.push(`/admin/users/${user.id}`)}
                            className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded-lg text-sm"
                          >
                            View Details
                          </Button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Instructions */}
          <div className="mt-6 bg-white/5 border border-white/10 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-white mb-3">How to Use API Keys</h3>
            <div className="space-y-3 text-gray-400">
              <p>1. Users can create and manage their API keys in their account page</p>
              <p>2. Each user can have multiple API keys for different applications</p>
              <p>3. API keys should be included in the request headers as: <code className="bg-black/30 px-2 py-1 rounded text-blue-400">Authorization: Bearer YOUR_API_KEY</code></p>
              <p>4. Users should keep their API keys secure and regenerate them if compromised</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
