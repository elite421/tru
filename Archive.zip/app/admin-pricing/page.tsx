"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/component/ui/button"
import { DollarSign, Save, RefreshCw, CheckCircle, Plus, Trash2, Shield, Edit, X } from "lucide-react"
import { useAlert } from "@/component/AlertProvider"

interface PricingRate {
  verificationType: string
  label: string
  price: number
  description: string
}

interface PricingPlan {
  id: number
  name: string
  description: string
  is_active: boolean
  user_count: number
  rates: Array<{ verification_type: string; price: number }>
}

const defaultRates: PricingRate[] = [
  // Identity Documents - KYC
  { verificationType: "pan", label: "PAN Verification - Basic", price: 5, description: "Verify PAN cards (Lite)" },
  { verificationType: "pan-plus", label: "PAN Verification - Plus", price: 7, description: "Enhanced PAN verification" },
  { verificationType: "aadhaar-ekyc", label: "Aadhaar eKYC", price: 8, description: "Aadhaar OTP-based eKYC" },
  { verificationType: "driving-license", label: "Driving License", price: 8, description: "Verify driving licenses" },
  { verificationType: "rc", label: "Vehicle RC", price: 7, description: "Verify vehicle registration" },
  
  // Financial
  { verificationType: "bank-account", label: "Bank Account", price: 6, description: "Verify bank accounts" },
  { verificationType: "ifsc", label: "IFSC Code", price: 2, description: "Verify IFSC codes" },
  { verificationType: "upi", label: "UPI Verification", price: 4, description: "Verify UPI IDs" },
  { verificationType: "upi-advanced", label: "UPI Advanced", price: 6, description: "Advanced UPI verification" },
  { verificationType: "credit-report", label: "Credit Report", price: 50, description: "Get credit report & score" },
  
  // Business & Tax - GST
  { verificationType: "gst", label: "GST Verification - Basic", price: 7, description: "Basic GST verification" },
  { verificationType: "gst-advanced", label: "GST Verification - Advanced", price: 10, description: "Advanced GST verification" },
  { verificationType: "gstin-by-pan", label: "GSTIN by PAN", price: 6, description: "Search GSTIN by PAN" },
  { verificationType: "track-gstr", label: "Track GSTR", price: 8, description: "Track GST returns" },
  
  // Business & Tax - MCA
  { verificationType: "cin", label: "CIN Verification", price: 8, description: "Verify CIN (MCA)" },
  { verificationType: "din", label: "DIN Verification", price: 8, description: "Verify DIN (MCA)" },
  
  // Business & Tax - TaxPayer
  { verificationType: "tan", label: "TAN Verification", price: 5, description: "Verify TAN" },
  { verificationType: "tds-compliance", label: "TDS Compliance Check", price: 7, description: "Check TDS compliance" },
  
  // Telecom
  { verificationType: "mobile-number", label: "Mobile Number", price: 3, description: "Verify mobile numbers" },
  { verificationType: "mobile-to-name", label: "Mobile to Name", price: 5, description: "Get name from mobile" },
  { verificationType: "mobile-to-email", label: "Mobile to Email", price: 5, description: "Get email from mobile" },
  { verificationType: "mobile-intelligence", label: "Mobile Intelligence", price: 8, description: "Comprehensive mobile data" },
  { verificationType: "email-validation", label: "Email Validation", price: 2, description: "Validate email addresses" },
]

export default function AdminPricingPage() {
  const router = useRouter()
  const { success, error } = useAlert()
  const [rates, setRates] = useState<PricingRate[]>(defaultRates)
  const [loading, setLoading] = useState(false)
  const [plans, setPlans] = useState<PricingPlan[]>([])
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [showEditModal, setShowEditModal] = useState(false)
  const [editingPlan, setEditingPlan] = useState<PricingPlan | null>(null)

  // New plan form
  const [newPlanName, setNewPlanName] = useState("")
  const [newPlanDescription, setNewPlanDescription] = useState("")
  const [newPlanRates, setNewPlanRates] = useState<Record<string, number>>({})

  useEffect(() => {
    checkAuth()
    fetchPlans()
    fetchDefaultRates() // Load actual prices from database
    initializeNewPlanRates()
  }, [])

  const checkAuth = () => {
    const adminUser = sessionStorage.getItem("admin_user")
    if (!adminUser) {
      router.push("/admin/login")
    }
  }

  const fetchDefaultRates = async () => {
    try {
      const response = await fetch("/api/admin/pricing")
      if (response.ok) {
        const data = await response.json()
        if (data.rates && data.rates.length > 0) {
          // Map database rates to PricingRate format with labels and descriptions
          const mappedRates = defaultRates.map(defaultRate => {
            // Find matching rate from database
            const dbRate = data.rates.find((r: any) => r.verificationType === defaultRate.verificationType)
            return {
              verificationType: defaultRate.verificationType,
              label: defaultRate.label,
              description: defaultRate.description,
              // Use database price if found, otherwise use default
              price: dbRate ? dbRate.price : defaultRate.price
            }
          })
          setRates(mappedRates)
          console.log('[Admin Pricing] Loaded rates from database:', mappedRates.length)
        } else {
          // No database rates found, use defaults
          console.log('[Admin Pricing] No database rates found, using defaults')
        }
      }
    } catch (err) {
      console.error("Error fetching default rates:", err)
    }
  }

  const initializeNewPlanRates = () => {
    const initialRates: Record<string, number> = {}
    defaultRates.forEach(rate => {
      initialRates[rate.verificationType] = rate.price
    })
    setNewPlanRates(initialRates)
  }

  const fetchPlans = async () => {
    try {
      const response = await fetch("/api/admin/plans")
      if (response.ok) {
        const data = await response.json()
        setPlans(data.plans || [])
      }
    } catch (err) {
      console.error("Error fetching plans:", err)
    }
  }

  const handlePriceChange = (verificationType: string, newPrice: number) => {
    setRates(rates.map(rate => 
      rate.verificationType === verificationType 
        ? { ...rate, price: newPrice }
        : rate
    ))
  }

  const handleNewPlanRateChange = (verificationType: string, newPrice: number) => {
    setNewPlanRates({
      ...newPlanRates,
      [verificationType]: newPrice
    })
  }

  const handleSave = async () => {
    setLoading(true)
    try {
      const response = await fetch("/api/admin/pricing", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          rates: rates.map(rate => ({
            verificationType: rate.verificationType,
            price: rate.price
          }))
        })
      })

      const data = await response.json()

      if (response.ok) {
        success(data.message || "Default pricing updated successfully!")
        await fetchDefaultRates()
      } else {
        error(data.error || "Failed to update pricing")
      }
    } catch (err) {
      console.error("Error updating pricing:", err)
      error("Failed to update pricing")
    } finally {
      setLoading(false)
    }
  }

  const handleReset = () => {
    if (confirm("Reset all prices to default values?")) {
      setRates(defaultRates)
      success("Prices reset to default")
    }
  }

  const handleCreatePlan = async () => {
    if (!newPlanName.trim()) {
      error("Please enter a plan name")
      return
    }

    setLoading(true)
    try {
      const response = await fetch("/api/admin/plans", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: newPlanName,
          description: newPlanDescription,
          rates: newPlanRates
        })
      })

      const data = await response.json()

      if (response.ok) {
        success(data.message || "Plan created successfully!")
        setShowCreateModal(false)
        setNewPlanName("")
        setNewPlanDescription("")
        initializeNewPlanRates()
        fetchPlans()
      } else {
        error(data.error || "Failed to create plan")
      }
    } catch (err) {
      error("Failed to create plan")
    } finally {
      setLoading(false)
    }
  }

  const handleDeletePlan = async (planId: number) => {
    if (!confirm("Are you sure you want to delete this plan?")) return

    try {
      const response = await fetch(`/api/admin/plans?id=${planId}`, {
        method: "DELETE"
      })

      const data = await response.json()

      if (response.ok) {
        success("Plan deleted successfully!")
        fetchPlans()
      } else {
        error(data.error || "Failed to delete plan")
      }
    } catch (err) {
      error("Failed to delete plan")
    }
  }

  const categories = [
    { name: "Identity & KYC", items: rates.filter(r => ["pan", "pan-plus", "aadhaar-ekyc", "driving-license", "rc"].includes(r.verificationType)) },
    { name: "Financial Services", items: rates.filter(r => ["bank-account", "ifsc", "upi", "upi-advanced", "credit-report"].includes(r.verificationType)) },
    { name: "GST Verification", items: rates.filter(r => ["gst", "gst-advanced", "gstin-by-pan", "track-gstr"].includes(r.verificationType)) },
    { name: "Business & Corporate", items: rates.filter(r => ["cin", "din", "tan", "tds-compliance"].includes(r.verificationType)) },
    { name: "Telecom & Email", items: rates.filter(r => ["mobile-number", "mobile-to-name", "mobile-to-email", "mobile-intelligence", "email-validation"].includes(r.verificationType)) },
  ]

  const totalRevenue = rates.reduce((sum, rate) => sum + rate.price, 0)

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">
                Pricing Management
              </h1>
              <p className="text-gray-400">
                Configure default pricing and create custom plans for clients
              </p>
            </div>
            <div className="flex gap-3">
              <Button
                onClick={handleReset}
                className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg flex items-center gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                Reset
              </Button>
              <Button
                onClick={handleSave}
                disabled={loading}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  <>
                    <Save className="w-4 h-4" />
                    Save Changes
                  </>
                )}
              </Button>
            </div>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Total Services</p>
                <p className="text-2xl font-bold text-white">{rates.length}</p>
              </div>
              <Shield className="w-8 h-8 text-blue-400" />
            </div>
          </div>
          
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Avg Price</p>
                <p className="text-2xl font-bold text-white">₹{(totalRevenue / rates.length).toFixed(2)}</p>
              </div>
              <DollarSign className="w-8 h-8 text-green-400" />
            </div>
          </div>
          
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Custom Plans</p>
                <p className="text-2xl font-bold text-white">{plans.length}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-purple-400" />
            </div>
          </div>

          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Assigned Users</p>
                <p className="text-2xl font-bold text-white">
                  {plans.reduce((sum, plan) => sum + plan.user_count, 0)}
                </p>
              </div>
              <Shield className="w-8 h-8 text-orange-400" />
            </div>
          </div>
        </div>

        {/* Custom Plans Section */}
        <div className="bg-white/5 border border-white/10 rounded-xl p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-white">Custom Pricing Plans</h2>
            <Button
              onClick={() => setShowCreateModal(true)}
              className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center gap-2"
            >
              <Plus className="w-4 h-4" />
              Create Plan
            </Button>
          </div>

          {plans.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-400 mb-4">No custom plans created yet</p>
              <p className="text-sm text-gray-500">Create plans for negotiated clients with custom pricing</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {plans.map(plan => (
                <div key={plan.id} className="bg-white/5 border border-white/10 rounded-lg p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-white mb-1">{plan.name}</h3>
                      <p className="text-sm text-gray-400">{plan.description}</p>
                    </div>
                    <button
                      onClick={() => handleDeletePlan(plan.id)}
                      className="p-2 hover:bg-red-500/20 text-red-400 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="flex items-center justify-between pt-3 border-t border-white/10">
                    <span className="text-sm text-gray-400">
                      {plan.user_count} user{plan.user_count !== 1 ? 's' : ''} assigned
                    </span>
                    <span className={`text-xs px-2 py-1 rounded ${
                      plan.is_active ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'
                    }`}>
                      {plan.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Default Pricing Categories */}
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-white mb-4">Default Service Pricing</h2>
          <p className="text-gray-400 mb-6">These rates apply to users without a custom plan</p>
        </div>

        <div className="space-y-6">
          {categories.map((category) => (
            <div key={category.name} className="bg-white/5 border border-white/10 rounded-xl p-6">
              <h3 className="text-xl font-bold text-white mb-4">{category.name}</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {category.items.map((rate) => (
                  <div key={rate.verificationType} className="bg-white/5 border border-white/10 rounded-lg p-4">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <h4 className="font-semibold text-white mb-1">{rate.label}</h4>
                        <p className="text-sm text-gray-400">{rate.description}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 mt-3">
                      <span className="text-gray-400">₹</span>
                      <input
                        type="number"
                        value={rate.price}
                        onChange={(e) => handlePriceChange(rate.verificationType, parseFloat(e.target.value) || 0)}
                        className="flex-1 px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
                        min="0"
                        step="0.01"
                      />
                      <span className="text-gray-400 text-sm">per verification</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Info Card */}
        <div className="mt-6 bg-blue-500/10 border border-blue-500/20 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-2">💡 Pricing Tips</h3>
          <ul className="space-y-2 text-gray-400 text-sm">
            <li>• Default prices apply to all users without a custom plan</li>
            <li>• Create custom plans for negotiated clients with special pricing</li>
            <li>• Assign plans to users in the User Management section</li>
            <li>• Users with expired plans will revert to default pricing</li>
          </ul>
        </div>
      </div>

      {/* Create Plan Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-800 rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-white">Create Custom Pricing Plan</h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="p-2 hover:bg-white/10 rounded-lg transition-colors"
              >
                <X className="w-6 h-6 text-gray-400" />
              </button>
            </div>

            <div className="space-y-4 mb-6">
              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Plan Name *</label>
                <input
                  type="text"
                  value={newPlanName}
                  onChange={(e) => setNewPlanName(e.target.value)}
                  placeholder="e.g., Enterprise Plan, VIP Client"
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-blue-400"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">Description</label>
                <input
                  type="text"
                  value={newPlanDescription}
                  onChange={(e) => setNewPlanDescription(e.target.value)}
                  placeholder="e.g., Special pricing for enterprise clients"
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-blue-400"
                />
              </div>
            </div>

            <div className="mb-6">
              <h4 className="text-lg font-semibold text-white mb-4">Custom Rates</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-96 overflow-y-auto">
                {defaultRates.map(rate => (
                  <div key={rate.verificationType} className="bg-white/5 border border-white/10 rounded-lg p-3">
                    <p className="text-sm font-semibold text-white mb-1">{rate.label}</p>
                    <p className="text-xs text-gray-400 mb-2">{rate.description}</p>
                    <div className="flex items-center gap-2">
                      <span className="text-gray-400">₹</span>
                      <input
                        type="number"
                        value={newPlanRates[rate.verificationType] || 0}
                        onChange={(e) => handleNewPlanRateChange(rate.verificationType, parseFloat(e.target.value) || 0)}
                        className="flex-1 px-3 py-1 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
                        min="0"
                        step="0.01"
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                onClick={() => setShowCreateModal(false)}
                className="flex-1 bg-gray-600 hover:bg-gray-700 text-white py-2 rounded-lg"
              >
                Cancel
              </Button>
              <Button
                onClick={handleCreatePlan}
                disabled={loading}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {loading ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Plus className="w-4 h-4" />
                )}
                Create Plan
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
