"use client"

import { 
  Shield, 
  Zap, 
  Lock, 
  CheckCircle, 
  Clock, 
  Globe, 
  DollarSign, 
  TrendingUp,
  Smartphone,
  Mail,
  CreditCard,
  FileText,
  Database,
  Sparkles,
  Award,
  BarChart3
} from "lucide-react"

export default function FeaturesPage() {
  const mainFeatures = [
    {
      icon: <Zap className="w-12 h-12" />,
      title: "Lightning Fast Verification",
      description: "Get instant verification results in less than 2 seconds. Our optimized infrastructure ensures rapid processing without compromising accuracy.",
      gradient: "from-yellow-400 to-orange-500"
    },
    {
      icon: <Shield className="w-12 h-12" />,
      title: "Bank-Grade Security",
      description: "Enterprise-level encryption and security protocols protect all data transmissions. Your information is safe with 256-bit SSL encryption.",
      gradient: "from-blue-400 to-indigo-600"
    },
    {
      icon: <CheckCircle className="w-12 h-12" />,
      title: "99.9% Accuracy Rate",
      description: "Our AI-powered verification system delivers industry-leading accuracy. Minimize false positives and ensure reliable results every time.",
      gradient: "from-green-400 to-emerald-600"
    },
    {
      icon: <Globe className="w-12 h-12" />,
      title: "Pan-India Coverage",
      description: "Comprehensive database coverage across all Indian states and territories. Verify documents from any region with complete confidence.",
      gradient: "from-purple-400 to-pink-600"
    },
    {
      icon: <Lock className="w-12 h-12" />,
      title: "GDPR & Compliance",
      description: "Fully compliant with data protection regulations including GDPR, ISO 27001, and Indian IT Act. Your data privacy is our priority.",
      gradient: "from-red-400 to-rose-600"
    },
    {
      icon: <DollarSign className="w-12 h-12" />,
      title: "Pay-As-You-Go Pricing",
      description: "No hidden fees, no subscriptions. Only pay for successful verifications. Scale from 1 to 1 million verifications effortlessly.",
      gradient: "from-cyan-400 to-blue-600"
    }
  ]

  const verificationTypes = [
    {
      icon: <CreditCard className="w-8 h-8" />,
      title: "PAN Verification",
      description: "Basic & Plus with enhanced details",
      price: "₹5-₹7",
      color: "bg-purple-500"
    },
    {
      icon: <FileText className="w-8 h-8" />,
      title: "Aadhaar eKYC",
      description: "OTP-based eKYC verification",
      price: "₹8",
      color: "bg-blue-500"
    },
    {
      icon: <FileText className="w-8 h-8" />,
      title: "Driving License",
      description: "Complete license details",
      price: "₹8",
      color: "bg-green-500"
    },
    {
      icon: <Database className="w-8 h-8" />,
      title: "GST Verification",
      description: "Basic & Advanced GST verification",
      price: "₹7-₹10",
      color: "bg-orange-500"
    },
    {
      icon: <Globe className="w-8 h-8" />,
      title: "Vehicle RC",
      description: "Registration certificate verification",
      price: "₹7",
      color: "bg-red-500"
    },
    {
      icon: <Database className="w-8 h-8" />,
      title: "Bank Account",
      description: "Account verification with IFSC",
      price: "₹6",
      color: "bg-teal-500"
    },
    {
      icon: <Smartphone className="w-8 h-8" />,
      title: "UPI Verification",
      description: "Basic & Advanced UPI validation",
      price: "₹4-₹6",
      color: "bg-cyan-500"
    },
    {
      icon: <Database className="w-8 h-8" />,
      title: "IFSC Code",
      description: "Bank branch details",
      price: "₹2",
      color: "bg-teal-500"
    },
    {
      icon: <Smartphone className="w-8 h-8" />,
      title: "Mobile Intelligence",
      description: "Mobile to PAN, UAN, Name & more",
      price: "₹4-₹8",
      color: "bg-indigo-500"
    },
    {
      icon: <CheckCircle className="w-8 h-8" />,
      title: "EPFO Services",
      description: "UAN verification & employment history",
      price: "₹7-₹9",
      color: "bg-green-500"
    },
    {
      icon: <FileText className="w-8 h-8" />,
      title: "Document OCR",
      description: "Aadhaar, PAN, DL, Voter ID OCR",
      price: "₹8-₹10",
      color: "bg-purple-500"
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Biometric Services",
      description: "Face match & liveness detection",
      price: "₹12-₹15",
      color: "bg-pink-500"
    },
    {
      icon: <Globe className="w-8 h-8" />,
      title: "Business Verification",
      description: "CIN, DIN, TAN, MSME services",
      price: "₹5-₹10",
      color: "bg-yellow-500"
    },
    {
      icon: <CreditCard className="w-8 h-8" />,
      title: "Credit Report",
      description: "Comprehensive credit assessment",
      price: "₹50",
      color: "bg-rose-500"
    }
  ]

  const benefits = [
    {
      icon: <Clock className="w-6 h-6" />,
      title: "Save Time",
      description: "Reduce verification time from days to seconds"
    },
    {
      icon: <TrendingUp className="w-6 h-6" />,
      title: "Boost Conversions",
      description: "Faster onboarding increases completion rates by 40%"
    },
    {
      icon: <Award className="w-6 h-6" />,
      title: "Trusted by 1000+",
      description: "Leading businesses trust our verification platform"
    },
    {
      icon: <BarChart3 className="w-6 h-6" />,
      title: "Real-time Analytics",
      description: "Track all verifications with detailed dashboards"
    }
  ]

  const useCases = [
    {
      title: "FinTech & Banking",
      description: "KYC compliance, account opening, loan approvals, and fraud prevention.",
      emoji: "🏦"
    },
    {
      title: "E-commerce",
      description: "Seller verification, buyer authentication, and payment security.",
      emoji: "🛒"
    },
    {
      title: "Healthcare",
      description: "Patient verification, insurance validation, and provider credentialing.",
      emoji: "🏥"
    },
    {
      title: "EdTech",
      description: "Student verification, certificate validation, and enrollment processing.",
      emoji: "🎓"
    },
    {
      title: "Real Estate",
      description: "Tenant screening, property verification, and ownership validation.",
      emoji: "🏠"
    },
    {
      title: "Travel & Hospitality",
      description: "Guest verification, booking authentication, and identity validation.",
      emoji: "✈️"
    }
  ]

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-500/10 via-purple-500/10 to-pink-500/10 animate-float" />
        <div className="relative max-w-7xl mx-auto px-8 py-20">
          <div className="text-center mb-12">
            <div className="inline-block mb-4 animate-bounce-in">
              <span className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-6 py-2 rounded-full text-sm font-semibold">
                ✨ Trusted by 1000+ Businesses
              </span>
            </div>
            <h1 className="text-6xl font-bold bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-6 animate-fade-in">
              Powerful Verification Features
            </h1>
            <p className="text-2xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto animate-slide-up" style={{ animationDelay: "0.2s" }}>
              Everything you need to verify identities, documents, and credentials instantly with industry-leading accuracy and security.
            </p>
          </div>
        </div>
      </section>

      {/* Main Features Grid */}
      <section className="max-w-7xl mx-auto px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {mainFeatures.map((feature, index) => (
            <div 
              key={index}
              className="group bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 animate-scale-in"
              style={{ animationDelay: `${0.3 + (index * 0.1)}s` }}
            >
              <div className={`w-16 h-16 bg-gradient-to-br ${feature.gradient} rounded-2xl flex items-center justify-center text-white mb-6 group-hover:scale-110 transition-transform duration-300`}>
                {feature.icon}
              </div>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                {feature.title}
              </h3>
              <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Verification Types */}
      <section className="max-w-7xl mx-auto px-8 py-16">
        <div className="text-center mb-12 animate-fade-in">
          <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            40+ Verification Services
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Comprehensive Deepvue API verification suite for all your business needs
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {verificationTypes.map((type, index) => (
            <div 
              key={index}
              className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 hover:shadow-xl hover:scale-105 transition-all duration-300 border-2 border-gray-100 dark:border-gray-700 hover:border-indigo-300 dark:hover:border-indigo-600 animate-slide-in-left"
              style={{ animationDelay: `${0.1 + (index * 0.1)}s` }}
            >
              <div className="flex items-start gap-4">
                <div className={`${type.color} rounded-xl p-3 text-white flex-shrink-0`}>
                  {type.icon}
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                    {type.title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 text-sm mb-3">
                    {type.description}
                  </p>
                  <span className="inline-block bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-3 py-1 rounded-full text-xs font-bold">
                    {type.price}/API
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Benefits Section */}
      <section className="max-w-7xl mx-auto px-8 py-16">
        <div className="bg-gradient-to-br from-indigo-600 to-purple-600 rounded-3xl shadow-2xl p-12 text-white animate-glow hover:scale-105 transition-transform duration-500">
          <div className="text-center mb-12 animate-fade-in">
            <h2 className="text-4xl font-bold mb-4">Why Choose TruVerify?</h2>
            <p className="text-xl text-white/90">
              Join thousands of businesses that trust our platform
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <div 
                key={index}
                className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 hover:bg-white/20 hover:scale-110 transition-all duration-300 animate-bounce-in"
                style={{ animationDelay: `${0.2 + (index * 0.1)}s` }}
              >
                <div className="bg-white/20 w-12 h-12 rounded-xl flex items-center justify-center mb-4">
                  {benefit.icon}
                </div>
                <h3 className="text-xl font-bold mb-2">{benefit.title}</h3>
                <p className="text-white/80">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Use Cases */}
      <section className="max-w-7xl mx-auto px-8 py-16">
        <div className="text-center mb-12 animate-slide-up">
          <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Built for Every Industry
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Trusted verification solutions across diverse sectors
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {useCases.map((useCase, index) => (
            <div 
              key={index}
              className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-8 hover:shadow-xl hover:scale-105 transition-all duration-300 border-l-4 border-indigo-600 animate-slide-in-right"
              style={{ animationDelay: `${0.1 + (index * 0.1)}s` }}
            >
              <div className="text-5xl mb-4">{useCase.emoji}</div>
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-3">
                {useCase.title}
              </h3>
              <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                {useCase.description}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* Stats Section */}
      <section className="max-w-7xl mx-auto px-8 py-16">
        <div className="bg-gradient-to-r from-gray-900 to-gray-800 dark:from-gray-800 dark:to-gray-900 rounded-3xl shadow-2xl p-12 animate-fade-in hover:scale-105 transition-transform duration-500">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <div className="animate-bounce-in stagger-1">
              <div className="text-5xl font-bold bg-gradient-to-r from-yellow-400 to-orange-500 bg-clip-text text-transparent mb-2 animate-float">
                99.9%
              </div>
              <div className="text-gray-400 text-lg">Accuracy Rate</div>
            </div>
            <div className="animate-bounce-in stagger-2">
              <div className="text-5xl font-bold bg-gradient-to-r from-blue-400 to-indigo-500 bg-clip-text text-transparent mb-2 animate-float">
                &lt;2s
              </div>
              <div className="text-gray-400 text-lg">Average Response</div>
            </div>
            <div className="animate-bounce-in stagger-3">
              <div className="text-5xl font-bold bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent mb-2 animate-float">
                10M+
              </div>
              <div className="text-gray-400 text-lg">Verifications</div>
            </div>
            <div className="animate-bounce-in stagger-4">
              <div className="text-5xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent mb-2 animate-float">
                1000+
              </div>
              <div className="text-gray-400 text-lg">Happy Clients</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="max-w-7xl mx-auto px-8 py-16 mb-16">
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-3xl shadow-2xl p-12 text-center text-white">
          <Sparkles className="w-16 h-16 mx-auto mb-6" />
          <h2 className="text-4xl font-bold mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-xl mb-8 text-white/90 max-w-2xl mx-auto">
            Join thousands of businesses using TruVerify for fast, accurate, and secure verification. No credit card required to start.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="/docs"
              className="bg-white text-indigo-600 px-8 py-4 rounded-xl font-bold text-lg hover:bg-gray-100 transition-all duration-300 shadow-lg hover:shadow-xl"
            >
              View Documentation
            </a>
            <a 
              href="/contact"
              className="bg-white/10 backdrop-blur-sm text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-white/20 transition-all duration-300 border-2 border-white/30"
            >
              Contact Sales
            </a>
          </div>
        </div>
      </section>
    </div>
  )
}
