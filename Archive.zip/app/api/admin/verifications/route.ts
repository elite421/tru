import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

export async function GET(request: NextRequest) {
  try {
    // Get all verification requests with user details
    const result = await query(`
      SELECT 
        vr.id,
        vr.user_id,
        u.email as user_email,
        u.full_name as user_name,
        vr.verification_type,
        vr.document_number,
        vr.status,
        vr.cost,
        vr.created_at,
        vr.verified_at
      FROM verification_requests vr
      LEFT JOIN users u ON vr.user_id = u.id
      ORDER BY vr.created_at DESC
      LIMIT 100
    `);

    // Get summary statistics
    const statsResult = await query(`
      SELECT 
        COUNT(*) as total_verifications,
        COUNT(CASE WHEN status = 'success' THEN 1 END) as successful,
        COUNT(CASE WHEN status = 'failed' THEN 1 END) as failed,
        SUM(cost) as total_revenue,
        COUNT(DISTINCT user_id) as unique_users
      FROM verification_requests
    `);

    const stats = statsResult.rows[0];

    return NextResponse.json({
      success: true,
      verifications: result.rows,
      stats: {
        totalVerifications: parseInt(stats.total_verifications),
        successful: parseInt(stats.successful),
        failed: parseInt(stats.failed),
        totalRevenue: parseFloat(stats.total_revenue || 0),
        uniqueUsers: parseInt(stats.unique_users)
      }
    });
  } catch (error: any) {
    console.error("Admin verifications error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to fetch verifications" },
      { status: 500 }
    );
  }
}
