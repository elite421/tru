import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const body = await request.json();
    const { planId, expiresAt } = body;
    const { id: userId } = await params;

    if (!planId) {
      return NextResponse.json(
        { success: false, error: "Plan ID is required" },
        { status: 400 }
      );
    }

    // Verify plan exists
    const planResult = await query(
      "SELECT id, name FROM pricing_plans WHERE id = $1",
      [planId]
    );

    if (planResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "Plan not found" },
        { status: 404 }
      );
    }

    // Assign plan to user
    await query(
      `UPDATE users 
       SET pricing_plan_id = $1, 
           plan_expires_at = $2,
           updated_at = CURRENT_TIMESTAMP
       WHERE id = $3`,
      [planId, expiresAt || null, userId]
    );

    return NextResponse.json({
      success: true,
      message: `Plan "${planResult.rows[0].name}" assigned successfully`
    });
  } catch (error: any) {
    console.error("Error assigning plan:", error);
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}
