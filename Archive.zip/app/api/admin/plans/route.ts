import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

// GET: Fetch all pricing plans
export async function GET(request: NextRequest) {
  try {
    const plansResult = await query(`
      SELECT 
        pp.id,
        pp.name,
        pp.description,
        pp.is_default,
        pp.is_active,
        pp.created_at,
        COUNT(u.id) as user_count
      FROM pricing_plans pp
      LEFT JOIN users u ON u.pricing_plan_id = pp.id
      GROUP BY pp.id
      ORDER BY pp.created_at DESC
    `);

    const plans = await Promise.all(plansResult.rows.map(async (plan) => {
      const ratesResult = await query(
        "SELECT verification_type, price FROM pricing_plan_rates WHERE pricing_plan_id = $1",
        [plan.id]
      );
      
      return {
        ...plan,
        rates: ratesResult.rows
      };
    }));

    return NextResponse.json({ success: true, plans });
  } catch (error: any) {
    console.error("Error fetching plans:", error);
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}

// POST: Create new pricing plan
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, description, rates } = body;

    if (!name || !rates || Object.keys(rates).length === 0) {
      return NextResponse.json(
        { success: false, error: "Plan name and rates are required" },
        { status: 400 }
      );
    }

    // Create the plan
    const planResult = await query(
      `INSERT INTO pricing_plans (name, description, is_active)
       VALUES ($1, $2, true)
       RETURNING *`,
      [name, description || '']
    );

    const newPlan = planResult.rows[0];

    // Insert rates
    for (const [verificationType, price] of Object.entries(rates)) {
      await query(
        `INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price)
         VALUES ($1, $2, $3)`,
        [newPlan.id, verificationType, price]
      );
    }

    return NextResponse.json({
      success: true,
      plan: newPlan,
      message: "Pricing plan created successfully"
    });
  } catch (error: any) {
    console.error("Error creating plan:", error);
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}

// PUT: Update pricing plan
export async function PUT(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, name, description, rates, isActive } = body;

    if (!id) {
      return NextResponse.json(
        { success: false, error: "Plan ID is required" },
        { status: 400 }
      );
    }

    // Update plan
    await query(
      `UPDATE pricing_plans 
       SET name = $1, description = $2, is_active = $3, updated_at = CURRENT_TIMESTAMP
       WHERE id = $4`,
      [name, description, isActive, id]
    );

    // Update rates if provided
    if (rates) {
      // Delete old rates
      await query("DELETE FROM pricing_plan_rates WHERE pricing_plan_id = $1", [id]);
      
      // Insert new rates
      for (const [verificationType, price] of Object.entries(rates)) {
        await query(
          `INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price)
           VALUES ($1, $2, $3)`,
          [id, verificationType, price]
        );
      }
    }

    return NextResponse.json({
      success: true,
      message: "Pricing plan updated successfully"
    });
  } catch (error: any) {
    console.error("Error updating plan:", error);
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}

// DELETE: Delete pricing plan
export async function DELETE(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const id = searchParams.get("id");

    if (!id) {
      return NextResponse.json(
        { success: false, error: "Plan ID is required" },
        { status: 400 }
      );
    }

    // Check if plan is assigned to any users
    const usersResult = await query(
      "SELECT COUNT(*) as count FROM users WHERE pricing_plan_id = $1",
      [id]
    );

    if (parseInt(usersResult.rows[0].count) > 0) {
      return NextResponse.json(
        { success: false, error: "Cannot delete plan that is assigned to users" },
        { status: 400 }
      );
    }

    // Delete plan (rates will be deleted automatically due to CASCADE)
    await query("DELETE FROM pricing_plans WHERE id = $1", [id]);

    return NextResponse.json({
      success: true,
      message: "Pricing plan deleted successfully"
    });
  } catch (error: any) {
    console.error("Error deleting plan:", error);
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}
