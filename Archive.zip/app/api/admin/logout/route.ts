import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get("admin_token")?.value;

    if (token) {
      // Delete session from database
      await query(
        "DELETE FROM admin_sessions WHERE session_token = $1",
        [token]
      );
    }

    const response = NextResponse.json({
      success: true,
      message: "Logged out successfully",
    });

    // Clear cookie
    response.cookies.delete("admin_token");

    return response;
  } catch (error: any) {
    console.error("Admin logout error:", error);
    return NextResponse.json(
      { success: false, error: "Logout failed" },
      { status: 500 }
    );
  }
}
