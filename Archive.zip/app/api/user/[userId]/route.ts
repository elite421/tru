import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ userId: string }> }
) {
  try {
    const { userId } = await params;

    if (!userId) {
      return NextResponse.json(
        { success: false, error: "User ID is required" },
        { status: 400 }
      );
    }

    // Get user details with plan name
    const userResult = await query(
      `SELECT 
        u.id, 
        u.email, 
        u.phone, 
        u.full_name, 
        u.company_name, 
        u.email_verified, 
        u.phone_verified, 
        u.pricing_plan_id, 
        u.plan_expires_at, 
        u.created_at, 
        u.last_login,
        pp.name as plan_name
       FROM users u
       LEFT JOIN pricing_plans pp ON u.pricing_plan_id = pp.id
       WHERE u.id = $1`,
      [userId]
    );

    if (userResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "User not found" },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      user: userResult.rows[0]
    });
  } catch (error: any) {
    console.error("User fetch error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to fetch user" },
      { status: 500 }
    );
  }
}
