import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");
    const limit = parseInt(searchParams.get("limit") || "50");
    const offset = parseInt(searchParams.get("offset") || "0");

    if (!userId) {
      return NextResponse.json(
        { success: false, error: "User ID is required" },
        { status: 400 }
      );
    }

    // Get verification history
    const historyResult = await query(
      `SELECT id, user_id, verification_type, amount, base_amount, gst_amount, 
              gst_percentage, deepvue_transaction_id, response_time, status, 
              cache_hit, details, created_at 
       FROM transactions 
       WHERE user_id = $1 
       ORDER BY created_at DESC 
       LIMIT $2 OFFSET $3`,
      [userId, limit, offset]
    );

    const history = historyResult.rows.map((row) => ({
      id: row.id,
      user_id: row.user_id,
      verification_type: row.verification_type,
      amount_charged: parseFloat(row.amount || row.base_amount),
      base_amount: parseFloat(row.base_amount || 0),
      gst_amount: parseFloat(row.gst_amount || 0),
      status: row.status,
      cache_hit: row.cache_hit,
      details: row.details,
      deepvue_transaction_id: row.deepvue_transaction_id,
      response_time: row.response_time,
      created_at: row.created_at,
    }));

    // Get total count
    const countResult = await query(
      `SELECT COUNT(*) FROM transactions WHERE user_id = $1`,
      [userId]
    );
    const total = parseInt(countResult.rows[0].count);

    return NextResponse.json(
      {
        success: true,
        history,
        pagination: {
          total,
          limit,
          offset,
        },
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Verification history error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to fetch verification history" },
      { status: 500 }
    );
  }
}
