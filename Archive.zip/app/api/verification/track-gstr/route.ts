import { NextRequest, NextResponse } from "next/server";
import { deepvueService } from "@/lib/deepvue";
import { query } from "@/db/db";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, gstinNumber, financialYear } = body;

    if (!userId || !gstinNumber || !financialYear) {
      return NextResponse.json(
        { success: false, error: "User ID, GSTIN number, and financial year are required" },
        { status: 400 }
      );
    }

    const gstinRegex = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
    if (!gstinRegex.test(gstinNumber)) {
      return NextResponse.json(
        { success: false, error: "Invalid GSTIN format" },
        { status: 400 }
      );
    }

    const deepvueResponse = await deepvueService.trackGSTR(gstinNumber, financialYear);

    const walletResult = await query(
      "SELECT balance FROM wallets WHERE user_id = $1",
      [userId]
    );

    if (walletResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "Wallet not found" },
        { status: 404 }
      );
    }

    const currentBalance = parseFloat(walletResult.rows[0].balance);
    const verificationCost = 8;

    if (currentBalance < verificationCost) {
      return NextResponse.json(
        { success: false, error: "Insufficient wallet balance" },
        { status: 400 }
      );
    }

    await query(
      "UPDATE wallets SET balance = balance - $1 WHERE user_id = $2",
      [verificationCost, userId]
    );

    await query(
      `INSERT INTO verification_history 
       (user_id, verification_type, status, details, amount_charged) 
       VALUES ($1, $2, $3, $4, $5)`,
      [userId, "track_gstr", "completed", JSON.stringify(deepvueResponse), verificationCost]
    );

    return NextResponse.json(
      {
        success: true,
        data: deepvueResponse,
        wallet: {
          amountDeducted: verificationCost,
          newBalance: currentBalance - verificationCost,
        },
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Track GSTR error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Service failed" },
      { status: 500 }
    );
  }
}
