import { NextRequest, NextResponse } from "next/server";
import { deepvueService } from "@/lib/deepvue";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { panNumber } = body;

    if (!panNumber) {
      return NextResponse.json(
        { success: false, error: "PAN number is required" },
        { status: 400 }
      );
    }

    // Call Deepvue API
    const result = await deepvueService.verifyPANPlus(panNumber);

    return NextResponse.json({
      success: true,
      data: result,
    });
  } catch (error: any) {
    console.error("PAN Plus verification error:", error);
    return NextResponse.json(
      {
        success: false,
        error: error.message || "Failed to verify PAN Plus",
      },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const panNumber = searchParams.get("panNumber");

    if (!panNumber) {
      return NextResponse.json(
        { success: false, error: "PAN number is required" },
        { status: 400 }
      );
    }

    // Call Deepvue API
    const result = await deepvueService.verifyPANPlus(panNumber);

    return NextResponse.json({
      success: true,
      data: result,
    });
  } catch (error: any) {
    console.error("PAN Plus verification error:", error);
    return NextResponse.json(
      {
        success: false,
        error: error.message || "Failed to verify PAN Plus",
      },
      { status: 500 }
    );
  }
}
