import { NextRequest, NextResponse } from "next/server";
import { deepvueService } from "@/lib/deepvue";

// Step 1: Generate OTP
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { step, aadhaarNumber, otp, referenceId, consent = "Y", purpose = "For KYC" } = body;

    if (step === "generate-otp") {
      if (!aadhaarNumber) {
        return NextResponse.json(
          { success: false, error: "Aadhaar number is required" },
          { status: 400 }
        );
      }

      // Call Deepvue API to generate OTP
      const result = await deepvueService.generateAadhaarOTP(aadhaarNumber, consent, purpose);

      return NextResponse.json({
        success: true,
        data: result,
        message: "OTP sent to registered mobile number",
      });
    } else if (step === "verify-otp") {
      if (!otp || !referenceId) {
        return NextResponse.json(
          { success: false, error: "OTP and reference ID are required" },
          { status: 400 }
        );
      }

      // Call Deepvue API to verify OTP
      const result = await deepvueService.verifyAadhaarOTP(otp, referenceId, consent, purpose);

      return NextResponse.json({
        success: true,
        data: result,
        message: "Aadhaar eKYC completed successfully",
      });
    } else {
      return NextResponse.json(
        { success: false, error: "Invalid step. Use 'generate-otp' or 'verify-otp'" },
        { status: 400 }
      );
    }
  } catch (error: any) {
    console.error("Aadhaar eKYC error:", error);
    return NextResponse.json(
      {
        success: false,
        error: error.message || "Failed to process Aadhaar eKYC",
      },
      { status: 500 }
    );
  }
}
