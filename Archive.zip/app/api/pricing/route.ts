import { NextResponse } from "next/server";

export async function GET() {
  const pricingPlans = [
    {
      name: "Email Verification",
      price: 2,
    },
    {
      name: "Phone Verification",
      price: 3,
    },
    {
      name: "Aadhar Verification",
      price: 5,
    },
    {
      name: "PAN Verification",
      price: 5,
    },
    {
      name: "Driving License Verification",
      price: 8,
    },
    {
      name: "Passport Verification",
      price: 10,
    },
    {
      name: "GST Verification",
      price: 7,
    },
    {
      name: "Bank Account Verification",
      price: 6,
    },
    {
      name: "Voter ID Verification",
      price: 5,
    },
  ];

  return NextResponse.json({ pricingPlans }, { status: 200 });
}
