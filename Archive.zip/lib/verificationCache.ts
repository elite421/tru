import { query } from "@/db/db";

export type CacheResult<T> = {
  data: T;
  cacheHit: boolean;
};

/**
 * Check if verification data exists in cache
 */
export async function checkCache<T>(
  verificationType: string,
  verificationKey: string
): Promise<T | null> {
  try {
    const cacheKey = verificationKey.toUpperCase().trim();
    const result = await query(
      "SELECT verification_data FROM verification_cache WHERE verification_type = $1 AND verification_key = $2",
      [verificationType, cacheKey]
    );

    if (result.rows.length > 0) {
      // Update access statistics
      await query(
        "UPDATE verification_cache SET access_count = access_count + 1, last_accessed_at = CURRENT_TIMESTAMP WHERE verification_type = $1 AND verification_key = $2",
        [verificationType, cacheKey]
      );

      return result.rows[0].verification_data as T;
    }

    return null;
  } catch (error) {
    console.error(`[Cache] Error checking cache for ${verificationType}:`, error);
    return null;
  }
}

/**
 * Store verification data in cache
 */
export async function storeInCache(
  verificationType: string,
  verificationKey: string,
  verificationData: any,
  deepvueTransactionId?: string
): Promise<void> {
  try {
    const cacheKey = verificationKey.toUpperCase().trim();
    await query(
      `INSERT INTO verification_cache (verification_type, verification_key, verification_data, deepvue_transaction_id) 
       VALUES ($1, $2, $3, $4) 
       ON CONFLICT (verification_type, verification_key) 
       DO UPDATE SET 
         verification_data = $3,
         deepvue_transaction_id = $4,
         last_accessed_at = CURRENT_TIMESTAMP,
         access_count = verification_cache.access_count + 1`,
      [verificationType, cacheKey, JSON.stringify(verificationData), deepvueTransactionId]
    );
    console.log(`[Cache] Stored ${verificationType} verification for key: ${cacheKey} with transaction ID: ${deepvueTransactionId}`);
  } catch (error) {
    console.error(`[Cache] Error storing cache for ${verificationType}:`, error);
    // Don't throw - caching is optional
  }
}

/**
 * Get cached data or fetch from API
 */
export async function getCachedOrFetch<T>(
  verificationType: string,
  verificationKey: string,
  fetchFunction: () => Promise<T>
): Promise<CacheResult<T>> {
  // Try cache first
  const cachedData = await checkCache<T>(verificationType, verificationKey);
  
  if (cachedData) {
    console.log(`[Cache] Cache HIT for ${verificationType}: ${verificationKey}`);
    return { data: cachedData, cacheHit: true };
  }

  // Cache miss - fetch from API
  console.log(`[Cache] Cache MISS for ${verificationType}: ${verificationKey} - Fetching from API`);
  const freshData = await fetchFunction();

  // Extract DeepVue transaction ID from response if available
  const deepvueTransactionId = (freshData as any)?.transaction_id || 
                                (freshData as any)?.decentro_transaction_id || 
                                (freshData as any)?.reference_id;

  // Store in cache for future requests
  await storeInCache(verificationType, verificationKey, freshData, deepvueTransactionId);

  return { data: freshData, cacheHit: false };
}

/**
 * Clear cache for specific verification
 */
export async function clearCache(
  verificationType: string,
  verificationKey: string
): Promise<void> {
  try {
    const cacheKey = verificationKey.toUpperCase().trim();
    await query(
      "DELETE FROM verification_cache WHERE verification_type = $1 AND verification_key = $2",
      [verificationType, cacheKey]
    );
    console.log(`[Cache] Cleared cache for ${verificationType}: ${cacheKey}`);
  } catch (error) {
    console.error(`[Cache] Error clearing cache:`, error);
  }
}

/**
 * Clear old cache entries (older than specified days)
 */
export async function clearOldCache(daysOld: number = 30): Promise<number> {
  try {
    const result = await query(
      "DELETE FROM verification_cache WHERE last_accessed_at < NOW() - INTERVAL '$1 days'",
      [daysOld]
    );
    console.log(`[Cache] Cleared ${result.rowCount} old cache entries`);
    return result.rowCount || 0;
  } catch (error) {
    console.error(`[Cache] Error clearing old cache:`, error);
    return 0;
  }
}

/**
 * Get cache statistics
 */
export async function getCacheStats() {
  try {
    const stats = await query(`
      SELECT 
        verification_type,
        COUNT(*) as total_entries,
        SUM(access_count) as total_accesses,
        AVG(access_count) as avg_access_count,
        MAX(last_accessed_at) as most_recent_access
      FROM verification_cache
      GROUP BY verification_type
    `);

    return stats.rows;
  } catch (error) {
    console.error(`[Cache] Error getting cache stats:`, error);
    return [];
  }
}
