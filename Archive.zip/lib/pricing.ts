import { query } from "@/db/db";

// Default pricing rates (used when user has no custom plan)
const DEFAULT_RATES: Record<string, number> = {
  "pan": 5,
  "pan-plus": 7,
  "aadhaar-ekyc": 8,
  "driving-license": 8,
  "rc": 7,
  "bank-account": 6,
  "ifsc": 2,
  "upi": 4,
  "upi-advanced": 6,
  "credit-report": 50,
  "gst": 7,
  "gst-advanced": 10,
  "gstin-by-pan": 6,
  "track-gstr": 8,
  "cin": 8,
  "din": 8,
  "tan": 5,
  "tds-compliance": 7,
  "mobile-number": 3,
  "mobile-to-name": 5,
  "mobile-to-email": 5,
  "mobile-intelligence": 8,
  "email-validation": 2,
  "email": 2,
  "phone": 3,
  "aadhar": 8,
  "passport": 10,
  "voter-id": 7,
};

/**
 * Get the price for a specific verification type for a user
 * @param userId - The user's ID
 * @param verificationType - The type of verification (e.g., 'pan', 'gst', 'aadhaar-ekyc')
 * @returns The price for the verification, or null if not found
 */
export async function getUserVerificationPrice(
  userId: string | number,
  verificationType: string
): Promise<number | null> {
  try {
    // Get user's pricing plan
    const userResult = await query(
      "SELECT pricing_plan_id, plan_expires_at FROM users WHERE id = $1",
      [userId]
    );

    if (userResult.rows.length === 0) {
      return null;
    }

    const user = userResult.rows[0];
    let pricingPlanId = user.pricing_plan_id;

    // Check if plan is expired
    if (pricingPlanId && user.plan_expires_at) {
      const expiryDate = new Date(user.plan_expires_at);
      if (expiryDate < new Date()) {
        // Plan expired, use default pricing
        pricingPlanId = null;
      }
    }

    // If user has a custom plan, get price from that plan
    if (pricingPlanId) {
      const priceResult = await query(
        "SELECT price FROM pricing_plan_rates WHERE pricing_plan_id = $1 AND verification_type = $2",
        [pricingPlanId, verificationType]
      );

      if (priceResult.rows.length > 0) {
        return parseFloat(priceResult.rows[0].price);
      }
    }

    // Otherwise, get default pricing
    const defaultPlanResult = await query(
      "SELECT id FROM pricing_plans WHERE is_default = true AND is_active = true LIMIT 1"
    );

    if (defaultPlanResult.rows.length > 0) {
      const defaultPlanId = defaultPlanResult.rows[0].id;
      const defaultPriceResult = await query(
        "SELECT price FROM pricing_plan_rates WHERE pricing_plan_id = $1 AND verification_type = $2",
        [defaultPlanId, verificationType]
      );

      if (defaultPriceResult.rows.length > 0) {
        return parseFloat(defaultPriceResult.rows[0].price);
      }
    }

    return null;
  } catch (error) {
    console.error("Error getting user verification price:", error);
    return null;
  }
}

/**
 * Get all verification prices for a user
 * @param userId - The user's ID
 * @returns A map of verification types to prices
 */
export async function getUserAllVerificationPrices(
  userId: string | number
): Promise<Record<string, number>> {
  try {
    const prices: Record<string, number> = {};

    // Get user's pricing plan
    const userResult = await query(
      "SELECT pricing_plan_id, plan_expires_at FROM users WHERE id = $1",
      [userId]
    );

    if (userResult.rows.length === 0) {
      return prices;
    }

    const user = userResult.rows[0];
    let pricingPlanId = user.pricing_plan_id;

    // Check if plan is expired
    if (pricingPlanId && user.plan_expires_at) {
      const expiryDate = new Date(user.plan_expires_at);
      if (expiryDate < new Date()) {
        pricingPlanId = null;
      }
    }

    if (pricingPlanId) {
      // User has a custom pricing plan
      const ratesResult = await query(
        "SELECT verification_type, price FROM pricing_plan_rates WHERE pricing_plan_id = $1",
        [pricingPlanId]
      );

      ratesResult.rows.forEach((row) => {
        prices[row.verification_type] = parseFloat(row.price);
      });
    }

    // Get default pricing for any missing types
    const defaultPlanResult = await query(
      "SELECT id FROM pricing_plans WHERE is_default = true AND is_active = true LIMIT 1"
    );

    if (defaultPlanResult.rows.length > 0) {
      const defaultPlanId = defaultPlanResult.rows[0].id;
      const defaultRatesResult = await query(
        "SELECT verification_type, price FROM pricing_plan_rates WHERE pricing_plan_id = $1",
        [defaultPlanId]
      );

      defaultRatesResult.rows.forEach((row) => {
        // Only add if not already present from custom plan
        if (!prices[row.verification_type]) {
          prices[row.verification_type] = parseFloat(row.price);
        }
      });
    }

    return prices;
  } catch (error) {
    console.error("Error getting user verification prices:", error);
    return {};
  }
}

/**
 * Get the verification cost for a user based on their pricing plan
 * @param userId - The user's ID
 * @param verificationType - The type of verification (e.g., 'pan', 'gst', 'email')
 * @returns The cost in rupees
 */
export async function getVerificationCost(
  userId: string | number,
  verificationType: string
): Promise<number> {
  try {
    // Get user's pricing plan
    const userResult = await query(
      `SELECT 
        u.pricing_plan_id,
        u.plan_expires_at,
        pp.is_active
       FROM users u
       LEFT JOIN pricing_plans pp ON u.pricing_plan_id = pp.id
       WHERE u.id = $1`,
      [userId]
    );

    // If user not found or no plan assigned, use default rate
    if (userResult.rows.length === 0 || !userResult.rows[0].pricing_plan_id) {
      return DEFAULT_RATES[verificationType] || 10;
    }

    const user = userResult.rows[0];

    // Check if plan is expired
    if (user.plan_expires_at) {
      const expiryDate = new Date(user.plan_expires_at);
      const now = new Date();
      if (expiryDate < now) {
        // Plan expired, use default rate
        return DEFAULT_RATES[verificationType] || 10;
      }
    }

    // Check if plan is active
    if (!user.is_active) {
      return DEFAULT_RATES[verificationType] || 10;
    }

    // Get custom rate from plan
    const rateResult = await query(
      `SELECT price FROM pricing_plan_rates 
       WHERE pricing_plan_id = $1 AND verification_type = $2`,
      [user.pricing_plan_id, verificationType]
    );

    if (rateResult.rows.length > 0) {
      return parseFloat(rateResult.rows[0].price);
    }

    // If custom plan doesn't have this verification type, use default
    return DEFAULT_RATES[verificationType] || 10;
  } catch (error) {
    console.error("Error getting verification cost:", error);
    // On error, return default rate
    return DEFAULT_RATES[verificationType] || 10;
  }
}

/**
 * Get all verification costs for a user (useful for displaying pricing tables)
 * @param userId - The user's ID
 * @returns Object mapping verification types to their costs
 */
export async function getAllVerificationCosts(
  userId: string | number
): Promise<Record<string, number>> {
  try {
    const userResult = await query(
      `SELECT 
        u.pricing_plan_id,
        u.plan_expires_at,
        pp.is_active
       FROM users u
       LEFT JOIN pricing_plans pp ON u.pricing_plan_id = pp.id
       WHERE u.id = $1`,
      [userId]
    );

    // If user not found or no plan assigned, use default rates
    if (userResult.rows.length === 0 || !userResult.rows[0].pricing_plan_id) {
      return DEFAULT_RATES;
    }

    const user = userResult.rows[0];

    // Check if plan is expired or inactive
    if (user.plan_expires_at) {
      const expiryDate = new Date(user.plan_expires_at);
      const now = new Date();
      if (expiryDate < now || !user.is_active) {
        return DEFAULT_RATES;
      }
    }

    // Get custom rates from plan
    const ratesResult = await query(
      `SELECT verification_type, price FROM pricing_plan_rates 
       WHERE pricing_plan_id = $1`,
      [user.pricing_plan_id]
    );

    // Start with default rates and override with custom rates
    const rates: Record<string, number> = { ...DEFAULT_RATES };
    
    ratesResult.rows.forEach(row => {
      rates[row.verification_type] = parseFloat(row.price);
    });

    return rates;
  } catch (error) {
    console.error("Error getting all verification costs:", error);
    return DEFAULT_RATES;
  }
}

/**
 * Get default pricing rates
 * @returns Object mapping verification types to their default costs
 */
export function getDefaultRates(): Record<string, number> {
  return { ...DEFAULT_RATES };
}
