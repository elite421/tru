import { FaFacebook, FaTwitter, FaInstagram, FaLinkedin } from "react-icons/fa";
import { Button } from "@/component/ui/button";

export default function Footer() {
  return (
    <footer className="bg-zinc-900 text-gray-300 py-10 px-6">
      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-10 border-b border-zinc-700 pb-8">
        {/* Column 1: Logo / Brand */}
        <div>
          <h2 className="text-2xl font-bold text-white mb-3">TruVerify</h2>
          <p className="text-sm text-gray-400">
            Empowering trust through verification.  
            Reliable, secure, and efficient.
          </p>
        </div>

        {/* Column 2: Quick Links */}
        <div>
          <h3 className="text-lg font-semibold text-white mb-3">Quick Links</h3>
          <ul className="space-y-2 text-sm">
            <li><a href="/" className="hover:text-white transition">Dashboard</a></li>
            <li><a href="/features" className="hover:text-white transition">Features</a></li>
            <li><a href="/pricing" className="hover:text-white transition">Pricing</a></li>
            <li><a href="/contact" className="hover:text-white transition">Contact</a></li>
          </ul>
        </div>

        {/* Column 3: Resources */}
        <div>
          <h3 className="text-lg font-semibold text-white mb-3">Resources</h3>
          <ul className="space-y-2 text-sm">
            <li><a href="/help" className="hover:text-white transition">Help Center</a></li>
            <li><a href="/security" className="hover:text-white transition">Security & Compliance</a></li>
            <li><a href="/privacy" className="hover:text-white transition">Privacy Policy</a></li>
            <li><a href="/terms" className="hover:text-white transition">Terms of Service</a></li>
          </ul>
        </div>

        {/* Column 4: Social Media */}
        <div>
          <h3 className="text-lg font-semibold text-white mb-3">Follow Us</h3>
          <div className="flex items-center gap-3 mb-4">
            <Button variant="outline" className="p-2 rounded-full border-gray-600 hover:bg-gray-700">
              <FaFacebook size={18} />
            </Button>
            <Button variant="outline" className="p-2 rounded-full border-gray-600 hover:bg-gray-700">
              <FaTwitter size={18} />
            </Button>
            <Button variant="outline" className="p-2 rounded-full border-gray-600 hover:bg-gray-700">
              <FaInstagram size={18} />
            </Button>
            <Button variant="outline" className="p-2 rounded-full border-gray-600 hover:bg-gray-700">
              <FaLinkedin size={18} />
            </Button>
          </div>
          <p className="text-sm text-gray-400">Stay connected with us!</p>
        </div>
      </div>

      {/* Copyright Section */}
      <div className="mt-6 text-center text-gray-500 text-sm">
        © {new Date().getFullYear()} TruVerify. All rights reserved.
      </div>
    </footer>
  );
}
