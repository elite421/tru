"use client"

import { createContext, useContext, useState, ReactNode } from "react"
import Alert, { AlertType } from "./ui/alert"

interface AlertMessage {
  id: string
  type: AlertType
  title?: string
  message: string
  duration?: number
}

interface AlertContextType {
  showAlert: (type: AlertType, message: string, title?: string, duration?: number) => void
  success: (message: string, title?: string) => void
  error: (message: string, title?: string) => void
  warning: (message: string, title?: string) => void
  info: (message: string, title?: string) => void
}

const AlertContext = createContext<AlertContextType | undefined>(undefined)

export function AlertProvider({ children }: { children: ReactNode }) {
  const [alerts, setAlerts] = useState<AlertMessage[]>([])

  const showAlert = (
    type: AlertType,
    message: string,
    title?: string,
    duration: number = 5000
  ) => {
    const id = Math.random().toString(36).substring(7)
    const newAlert: AlertMessage = { id, type, message, title, duration }
    
    setAlerts(prev => [...prev, newAlert])
  }

  const removeAlert = (id: string) => {
    setAlerts(prev => prev.filter(alert => alert.id !== id))
  }

  const success = (message: string, title?: string) => {
    showAlert("success", message, title)
  }

  const error = (message: string, title?: string) => {
    showAlert("error", message, title)
  }

  const warning = (message: string, title?: string) => {
    showAlert("warning", message, title)
  }

  const info = (message: string, title?: string) => {
    showAlert("info", message, title)
  }

  return (
    <AlertContext.Provider value={{ showAlert, success, error, warning, info }}>
      {children}
      
      {/* Alert Container */}
      <div className="fixed top-4 right-4 z-[9999] space-y-3 max-w-md w-full pointer-events-none">
        <div className="space-y-3 pointer-events-auto">
          {alerts.map(alert => (
            <Alert
              key={alert.id}
              type={alert.type}
              title={alert.title}
              message={alert.message}
              duration={alert.duration}
              onClose={() => removeAlert(alert.id)}
            />
          ))}
        </div>
      </div>
    </AlertContext.Provider>
  )
}

export function useAlert() {
  const context = useContext(AlertContext)
  if (!context) {
    throw new Error("useAlert must be used within AlertProvider")
  }
  return context
}
