"use client"

import { useRouter } from "next/navigation"
import { ArrowRight } from "lucide-react"

interface CardProps {
  title: string
  description: string
  buttonText?: string
  placeholder?: string
  price?: number
  verificationType?: string
}

export default function Card({
  title,
  description,
  price,
  verificationType,
}: CardProps) {
  const router = useRouter()

  const handleCardClick = () => {
    // Navigate directly to verification page (no login required)
    if (verificationType) {
      router.push(`/verify/${verificationType}`)
    }
  }

  return (
    <div 
      onClick={handleCardClick}
      className="relative bg-white dark:bg-zinc-900 shadow-lg rounded-2xl overflow-visible border border-gray-200 dark:border-zinc-800 transition-all transform hover:-translate-y-2 hover:shadow-2xl w-full p-6 cursor-pointer group"
    >
      <div className="flex items-start justify-between mb-3">
        <h3 className="text-xl font-semibold text-gray-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors">
          {title}
        </h3>
        <ArrowRight className="w-5 h-5 text-gray-400 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-all group-hover:translate-x-1" />
      </div>
      
      <p className="text-sm text-gray-600 dark:text-gray-300 mb-4">{description}</p>

      {/* Price */}
      {price && (
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-200 dark:border-zinc-700">
          <span className="text-sm text-gray-500 dark:text-gray-400">Price per verification</span>
          <span className="font-bold text-xl text-indigo-600 dark:text-indigo-400">₹{price}</span>
        </div>
      )}

      {/* Hover Indicator */}
      <div className="mt-4 flex items-center gap-2 text-indigo-600 dark:text-indigo-400 font-medium text-sm opacity-0 group-hover:opacity-100 transition-opacity">
        <span>Click to verify</span>
        <ArrowRight className="w-4 h-4" />
      </div>
    </div>
  )
}
