-- Quick Setup: Verification Cache and History Tables
-- Run this script to fix database errors related to verification tables
-- Execute: psql -U postgres -d your_database_name -f scripts/setup-cache.sql

-- ============================================
-- 1. VERIFICATION CACHE TABLE
-- ============================================
-- This table stores cached verification results to reduce API calls

CREATE TABLE IF NOT EXISTS verification_cache (
    id SERIAL PRIMARY KEY,
    verification_type VARCHAR(100) NOT NULL,
    verification_key VARCHAR(500) NOT NULL,
    verification_data JSONB NOT NULL,
    first_verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_accessed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    access_count INTEGER DEFAULT 1,
    UNIQUE(verification_type, verification_key)
);

-- Create indexes for verification_cache
CREATE INDEX IF NOT EXISTS idx_verification_cache_lookup 
ON verification_cache(verification_type, verification_key);

CREATE INDEX IF NOT EXISTS idx_verification_cache_type 
ON verification_cache(verification_type);

CREATE INDEX IF NOT EXISTS idx_verification_cache_accessed 
ON verification_cache(last_accessed_at);

-- Add comments for verification_cache
COMMENT ON TABLE verification_cache IS 'Stores cached verification results to reduce API calls and costs';
COMMENT ON COLUMN verification_cache.verification_type IS 'Type of verification: pan, aadhar, rc, gst, etc.';
COMMENT ON COLUMN verification_cache.verification_key IS 'Unique identifier for the verification (e.g., PAN number, RC number)';
COMMENT ON COLUMN verification_cache.verification_data IS 'Complete verification response data in JSON format';
COMMENT ON COLUMN verification_cache.access_count IS 'Number of times this cached data has been accessed';

-- ============================================
-- 2. VERIFICATION HISTORY TABLE
-- ============================================
-- This table stores a log of all verification requests made by users

CREATE TABLE IF NOT EXISTS verification_history (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    verification_type VARCHAR(100) NOT NULL,
    status VARCHAR(50) NOT NULL,
    details JSONB,
    amount_charged DECIMAL(10, 2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for verification_history
CREATE INDEX IF NOT EXISTS idx_verification_history_user_id 
ON verification_history(user_id);

CREATE INDEX IF NOT EXISTS idx_verification_history_type 
ON verification_history(verification_type);

CREATE INDEX IF NOT EXISTS idx_verification_history_created_at 
ON verification_history(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_verification_history_status 
ON verification_history(status);

-- Add comments for verification_history
COMMENT ON TABLE verification_history IS 'Stores historical log of all verification requests';
COMMENT ON COLUMN verification_history.user_id IS 'ID of the user who requested the verification';
COMMENT ON COLUMN verification_history.verification_type IS 'Type of verification performed';
COMMENT ON COLUMN verification_history.status IS 'Status: completed, failed, pending';
COMMENT ON COLUMN verification_history.details IS 'Full verification response data';
COMMENT ON COLUMN verification_history.amount_charged IS 'Amount charged for this verification';

-- ============================================
-- 3. VERIFICATION REQUESTS TABLE (if not exists)
-- ============================================
-- Main table for tracking verification requests with detailed status

CREATE TABLE IF NOT EXISTS verification_requests (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    verification_type VARCHAR(50) NOT NULL,
    document_number VARCHAR(100) DEFAULT '',
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    cost DECIMAL(10, 2) DEFAULT 0,
    request_data JSONB,
    response_data JSONB,
    verification_data JSONB,
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    verified_at TIMESTAMP,
    expires_at TIMESTAMP
);

-- Create indexes for verification_requests
CREATE INDEX IF NOT EXISTS idx_verification_requests_user_id 
ON verification_requests(user_id);

CREATE INDEX IF NOT EXISTS idx_verification_requests_status 
ON verification_requests(status);

CREATE INDEX IF NOT EXISTS idx_verification_requests_type 
ON verification_requests(verification_type);

CREATE INDEX IF NOT EXISTS idx_verification_requests_created_at 
ON verification_requests(created_at DESC);

-- ============================================
-- 4. TRANSACTIONS TABLE (if not exists)
-- ============================================
-- Tracks all successful verifications for reporting

CREATE TABLE IF NOT EXISTS transactions (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    verification_type VARCHAR(100) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) DEFAULT 'success',
    cache_hit BOOLEAN DEFAULT false,
    details JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for transactions
CREATE INDEX IF NOT EXISTS idx_transactions_user 
ON transactions(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_transactions_status 
ON transactions(status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_transactions_cache_hit 
ON transactions(cache_hit);

-- ============================================
-- VERIFY SETUP
-- ============================================

SELECT 'verification_cache table created successfully!' as status;
SELECT COUNT(*) as verification_cache_count FROM verification_cache;

SELECT 'verification_history table created successfully!' as status;
SELECT COUNT(*) as verification_history_count FROM verification_history;

SELECT 'verification_requests table created successfully!' as status;
SELECT COUNT(*) as verification_requests_count FROM verification_requests;

SELECT 'transactions table created successfully!' as status;
SELECT COUNT(*) as transactions_count FROM transactions;

SELECT '✅ All verification tables are ready!' as final_status;
