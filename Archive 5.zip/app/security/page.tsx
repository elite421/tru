"use client"

import { Shield, Lock, Eye, Server, CheckCircle, Award, FileText, AlertTriangle, Key, Database, RefreshCw, Fingerprint } from "lucide-react"

export default function SecurityCompliancePage() {
  const securityFeatures = [
    {
      icon: <Lock className="w-8 h-8" />,
      title: "256-bit SSL/TLS Encryption",
      description: "All data transmissions are protected with industry-standard SSL/TLS encryption, ensuring your data remains secure in transit."
    },
    {
      icon: <Database className="w-8 h-8" />,
      title: "AES-256 Data Encryption",
      description: "Sensitive data at rest is encrypted using AES-256 encryption, providing military-grade protection for stored information."
    },
    {
      icon: <Key className="w-8 h-8" />,
      title: "API Key Authentication",
      description: "Secure API key-based authentication with encrypted storage and instant regeneration capabilities for compromised keys."
    },
    {
      icon: <Eye className="w-8 h-8" />,
      title: "Access Control & Monitoring",
      description: "Strict role-based access controls with comprehensive audit logging. All data access is monitored and logged for security."
    },
    {
      icon: <Server className="w-8 h-8" />,
      title: "Secure Infrastructure",
      description: "Hosted on ISO 27001 certified data centers in India with 24/7 monitoring, redundancy, and disaster recovery protocols."
    },
    {
      icon: <RefreshCw className="w-8 h-8" />,
      title: "Regular Security Audits",
      description: "Continuous security assessments, penetration testing, and vulnerability scanning by third-party security experts."
    }
  ]

  const certifications = [
    {
      icon: <Award className="w-12 h-12" />,
      title: "ISO 27001 Certified",
      description: "Information Security Management System certification ensuring highest security standards.",
      badge: "ISO/IEC 27001:2013"
    },
    {
      icon: <Shield className="w-12 h-12" />,
      title: "GDPR Compliant",
      description: "Full compliance with General Data Protection Regulation for European data protection.",
      badge: "GDPR 2016/679"
    },
    {
      icon: <FileText className="w-12 h-12" />,
      title: "Indian IT Act Compliance",
      description: "Adherence to Information Technology Act, 2000 and associated data protection rules.",
      badge: "IT Act 2000"
    },
    {
      icon: <CheckCircle className="w-12 h-12" />,
      title: "SOC 2 Type II",
      description: "Service Organization Control compliance demonstrating security, availability, and confidentiality.",
      badge: "SOC 2 Type II"
    }
  ]

  const dataProtection = [
    {
      title: "Data Minimization",
      description: "We collect only the data necessary to provide verification services. No unnecessary information is stored."
    },
    {
      title: "Purpose Limitation",
      description: "Data is used exclusively for verification purposes and is never repurposed without explicit consent."
    },
    {
      title: "Storage Limitation",
      description: "Data is retained only as long as necessary or required by law (7 years for compliance records)."
    },
    {
      title: "Integrity & Confidentiality",
      description: "We implement technical and organizational measures to ensure data accuracy and prevent unauthorized access."
    },
    {
      title: "Accountability",
      description: "We maintain comprehensive records of data processing activities and compliance measures."
    }
  ]

  const incidentResponse = [
    {
      step: "1",
      title: "Detection & Analysis",
      description: "24/7 monitoring systems detect security incidents. Our team immediately analyzes the threat scope and impact."
    },
    {
      step: "2",
      title: "Containment",
      description: "Affected systems are isolated to prevent spread. Critical services continue operating on secure infrastructure."
    },
    {
      step: "3",
      title: "Eradication & Recovery",
      description: "Threats are eliminated, vulnerabilities patched, and systems restored from secure backups."
    },
    {
      step: "4",
      title: "Communication",
      description: "Affected users are notified within 72 hours as required by regulations. Transparent updates are provided."
    },
    {
      step: "5",
      title: "Post-Incident Review",
      description: "Comprehensive analysis to prevent recurrence. Security measures are enhanced based on learnings."
    }
  ]

  const bestPractices = [
    {
      icon: <Fingerprint className="w-6 h-6" />,
      title: "For Developers",
      tips: [
        "Store API keys in environment variables or secrets managers",
        "Never commit API keys to version control systems",
        "Implement rate limiting on your application side",
        "Use HTTPS for all API communications",
        "Rotate API keys periodically (every 90 days recommended)"
      ]
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: "For Organizations",
      tips: [
        "Implement principle of least privilege for user access",
        "Enable two-factor authentication for all team members",
        "Conduct regular security training for employees",
        "Maintain an inventory of all API integrations",
        "Review and audit access logs monthly"
      ]
    }
  ]

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-12 text-center">
          <div className="inline-block bg-blue-100 dark:bg-blue-900/30 rounded-full px-6 py-2 mb-6">
            <span className="text-blue-600 dark:text-blue-400 font-semibold">🔒 Bank-Grade Security</span>
          </div>
          <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent mb-4">
            Security & Compliance
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Your trust is our priority. Learn about our comprehensive security measures and compliance certifications.
          </p>
        </div>

        {/* Security Features */}
        <section className="mb-16">
          <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-8 text-center">
            Enterprise-Grade Security Features
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {securityFeatures.map((feature, index) => (
              <div 
                key={index}
                className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 border-2 border-gray-100 dark:border-gray-700"
              >
                <div className="bg-blue-100 dark:bg-blue-900/30 rounded-xl p-3 text-blue-600 dark:text-blue-400 w-fit mb-4">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                  {feature.description}
                </p>
              </div>
            ))}
          </div>
        </section>

        {/* Certifications */}
        <section className="mb-16">
          <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-8 text-center">
            Certifications & Compliance
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {certifications.map((cert, index) => (
              <div 
                key={index}
                className="bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-gray-800 dark:to-gray-700 rounded-2xl shadow-xl p-8 border-2 border-blue-200 dark:border-blue-800"
              >
                <div className="flex items-start gap-6">
                  <div className="text-blue-600 dark:text-blue-400">
                    {cert.icon}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-3">
                      <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                        {cert.title}
                      </h3>
                      <span className="bg-blue-600 text-white px-3 py-1 rounded-full text-xs font-bold whitespace-nowrap ml-2">
                        {cert.badge}
                      </span>
                    </div>
                    <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
                      {cert.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Data Protection Principles */}
        <section className="mb-16">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8">
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-8 text-center">
              Data Protection Principles
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {dataProtection.map((principle, index) => (
                <div key={index} className="flex items-start gap-4">
                  <CheckCircle className="w-6 h-6 text-green-600 dark:text-green-400 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                      {principle.title}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      {principle.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Incident Response */}
        <section className="mb-16">
          <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-8 text-center">
            Security Incident Response
          </h2>
          <div className="bg-gradient-to-br from-red-50 to-orange-50 dark:from-gray-800 dark:to-gray-700 rounded-2xl shadow-xl p-8">
            <div className="flex items-start gap-3 mb-6">
              <AlertTriangle className="w-6 h-6 text-orange-600 dark:text-orange-400" />
              <p className="text-gray-700 dark:text-gray-300">
                In the unlikely event of a security incident, our dedicated response team follows a structured protocol:
              </p>
            </div>
            <div className="space-y-4">
              {incidentResponse.map((phase, index) => (
                <div 
                  key={index}
                  className="bg-white dark:bg-gray-800 rounded-xl p-6 flex items-start gap-4"
                >
                  <div className="bg-gradient-to-br from-orange-500 to-red-500 text-white rounded-full w-12 h-12 flex items-center justify-center font-bold text-xl flex-shrink-0">
                    {phase.step}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
                      {phase.title}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      {phase.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Best Practices */}
        <section className="mb-16">
          <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-8 text-center">
            Security Best Practices
          </h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {bestPractices.map((guide, index) => (
              <div 
                key={index}
                className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8"
              >
                <div className="flex items-center gap-3 mb-6">
                  <div className="bg-purple-100 dark:bg-purple-900/30 rounded-xl p-3 text-purple-600 dark:text-purple-400">
                    {guide.icon}
                  </div>
                  <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                    {guide.title}
                  </h3>
                </div>
                <ul className="space-y-3">
                  {guide.tips.map((tip, tipIndex) => (
                    <li key={tipIndex} className="flex items-start gap-3">
                      <CheckCircle className="w-5 h-5 text-purple-600 dark:text-purple-400 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-600 dark:text-gray-400">{tip}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </section>

        {/* Security Contact */}
        <section className="mb-16">
          <div className="bg-gradient-to-r from-blue-600 to-cyan-600 rounded-2xl shadow-2xl p-8 text-white">
            <div className="text-center">
              <Shield className="w-16 h-16 mx-auto mb-4" />
              <h2 className="text-3xl font-bold mb-4">Report a Security Issue</h2>
              <p className="text-xl text-white/90 mb-6 max-w-2xl mx-auto">
                We take security seriously. If you discover a security vulnerability, please report it responsibly.
              </p>
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6 max-w-2xl mx-auto">
                <div className="space-y-3 text-left">
                  <p className="flex items-center gap-2">
                    <span className="font-semibold">Security Email:</span> security@truverify.com
                  </p>
                  <p className="flex items-center gap-2">
                    <span className="font-semibold">Response Time:</span> Within 24 hours for critical issues
                  </p>
                  <p className="flex items-center gap-2">
                    <span className="font-semibold">PGP Key:</span> Available on request for encrypted communication
                  </p>
                </div>
              </div>
              <p className="mt-6 text-white/80 text-sm">
                We appreciate responsible disclosure and may offer rewards for valid security reports.
              </p>
            </div>
          </div>
        </section>

        {/* Trust Indicators */}
        <section>
          <div className="bg-gray-900 dark:bg-gray-800 rounded-2xl shadow-xl p-8">
            <h2 className="text-3xl font-bold text-white mb-8 text-center">Security by the Numbers</h2>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
              <div>
                <div className="text-4xl font-bold bg-gradient-to-r from-green-400 to-emerald-500 bg-clip-text text-transparent mb-2">
                  99.9%
                </div>
                <div className="text-gray-400">Uptime SLA</div>
              </div>
              <div>
                <div className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-cyan-500 bg-clip-text text-transparent mb-2">
                  256-bit
                </div>
                <div className="text-gray-400">Encryption</div>
              </div>
              <div>
                <div className="text-4xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent mb-2">
                  24/7
                </div>
                <div className="text-gray-400">Monitoring</div>
              </div>
              <div>
                <div className="text-4xl font-bold bg-gradient-to-r from-orange-400 to-red-500 bg-clip-text text-transparent mb-2">
                  &lt;72h
                </div>
                <div className="text-gray-400">Incident Response</div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}
