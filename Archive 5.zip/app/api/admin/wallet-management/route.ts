import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";
import { logger } from "@/lib/logger";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, action, amount, reason } = body;

    if (!userId || !action || !amount) {
      return NextResponse.json(
        { success: false, error: "User ID, action, and amount are required" },
        { status: 400 }
      );
    }

    if (amount <= 0) {
      return NextResponse.json(
        { success: false, error: "Amount must be greater than 0" },
        { status: 400 }
      );
    }

    // Get wallet
    const walletResult = await query(
      "SELECT * FROM wallets WHERE user_id = $1",
      [userId]
    );

    if (walletResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "Wallet not found" },
        { status: 404 }
      );
    }

    const wallet = walletResult.rows[0];
    const currentBalance = parseFloat(wallet.balance);
    let newBalance;
    let transactionType;
    let description;

    if (action === "add") {
      newBalance = currentBalance + parseFloat(amount);
      transactionType = "credit";
      description = `Admin credit: ${reason || "Manual balance adjustment"}`;
    } else if (action === "deduct") {
      if (currentBalance < parseFloat(amount)) {
        return NextResponse.json(
          { success: false, error: "Insufficient balance to deduct" },
          { status: 400 }
        );
      }
      newBalance = currentBalance - parseFloat(amount);
      transactionType = "debit";
      description = `Admin debit: ${reason || "Manual balance adjustment"}`;
    } else {
      return NextResponse.json(
        { success: false, error: "Invalid action. Use 'add' or 'deduct'" },
        { status: 400 }
      );
    }

    // Update wallet balance
    await query(
      "UPDATE wallets SET balance = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2",
      [newBalance, wallet.id]
    );

    // Create transaction record
    await query(
      `INSERT INTO wallet_transactions 
       (wallet_id, user_id, transaction_type, amount, balance_before, balance_after, description, reference_type, status) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
      [
        wallet.id,
        userId,
        transactionType,
        amount,
        currentBalance,
        newBalance,
        description,
        "admin_adjustment",
        "completed"
      ]
    );

    // Log the action
    await logger.warning(
      "admin_wallet",
      `Admin ${action}ed ₹${amount} ${action === "add" ? "to" : "from"} user ${userId} wallet`,
      { user_id: userId, action, amount, reason, old_balance: currentBalance, new_balance: newBalance },
      userId
    );

    return NextResponse.json({
      success: true,
      message: `Successfully ${action}ed ₹${amount}`,
      newBalance,
      previousBalance: currentBalance
    });
  } catch (error: any) {
    console.error("Wallet management error:", error);
    await logger.error(
      "admin_wallet",
      `Wallet management error: ${error.message}`,
      { error: error.message, stack: error.stack }
    );
    return NextResponse.json(
      { success: false, error: error.message || "Failed to update wallet" },
      { status: 500 }
    );
  }
}
