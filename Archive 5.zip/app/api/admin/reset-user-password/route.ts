import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";
import bcrypt from "bcryptjs";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, newPassword } = body;

    if (!userId || !newPassword) {
      return NextResponse.json(
        { success: false, error: "User ID and new password are required" },
        { status: 400 }
      );
    }

    // Validate password length
    if (newPassword.length < 6) {
      return NextResponse.json(
        { success: false, error: "Password must be at least 6 characters" },
        { status: 400 }
      );
    }

    // Check if user exists
    const userResult = await query(
      "SELECT id, email, full_name FROM users WHERE id = $1",
      [userId]
    );

    if (userResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "User not found" },
        { status: 404 }
      );
    }

    const user = userResult.rows[0];

    // Hash the new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Update user password
    await query(
      "UPDATE users SET password = $1, updated_at = NOW() WHERE id = $2",
      [hashedPassword, userId]
    );

    // Log admin action for security audit (production-safe)
    const logMessage = `[ADMIN ACTION] Password reset for user: ${user.email} (ID: ${userId})`;
    console.log(logMessage);
    
    // TODO: In production, also log to admin_activity_log table
    // await query(
    //   "INSERT INTO admin_activity_log (admin_id, action, target_user_id, details, created_at) VALUES ($1, $2, $3, $4, NOW())",
    //   [adminId, 'password_reset', userId, logMessage]
    // );

    return NextResponse.json({
      success: true,
      message: `Password updated successfully for ${user.email}`,
      user: {
        id: user.id,
        email: user.email,
        fullName: user.full_name
      }
    });

  } catch (error: any) {
    console.error("Admin password reset error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to reset user password" },
      { status: 500 }
    );
  }
}
