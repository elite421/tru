import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, planId, expiresAt } = body;

    if (!userId || !planId) {
      return NextResponse.json(
        { success: false, error: "User ID and Plan ID are required" },
        { status: 400 }
      );
    }

    // Update user's pricing plan
    await query(
      `UPDATE users 
       SET pricing_plan_id = $1, plan_expires_at = $2 
       WHERE id = $3`,
      [planId, expiresAt || null, userId]
    );

    return NextResponse.json(
      { 
        success: true, 
        message: "Pricing plan assigned successfully"
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Plan assignment error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to assign plan" },
      { status: 500 }
    );
  }
}
