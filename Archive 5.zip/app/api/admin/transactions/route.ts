import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

export async function GET(request: NextRequest) {
  try {
    // Get all wallet transactions with user details and GST breakdown
    const result = await query(`
      SELECT 
        wt.id,
        wt.user_id,
        u.email as user_email,
        u.full_name as user_name,
        wt.transaction_type,
        wt.amount,
        wt.base_amount,
        wt.gst_amount,
        wt.gst_percentage,
        wt.deepvue_transaction_id,
        wt.response_time,
        wt.balance_before,
        wt.balance_after,
        wt.description,
        wt.reference_type,
        wt.status,
        wt.created_at
      FROM wallet_transactions wt
      LEFT JOIN users u ON wt.user_id = u.id
      ORDER BY wt.created_at DESC
      LIMIT 100
    `);

    // Get summary statistics including GST totals
    const statsResult = await query(`
      SELECT 
        COUNT(*) as total_transactions,
        SUM(CASE WHEN transaction_type = 'credit' THEN amount ELSE 0 END) as total_credits,
        SUM(CASE WHEN transaction_type = 'debit' THEN amount ELSE 0 END) as total_debits,
        SUM(CASE WHEN transaction_type = 'debit' THEN base_amount ELSE 0 END) as total_base_amount,
        SUM(CASE WHEN transaction_type = 'debit' THEN gst_amount ELSE 0 END) as total_gst_amount,
        AVG(CASE WHEN response_time > 0 THEN response_time ELSE NULL END) as avg_response_time,
        COUNT(DISTINCT user_id) as unique_users,
        AVG(amount) as avg_transaction_amount
      FROM wallet_transactions
    `);

    const stats = statsResult.rows[0];

    return NextResponse.json({
      success: true,
      transactions: result.rows,
      stats: {
        totalTransactions: parseInt(stats.total_transactions),
        totalCredits: parseFloat(stats.total_credits || 0),
        totalDebits: parseFloat(stats.total_debits || 0),
        totalBaseAmount: parseFloat(stats.total_base_amount || 0),
        totalGSTAmount: parseFloat(stats.total_gst_amount || 0),
        avgResponseTime: parseFloat(stats.avg_response_time || 0),
        uniqueUsers: parseInt(stats.unique_users),
        avgTransactionAmount: parseFloat(stats.avg_transaction_amount || 0)
      }
    });
  } catch (error: any) {
    console.error("Admin transactions error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to fetch transactions" },
      { status: 500 }
    );
  }
}
