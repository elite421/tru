import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";
import crypto from "crypto";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email } = body;

    if (!email) {
      return NextResponse.json(
        { success: false, error: "Email is required" },
        { status: 400 }
      );
    }

    // Check if user exists
    const userResult = await query(
      "SELECT id, email, full_name FROM users WHERE email = $1",
      [email.toLowerCase()]
    );

    // For security, always return success even if user doesn't exist
    // This prevents email enumeration attacks
    if (userResult.rows.length === 0) {
      // Still return success, but don't actually send email
      return NextResponse.json({
        success: true,
        message: "If an account exists with this email, you will receive password reset instructions."
      });
    }

    const user = userResult.rows[0];

    // Generate a reset token (valid for 1 hour)
    const resetToken = crypto.randomBytes(32).toString("hex");
    const resetTokenHash = crypto.createHash("sha256").update(resetToken).digest("hex");
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour from now

    // Store reset token in database
    await query(
      `INSERT INTO password_reset_tokens (user_id, token_hash, expires_at, created_at)
       VALUES ($1, $2, $3, NOW())
       ON CONFLICT (user_id) 
       DO UPDATE SET token_hash = $2, expires_at = $3, created_at = NOW()`,
      [user.id, resetTokenHash, expiresAt]
    );

    // In production, you would send an email here with the reset link
    const resetLink = `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/reset-password?token=${resetToken}&email=${encodeURIComponent(email)}`;
    
    // Log reset link only in development
    if (process.env.NODE_ENV === "development") {
      console.log("=== PASSWORD RESET REQUEST ===");
      console.log("User:", user.email);
      console.log("Reset Link:", resetLink);
      console.log("Token expires at:", expiresAt);
      console.log("=============================");
    }

    // TODO: Send email with reset link
    // await sendPasswordResetEmail(user.email, user.full_name, resetLink);

    return NextResponse.json({
      success: true,
      message: "Password reset instructions sent to your email",
      // Include reset link only in development
      ...(process.env.NODE_ENV === "development" && { 
        resetLink,
        note: "In production, this link would be sent via email" 
      })
    });

  } catch (error: any) {
    console.error("Forgot password error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to process password reset request" },
      { status: 500 }
    );
  }
}
