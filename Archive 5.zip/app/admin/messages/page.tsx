"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { 
  Mail,
  Search,
  RefreshCw,
  Eye,
  Send,
  CheckCircle,
  XCircle,
  Clock,
  User,
  Building,
  Phone,
  MessageSquare
} from "lucide-react"
import { Button } from "@/component/ui/button"

type ContactMessage = {
  id: number
  user_id: number | null
  name: string
  email: string
  phone: string | null
  company_name: string | null
  subject: string | null
  message: string
  status: string
  admin_reply: string | null
  replied_at: string | null
  created_at: string
  updated_at: string
  user_email: string | null
}

export default function AdminMessagesPage() {
  const router = useRouter()
  const [messages, setMessages] = useState<ContactMessage[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")
  const [selectedMessage, setSelectedMessage] = useState<ContactMessage | null>(null)
  const [replyText, setReplyText] = useState("")
  const [stats, setStats] = useState({
    total: 0,
    unread: 0,
    read_count: 0,
    replied: 0,
    resolved: 0
  })

  useEffect(() => {
    checkAuth()
    fetchMessages()
  }, [filterStatus])

  const checkAuth = () => {
    const adminUser = sessionStorage.getItem("admin_user")
    if (!adminUser) {
      router.push("/admin/login")
    }
  }

  const fetchMessages = async () => {
    try {
      setLoading(true)
      const url = `/api/admin/contact-messages${filterStatus !== "all" ? `?status=${filterStatus}` : ""}`
      const response = await fetch(url)
      
      if (response.ok) {
        const data = await response.json()
        setMessages(data.messages || [])
        setStats(data.stats || stats)
      }
    } catch (error) {
      console.error("Error fetching messages:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleStatusUpdate = async (id: number, status: string) => {
    try {
      const response = await fetch("/api/admin/contact-messages", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, status })
      })

      if (response.ok) {
        fetchMessages()
        if (selectedMessage?.id === id) {
          setSelectedMessage({ ...selectedMessage, status })
        }
      }
    } catch (error) {
      console.error("Error updating status:", error)
    }
  }

  const handleReply = async () => {
    if (!selectedMessage || !replyText.trim()) return

    try {
      const response = await fetch("/api/admin/contact-messages", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          id: selectedMessage.id, 
          admin_reply: replyText,
          status: "replied"
        })
      })

      if (response.ok) {
        setReplyText("")
        fetchMessages()
        setSelectedMessage(null)
        alert("Reply sent successfully!")
      }
    } catch (error) {
      console.error("Error sending reply:", error)
      alert("Failed to send reply")
    }
  }

  const filteredMessages = messages.filter(msg => {
    const matchesSearch = 
      msg.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      msg.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      msg.subject?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      msg.message?.toLowerCase().includes(searchTerm.toLowerCase())
    
    return matchesSearch
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "unread": return "bg-red-500/20 text-red-400 border-red-400"
      case "read": return "bg-blue-500/20 text-blue-400 border-blue-400"
      case "replied": return "bg-green-500/20 text-green-400 border-green-400"
      case "resolved": return "bg-gray-500/20 text-gray-400 border-gray-400"
      default: return "bg-gray-500/20 text-gray-400 border-gray-400"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Contact Messages</h1>
              <p className="text-gray-400">View and respond to user inquiries</p>
            </div>
            <Button
              onClick={fetchMessages}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-6">
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Total</p>
                <p className="text-2xl font-bold text-white">{stats.total}</p>
              </div>
              <Mail className="w-8 h-8 text-blue-400" />
            </div>
          </div>
          
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Unread</p>
                <p className="text-2xl font-bold text-red-400">{stats.unread}</p>
              </div>
              <XCircle className="w-8 h-8 text-red-400" />
            </div>
          </div>
          
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Read</p>
                <p className="text-2xl font-bold text-blue-400">{stats.read_count}</p>
              </div>
              <Eye className="w-8 h-8 text-blue-400" />
            </div>
          </div>
          
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Replied</p>
                <p className="text-2xl font-bold text-green-400">{stats.replied}</p>
              </div>
              <Send className="w-8 h-8 text-green-400" />
            </div>
          </div>
          
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Resolved</p>
                <p className="text-2xl font-bold text-gray-400">{stats.resolved}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-gray-400" />
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white/5 border border-white/10 rounded-xl p-4 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search messages..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-400"
              />
            </div>
            
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
            >
              <option value="all">All Status</option>
              <option value="unread">Unread</option>
              <option value="read">Read</option>
              <option value="replied">Replied</option>
              <option value="resolved">Resolved</option>
            </select>
          </div>
        </div>

        {/* Messages List */}
        <div className="bg-white/5 border border-white/10 rounded-xl overflow-hidden">
          {loading ? (
            <div className="p-12 text-center">
              <RefreshCw className="w-12 h-12 animate-spin text-white mx-auto mb-4" />
              <p className="text-gray-400">Loading messages...</p>
            </div>
          ) : filteredMessages.length === 0 ? (
            <div className="p-12 text-center">
              <Mail className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-400">No messages found</p>
            </div>
          ) : (
            <div className="divide-y divide-white/10">
              {filteredMessages.map((msg) => (
                <div
                  key={msg.id}
                  onClick={() => {
                    setSelectedMessage(msg)
                    if (msg.status === "unread") {
                      handleStatusUpdate(msg.id, "read")
                    }
                  }}
                  className="p-4 hover:bg-white/5 cursor-pointer transition-colors"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className={`px-2 py-1 rounded text-xs font-bold border ${getStatusColor(msg.status)}`}>
                          {msg.status.toUpperCase()}
                        </span>
                        <h3 className="text-white font-semibold">{msg.name}</h3>
                        {msg.company_name && (
                          <span className="text-xs text-gray-400">({msg.company_name})</span>
                        )}
                      </div>
                      
                      <p className="text-sm text-gray-400 mb-2">{msg.email}</p>
                      
                      {msg.subject && (
                        <p className="text-white font-medium mb-1">{msg.subject}</p>
                      )}
                      
                      <p className="text-sm text-gray-300 line-clamp-2">{msg.message}</p>
                    </div>
                    
                    <div className="text-right">
                      <p className="text-xs text-gray-400">
                        <Clock className="w-3 h-3 inline mr-1" />
                        {new Date(msg.created_at).toLocaleString()}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Message Detail Modal */}
      {selectedMessage && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setSelectedMessage(null)}>
          <div className="bg-gray-800 rounded-2xl shadow-2xl max-w-3xl w-full p-6 max-h-[90vh] overflow-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-white flex items-center gap-2">
                <MessageSquare className="w-6 h-6" />
                Message Details
              </h3>
              <button
                onClick={() => setSelectedMessage(null)}
                className="text-gray-400 hover:text-white"
              >
                <XCircle className="w-6 h-6" />
              </button>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center gap-4">
                <span className={`px-3 py-1 rounded text-sm font-bold border ${getStatusColor(selectedMessage.status)}`}>
                  {selectedMessage.status.toUpperCase()}
                </span>
                <select
                  value={selectedMessage.status}
                  onChange={(e) => handleStatusUpdate(selectedMessage.id, e.target.value)}
                  className="px-3 py-1 bg-white/10 border border-white/20 rounded text-white text-sm"
                >
                  <option value="unread">Mark Unread</option>
                  <option value="read">Mark Read</option>
                  <option value="replied">Mark Replied</option>
                  <option value="resolved">Mark Resolved</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/5 rounded-lg p-4">
                  <p className="text-sm text-gray-400 mb-1 flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Name
                  </p>
                  <p className="text-white font-semibold">{selectedMessage.name}</p>
                </div>

                <div className="bg-white/5 rounded-lg p-4">
                  <p className="text-sm text-gray-400 mb-1 flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    Email
                  </p>
                  <p className="text-white font-semibold">{selectedMessage.email}</p>
                </div>

                {selectedMessage.phone && (
                  <div className="bg-white/5 rounded-lg p-4">
                    <p className="text-sm text-gray-400 mb-1 flex items-center gap-2">
                      <Phone className="w-4 h-4" />
                      Phone
                    </p>
                    <p className="text-white font-semibold">{selectedMessage.phone}</p>
                  </div>
                )}

                {selectedMessage.company_name && (
                  <div className="bg-white/5 rounded-lg p-4">
                    <p className="text-sm text-gray-400 mb-1 flex items-center gap-2">
                      <Building className="w-4 h-4" />
                      Company
                    </p>
                    <p className="text-white font-semibold">{selectedMessage.company_name}</p>
                  </div>
                )}
              </div>

              {selectedMessage.subject && (
                <div className="bg-white/5 rounded-lg p-4">
                  <p className="text-sm text-gray-400 mb-1">Subject</p>
                  <p className="text-white font-semibold">{selectedMessage.subject}</p>
                </div>
              )}

              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-sm text-gray-400 mb-2">Message</p>
                <p className="text-white whitespace-pre-wrap">{selectedMessage.message}</p>
              </div>

              {selectedMessage.admin_reply && (
                <div className="bg-green-900/20 border border-green-500/30 rounded-lg p-4">
                  <p className="text-sm text-green-400 mb-2">Admin Reply</p>
                  <p className="text-white whitespace-pre-wrap">{selectedMessage.admin_reply}</p>
                  {selectedMessage.replied_at && (
                    <p className="text-xs text-gray-400 mt-2">
                      Replied at: {new Date(selectedMessage.replied_at).toLocaleString()}
                    </p>
                  )}
                </div>
              )}

              {/* Reply Section */}
              <div className="border-t border-white/10 pt-4">
                <label className="block text-sm text-gray-400 mb-2">Send Reply</label>
                <textarea
                  value={replyText}
                  onChange={(e) => setReplyText(e.target.value)}
                  placeholder="Type your reply here..."
                  className="w-full h-32 px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-400 resize-none"
                />
                <Button
                  onClick={handleReply}
                  disabled={!replyText.trim()}
                  className="mt-3 bg-green-600 hover:bg-green-700 text-white"
                >
                  <Send className="w-4 h-4 mr-2" />
                  Send Reply
                </Button>
              </div>

              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-sm text-gray-400">Received</p>
                <p className="text-white">{new Date(selectedMessage.created_at).toLocaleString()}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
