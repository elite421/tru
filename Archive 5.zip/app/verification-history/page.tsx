"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/component/ui/button"
import { 
  ArrowLeft, 
  Search, 
  Filter, 
  Download, 
  CheckCircle, 
  XCircle, 
  Clock,
  Eye,
  Copy,
  Calendar,
  Database,
  Zap
} from "lucide-react"
import { useToast } from "@/component/ToastProvider"

type VerificationRecord = {
  id: string
  user_id: string
  verification_type: string
  status: string
  details: any
  amount_charged: number
  cache_hit: boolean
  created_at: string
}

export default function VerificationHistoryPage() {
  const { showToast } = useToast()
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [verifications, setVerifications] = useState<VerificationRecord[]>([])
  const [filteredVerifications, setFilteredVerifications] = useState<VerificationRecord[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState("all")
  const [selectedVerification, setSelectedVerification] = useState<VerificationRecord | null>(null)
  const [viewMode, setViewMode] = useState<"normal" | "json">("normal")

  // Check authentication
  useEffect(() => {
    const userData = sessionStorage.getItem("user")
    if (!userData) {
      router.push("/login")
      return
    }
    
    try {
      const parsedUser = JSON.parse(userData)
      setUser(parsedUser)
    } catch (e) {
      router.push("/login")
    }
  }, [router])

  useEffect(() => {
    if (user) {
      fetchVerificationHistory()
    }
  }, [user])

  useEffect(() => {
    filterVerifications()
  }, [searchTerm, filterType, verifications])

  const fetchVerificationHistory = async () => {
    if (!user) return
    
    try {
      setLoading(true)
      // Use actual logged-in user's ID
      const userId = user.id
      const response = await fetch(`/api/verification/history?userId=${userId}`)
      const data = await response.json()
      
      if (data.success) {
        setVerifications(data.history || [])
      } else {
        showToast(data.error || "Failed to fetch history", "error")
      }
    } catch (error: any) {
      showToast(error.message || "Failed to fetch verification history", "error")
    } finally {
      setLoading(false)
    }
  }

  const filterVerifications = () => {
    let filtered = verifications

    // Filter by type
    if (filterType !== "all") {
      filtered = filtered.filter(v => v.verification_type === filterType)
    }

    // Filter by search term
    if (searchTerm) {
      filtered = filtered.filter(v => 
        v.verification_type.toLowerCase().includes(searchTerm.toLowerCase()) ||
        v.status.toLowerCase().includes(searchTerm.toLowerCase()) ||
        JSON.stringify(v.details).toLowerCase().includes(searchTerm.toLowerCase())
      )
    }

    setFilteredVerifications(filtered)
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle className="w-5 h-5 text-green-600" />
      case "failed":
        return <XCircle className="w-5 h-5 text-red-600" />
      case "pending":
        return <Clock className="w-5 h-5 text-yellow-600" />
      default:
        return <Clock className="w-5 h-5 text-gray-600" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400"
      case "failed":
        return "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400"
      case "pending":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-900/30 dark:text-gray-400"
    }
  }

  const verificationTypes = [
    "all", "pan", "aadhar", "driving-license", "passport", "gst", 
    "bank-account", "voter-id", "email", "phone", "upi", "ifsc", "rc"
  ]

  const exportToCSV = () => {
    const csvContent = [
      ["Date", "Type", "Status", "Amount", "Details"],
      ...filteredVerifications.map(v => [
        new Date(v.created_at).toLocaleString(),
        v.verification_type,
        v.status,
        `₹${v.amount_charged}`,
        JSON.stringify(v.details)
      ])
    ].map(row => row.join(",")).join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `verification-history-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
    showToast("History exported successfully", "success")
  }

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => router.push("/")}
            className="flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white mb-4"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Dashboard
          </button>
          
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
                Verification History
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                View and export all your past verifications
              </p>
            </div>
            <Button
              onClick={exportToCSV}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:opacity-90"
            >
              <Download className="w-5 h-5 mr-2" />
              Export CSV
            </Button>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search verifications..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-12 pr-4 py-3 border-2 border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white outline-none"
              />
            </div>

            {/* Filter by type */}
            <div className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-gray-400" />
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="px-4 py-3 border-2 border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white outline-none"
              >
                {verificationTypes.map(type => (
                  <option key={type} value={type}>
                    {type === "all" ? "All Types" : type.replace(/-/g, " ").toUpperCase()}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Results */}
        {loading ? (
          <div className="text-center py-20">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-indigo-600 mx-auto"></div>
            <p className="mt-4 text-gray-600 dark:text-gray-400">Loading history...</p>
          </div>
        ) : filteredVerifications.length === 0 ? (
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-12 text-center">
            <Calendar className="w-16 h-16 mx-auto mb-4 text-gray-400" />
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
              No Verifications Found
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              {searchTerm || filterType !== "all" 
                ? "Try adjusting your filters"
                : "Start verifying documents to see your history here"}
            </p>
            <Button
              onClick={() => router.push("/")}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white"
            >
              Start Verification
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredVerifications.map((verification) => (
              <div
                key={verification.id}
                className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 border border-gray-100 dark:border-gray-700"
              >
                <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                  <div className="flex items-start gap-4 flex-1">
                    <div className="w-12 h-12 rounded-xl bg-indigo-100 dark:bg-indigo-900/30 flex items-center justify-center flex-shrink-0">
                      {getStatusIcon(verification.status)}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-xl font-bold text-gray-900 dark:text-white">
                          {verification.verification_type.replace(/-/g, " ").toUpperCase()}
                        </h3>
                        <span className={`px-3 py-1 rounded-full text-xs font-bold ${getStatusColor(verification.status)}`}>
                          {verification.status}
                        </span>
                      </div>
                      
                      <div className="flex flex-wrap items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {new Date(verification.created_at).toLocaleString()}
                        </span>
                        <span className="font-semibold text-indigo-600 dark:text-indigo-400">
                          ₹{verification.amount_charged}
                        </span>
                      </div>
                    </div>
                  </div>

                  <Button
                    onClick={() => setSelectedVerification(verification)}
                    className="bg-indigo-600 text-white hover:bg-indigo-700"
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    View Details
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Detail Modal */}
        {selectedVerification && (
          <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50" onClick={() => setSelectedVerification(null)}>
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-4xl w-full max-h-[90vh] overflow-hidden" onClick={(e) => e.stopPropagation()}>
              <div className="p-6 border-b border-gray-200 dark:border-gray-700">
                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
                      Verification Details
                    </h2>
                    {selectedVerification.cache_hit ? (
                      <span className="bg-purple-100 dark:bg-purple-900/30 text-purple-800 dark:text-purple-400 px-3 py-1 rounded-full text-sm font-bold flex items-center gap-2">
                        <Database className="w-4 h-4" />
                        FROM CACHE
                      </span>
                    ) : (
                      <span className="bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-400 px-3 py-1 rounded-full text-sm font-bold flex items-center gap-2">
                        <Zap className="w-4 h-4" />
                        API CALL
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => setSelectedVerification(null)}
                    className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
                  >
                    <XCircle className="w-6 h-6" />
                  </button>
                </div>

                {/* View Toggle */}
                <div className="flex items-center gap-2 bg-gray-100 dark:bg-gray-700 rounded-xl p-1">
                  <button
                    onClick={() => setViewMode("normal")}
                    className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                      viewMode === "normal"
                        ? "bg-white dark:bg-gray-600 text-indigo-600 dark:text-indigo-400 shadow-md"
                        : "text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
                    }`}
                  >
                    Normal View
                  </button>
                  <button
                    onClick={() => setViewMode("json")}
                    className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                      viewMode === "json"
                        ? "bg-white dark:bg-gray-600 text-indigo-600 dark:text-indigo-400 shadow-md"
                        : "text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white"
                    }`}
                  >
                    JSON View
                  </button>
                </div>
              </div>

              <div className="p-6 overflow-auto max-h-[calc(90vh-200px)]">
                {/* Normal View */}
                {viewMode === "normal" && (
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                        <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1">Type</p>
                        <p className="text-lg font-bold text-gray-900 dark:text-white">
                          {selectedVerification.verification_type.replace(/-/g, " ").toUpperCase()}
                        </p>
                      </div>
                      <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                        <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1">Status</p>
                        <span className={`inline-block px-3 py-1 rounded-full text-sm font-bold ${getStatusColor(selectedVerification.status)}`}>
                          {selectedVerification.status}
                        </span>
                      </div>
                      <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                        <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1">Amount</p>
                        <p className="text-lg font-bold text-gray-900 dark:text-white">₹{selectedVerification.amount_charged}</p>
                      </div>
                      <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                        <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1">Date</p>
                        <p className="text-sm font-bold text-gray-900 dark:text-white">
                          {new Date(selectedVerification.created_at).toLocaleString()}
                        </p>
                      </div>
                    </div>

                    <div className="bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-800 rounded-xl p-6 mt-6">
                      <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-4">Response Data</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {Object.entries(selectedVerification.details).map(([key, value]) => (
                          <div key={key} className="bg-white dark:bg-gray-600 rounded-lg p-4 shadow-sm">
                            <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1">
                              {key.replace(/_/g, ' ')}
                            </p>
                            <p className="text-base font-bold text-gray-900 dark:text-white break-words">
                              {typeof value === 'object' ? JSON.stringify(value, null, 2) : String(value)}
                            </p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                )}

                {/* JSON View */}
                {viewMode === "json" && (
                  <div className="bg-gray-900 rounded-xl p-6">
                    <pre className="text-sm text-green-400 overflow-auto whitespace-pre-wrap font-mono">
                      {JSON.stringify(selectedVerification.details, null, 2)}
                    </pre>
                  </div>
                )}
              </div>

              <div className="p-6 border-t border-gray-200 dark:border-gray-700 flex gap-4">
                <Button
                  onClick={() => {
                    navigator.clipboard.writeText(JSON.stringify(selectedVerification.details, null, 2))
                    showToast("JSON copied to clipboard", "success")
                  }}
                  className="flex-1 bg-indigo-600 text-white hover:bg-indigo-700"
                >
                  <Copy className="w-4 h-4 mr-2" />
                  Copy JSON
                </Button>
                <Button
                  onClick={() => setSelectedVerification(null)}
                  className="px-6 bg-gray-600 text-white hover:bg-gray-700"
                >
                  Close
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
