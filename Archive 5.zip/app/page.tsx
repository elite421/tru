"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Card from "@/component/ui/card"
import { Mail, Phone, CreditCard, FileText, Building2, IdCard, Layers, User, BookOpen } from "lucide-react"

type VerificationCard = {
  title: string
  description: string
  placeholder: string
  verificationType: string
  defaultPrice: number
  category: string
}

export default function Dashboard() {
  const router = useRouter()
  const [prices, setPrices] = useState<Record<string, number>>({})
  const [selectedCategory, setSelectedCategory] = useState<string>("All")
  const [searchQuery, setSearchQuery] = useState<string>("")
  const [walletBalance, setWalletBalance] = useState<number>(0)
  const [loadingPrices, setLoadingPrices] = useState(false)
  const [user, setUser] = useState<any>(null)

  // Check authentication
  useEffect(() => {
    const userData = sessionStorage.getItem("user")
    if (!userData) {
      router.push("/login")
      return
    }
    
    try {
      const parsedUser = JSON.parse(userData)
      setUser(parsedUser)
    } catch (e) {
      router.push("/login")
    }
  }, [router])

  // Define categories with icons
  const categories = [
    { name: "All", icon: <Layers className="w-5 h-5" />, color: "from-purple-500 to-pink-500" },
    { name: "Identity Documents", icon: <IdCard className="w-5 h-5" />, color: "from-green-500 to-emerald-500" },
    { name: "Financial", icon: <CreditCard className="w-5 h-5" />, color: "from-orange-500 to-red-500" },
    { name: "Business & Tax", icon: <Building2 className="w-5 h-5" />, color: "from-indigo-500 to-purple-500" },
    { name: "EPFO Services", icon: <User className="w-5 h-5" />, color: "from-violet-500 to-purple-500" },
    { name: "Mobile Intelligence", icon: <Phone className="w-5 h-5" />, color: "from-rose-500 to-pink-500" },
    { name: "Document OCR", icon: <FileText className="w-5 h-5" />, color: "from-amber-500 to-orange-500" },
    { name: "Advanced Services", icon: <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>, color: "from-yellow-500 to-orange-500" }
  ]

  // Define all verification cards with categories
  const verificationCards: VerificationCard[] = [
    // Identity Documents - KYC
    {
      title: "PAN Verification - Basic",
      description: "Verify PAN card details instantly (Lite version).",
      placeholder: "Enter PAN Number (e.g., ABCDE1234F)",
      verificationType: "pan",
      defaultPrice: 5,
      category: "Identity Documents"
    },
    {
      title: "PAN Verification - Plus",
      description: "Enhanced PAN verification with additional details.",
      placeholder: "Enter PAN Number",
      verificationType: "pan-plus",
      defaultPrice: 7,
      category: "Identity Documents"
    },
    {
      title: "Aadhaar eKYC",
      description: "Verify Aadhaar with OTP-based eKYC (2-step process).",
      placeholder: "Enter 12-digit Aadhaar Number",
      verificationType: "aadhaar-ekyc",
      defaultPrice: 8,
      category: "Identity Documents"
    },
    {
      title: "Driving License Verification",
      description: "Async driving license verification with DOB.",
      placeholder: "Enter License Number",
      verificationType: "driving-license",
      defaultPrice: 8,
      category: "Identity Documents"
    },
    {
      title: "Vehicle RC Verification",
      description: "Verify vehicle registration certificate (Advanced).",
      placeholder: "Enter RC Number",
      verificationType: "rc",
      defaultPrice: 7,
      category: "Identity Documents"
    },
    
    // Financial
    {
      title: "Bank Account Verification",
      description: "Verify bank account details and IFSC code.",
      placeholder: "Enter Account Number",
      verificationType: "bank-account",
      defaultPrice: 6,
      category: "Financial"
    },
    {
      title: "IFSC Code Verification",
      description: "Verify bank branch details using IFSC code instantly.",
      placeholder: "Enter IFSC Code",
      verificationType: "ifsc",
      defaultPrice: 2,
      category: "Financial"
    },
    {
      title: "UPI Verification",
      description: "Verify UPI ID (VPA) or get UPI from mobile number.",
      placeholder: "Enter UPI ID",
      verificationType: "upi",
      defaultPrice: 4,
      category: "Financial"
    },
    {
      title: "UPI Advanced",
      description: "Advanced UPI verification with detailed information.",
      placeholder: "Enter UPI ID",
      verificationType: "upi-advanced",
      defaultPrice: 6,
      category: "Financial"
    },
    {
      title: "Credit Report",
      description: "Get comprehensive credit report and score.",
      placeholder: "Enter Details",
      verificationType: "credit-report",
      defaultPrice: 50,
      category: "Financial"
    },
    
    // Business & Tax - GST
    {
      title: "GST Verification - Basic",
      description: "Basic GST verification (Lite version).",
      placeholder: "Enter 15-digit GSTIN",
      verificationType: "gst",
      defaultPrice: 7,
      category: "Business & Tax"
    },
    {
      title: "GST Verification - Advanced",
      description: "Advanced GST verification with detailed business info.",
      placeholder: "Enter GSTIN",
      verificationType: "gst-advanced",
      defaultPrice: 10,
      category: "Business & Tax"
    },
    {
      title: "GSTIN by PAN",
      description: "Find all GSTINs linked to a PAN number.",
      placeholder: "Enter PAN Number",
      verificationType: "gstin-by-pan",
      defaultPrice: 6,
      category: "Business & Tax"
    },
    {
      title: "Track GSTR",
      description: "Track GST return filing status by financial year.",
      placeholder: "Enter GSTIN",
      verificationType: "track-gstr",
      defaultPrice: 8,
      category: "Business & Tax"
    },
    
    // Business & Tax - MCA
    {
      title: "CIN Verification",
      description: "Verify Corporate Identification Number (MCA).",
      placeholder: "Enter CIN Number",
      verificationType: "cin",
      defaultPrice: 8,
      category: "Business & Tax"
    },
    {
      title: "DIN Verification",
      description: "Verify Director Identification Number (MCA).",
      placeholder: "Enter DIN Number",
      verificationType: "din",
      defaultPrice: 8,
      category: "Business & Tax"
    },
    
    // Business & Tax - TaxPayer
    {
      title: "TAN Verification",
      description: "Verify Tax Deduction Account Number.",
      placeholder: "Enter TAN Number",
      verificationType: "tan",
      defaultPrice: 5,
      category: "Business & Tax"
    },
    {
      title: "TDS Compliance Check",
      description: "Check TDS compliance status (Section 206AB).",
      placeholder: "Enter PAN Number",
      verificationType: "tds-compliance",
      defaultPrice: 7,
      category: "Business & Tax"
    },
    
    // Business & Tax - MSME
    {
      title: "Udyam Verification",
      description: "Get Udyam Aadhaar (MSME) details (Async).",
      placeholder: "Enter Udyam Aadhaar Number",
      verificationType: "udyam",
      defaultPrice: 10,
      category: "Business & Tax"
    },
    {
      title: "Udyog Verification",
      description: "Get Udyog Aadhaar (MSME) details (Async).",
      placeholder: "Enter Udyog Aadhaar Number",
      verificationType: "udyog",
      defaultPrice: 10,
      category: "Business & Tax"
    },
    
    // EPFO Services
    {
      title: "Aadhaar to UAN",
      description: "Get UAN from Aadhaar number (EPFO Service).",
      placeholder: "Enter Aadhaar Number",
      verificationType: "aadhaar-to-uan",
      defaultPrice: 7,
      category: "EPFO Services"
    },
    {
      title: "PAN to UAN",
      description: "Get UAN from PAN number (EPFO Service).",
      placeholder: "Enter PAN Number",
      verificationType: "pan-to-uan",
      defaultPrice: 7,
      category: "EPFO Services"
    },
    {
      title: "UAN to Employment History",
      description: "Get employment history from UAN (EPFO).",
      placeholder: "Enter UAN Number",
      verificationType: "uan-employment",
      defaultPrice: 9,
      category: "EPFO Services"
    },
    
    // Mobile Intelligence
    {
      title: "Mobile to Name",
      description: "Get name associated with a mobile number.",
      placeholder: "Enter Mobile Number",
      verificationType: "mobile-to-name",
      defaultPrice: 6,
      category: "Mobile Intelligence"
    },
    {
      title: "Mobile to PAN",
      description: "Get PAN linked to a mobile number.",
      placeholder: "Enter Mobile Number",
      verificationType: "mobile-to-pan",
      defaultPrice: 8,
      category: "Mobile Intelligence"
    },
    {
      title: "Mobile to DL",
      description: "Get driving license details from mobile number.",
      placeholder: "Enter Mobile Number",
      verificationType: "mobile-to-dl",
      defaultPrice: 8,
      category: "Mobile Intelligence"
    },
    {
      title: "Mobile to UAN",
      description: "Get UAN from mobile number.",
      placeholder: "Enter Mobile Number",
      verificationType: "mobile-to-uan",
      defaultPrice: 7,
      category: "Mobile Intelligence"
    },
    {
      title: "Mobile to Digital Age",
      description: "Get digital age of a mobile number.",
      placeholder: "Enter Mobile Number",
      verificationType: "mobile-digital-age",
      defaultPrice: 6,
      category: "Mobile Intelligence"
    },
    {
      title: "Mobile Network Details",
      description: "Get network operator and circle details.",
      placeholder: "Enter Mobile Number",
      verificationType: "mobile-network",
      defaultPrice: 4,
      category: "Mobile Intelligence"
    },
    {
      title: "Mobile to Multiple UPI",
      description: "Get all UPI IDs linked to a mobile number.",
      placeholder: "Enter Mobile Number",
      verificationType: "mobile-to-upi",
      defaultPrice: 6,
      category: "Mobile Intelligence"
    },
    
    // Document OCR
    {
      title: "Aadhaar OCR",
      description: "Extract data from Aadhaar card images (Front & Back).",
      placeholder: "Upload Aadhaar Images",
      verificationType: "ocr-aadhaar",
      defaultPrice: 10,
      category: "Document OCR"
    },
    {
      title: "PAN Card OCR",
      description: "Extract data from PAN card image.",
      placeholder: "Upload PAN Image",
      verificationType: "ocr-pan",
      defaultPrice: 8,
      category: "Document OCR"
    },
    {
      title: "Driving License OCR",
      description: "Extract data from DL card images (Front & Back).",
      placeholder: "Upload DL Images",
      verificationType: "ocr-dl",
      defaultPrice: 10,
      category: "Document OCR"
    },
    {
      title: "Voter ID OCR",
      description: "Extract data from Voter ID card images.",
      placeholder: "Upload Voter ID Images",
      verificationType: "ocr-voter-id",
      defaultPrice: 10,
      category: "Document OCR"
    },
    {
      title: "Bank Cheque OCR",
      description: "Extract data from bank cheque image.",
      placeholder: "Upload Cheque Image",
      verificationType: "ocr-cheque",
      defaultPrice: 8,
      category: "Document OCR"
    },
    {
      title: "GSTIN Certificate OCR",
      description: "Extract data from GST certificate image.",
      placeholder: "Upload GST Certificate",
      verificationType: "ocr-gstin",
      defaultPrice: 10,
      category: "Document OCR"
    },
    
    // Advanced Services - Biometric
    {
      title: "Face Match",
      description: "Compare two face images for matching.",
      placeholder: "Upload Two Images",
      verificationType: "face-match",
      defaultPrice: 15,
      category: "Advanced Services"
    },
    {
      title: "Liveness Check",
      description: "Check if image is of a live person (anti-spoofing).",
      placeholder: "Upload Image",
      verificationType: "liveness-check",
      defaultPrice: 12,
      category: "Advanced Services"
    }
  ]

  useEffect(() => {
    if (!user) return

    const fetchPrices = async () => {
      try {
        setLoadingPrices(true)
        const userId = user.id
        
        const res = await fetch("/api/pricing/user", {
          headers: {
            "x-user-id": userId.toString()
          },
          cache: "no-store" // Prevent caching to always get fresh prices
        })
        
        if (res.ok) {
          const data = await res.json()
          setPrices(data.prices || {})
          console.log('[Dashboard] User-specific pricing loaded:', data.prices)
        } else {
          console.error('[Dashboard] Failed to fetch pricing, using default prices')
        }
      } catch (error) {
        console.error("Error fetching pricing:", error)
      } finally {
        setLoadingPrices(false)
      }
    }

    const fetchWalletBalance = async () => {
      try {
        const userId = user.id
        console.log('[Dashboard] Fetching wallet balance for userId:', userId)
        
        const url = `/api/wallet/balance?userId=${userId}`
        const res = await fetch(url)
        if (res.ok) {
          const data = await res.json()
          console.log('[Dashboard] Wallet balance loaded:', data.balance)
          setWalletBalance(data.balance)
          
          // Update user object in sessionStorage with latest balance
          const updatedUser = { ...user, walletBalance: data.balance }
          sessionStorage.setItem("user", JSON.stringify(updatedUser))
        } else {
          const errorText = await res.text()
          console.error('[Dashboard] Wallet balance error:', res.status, errorText)
        }
      } catch (error) {
        console.error("Error fetching wallet balance:", error)
      }
    }

    fetchPrices()
    fetchWalletBalance()
  }, [user])

  const handleRefreshPrices = async () => {
    if (!user) return
    
    try {
      setLoadingPrices(true)
      const userId = user.id
      
      const res = await fetch("/api/pricing/user", {
        headers: {
          "x-user-id": userId.toString()
        },
        cache: "no-store"
      })
      
      if (res.ok) {
        const data = await res.json()
        setPrices(data.prices || {})
        console.log('[Dashboard] Pricing refreshed:', data.prices)
      }
    } catch (error) {
      console.error("Error refreshing pricing:", error)
    } finally {
      setLoadingPrices(false)
    }
  }

  // Filter cards based on selected category and search query
  const filteredCards = verificationCards
    .filter(card => selectedCategory === "All" || card.category === selectedCategory)
    .filter(card => 
      card.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      card.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      card.verificationType.toLowerCase().includes(searchQuery.toLowerCase())
    )

  // Get count for each category
  const getCategoryCount = (categoryName: string) => {
    if (categoryName === "All") return verificationCards.length
    return verificationCards.filter(card => card.category === categoryName).length
  }

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 px-4 py-6">
      {/* Top Bar - Search and Wallet */}
      <div className="mb-6 flex flex-col md:flex-row gap-4 items-start md:items-center justify-between animate-slide-in-down">
        {/* Search Bar */}
        <div className="flex-1 max-w-2xl">
          <div className="relative hover-lift">
            <input
              type="text"
              placeholder="Search verifications..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-4 text-lg border-2 border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-800 dark:text-white outline-none transition-all"
            />
            <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            )}
          </div>
        </div>

        {/* Quick Access Icons */}
        <div className="flex gap-3 animate-fade-in" style={{ animationDelay: "0.2s" }}>
          {/* Refresh Pricing Button */}
          <button
            onClick={handleRefreshPrices}
            disabled={loadingPrices}
            className="bg-gradient-to-r from-teal-500 to-cyan-600 rounded-lg shadow-lg p-3 hover:scale-110 transition-all transform hover:rotate-3 group animate-bounce-in disabled:opacity-50 disabled:cursor-not-allowed"
            title="Refresh Pricing"
          >
            <svg 
              className={`w-5 h-5 text-white transition-transform ${loadingPrices ? 'animate-spin' : 'group-hover:rotate-180'}`}
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
          </button>

          {/* Advanced Services Icon */}
          <a
            href="/advanced-services"
            className="bg-gradient-to-r from-purple-500 to-pink-600 rounded-lg shadow-lg p-3 hover:scale-110 transition-all transform hover:rotate-3 group animate-bounce-in stagger-0"
            title="Advanced Services"
          >
            <svg className="w-5 h-5 text-white group-hover:rotate-12 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
          </a>

          {/* Account Icon */}
          <a
            href="/account"
            className="bg-gradient-to-r from-indigo-500 to-purple-600 rounded-lg shadow-lg p-3 hover:scale-110 transition-all transform hover:rotate-3 group animate-bounce-in stagger-1"
            title="Account Settings"
          >
            <User className="w-5 h-5 text-white group-hover:rotate-12 transition-transform" />
          </a>

          {/* Wallet Icon */}
          <a
            href="/wallet"
            className="bg-gradient-to-r from-green-500 to-emerald-600 rounded-lg shadow-lg p-3 hover:scale-110 transition-all transform hover:rotate-3 group animate-bounce-in stagger-2"
            title="Wallet"
          >
            <CreditCard className="w-5 h-5 text-white group-hover:rotate-12 transition-transform" />
          </a>

          {/* Docs Icon */}
          <a
            href="/docs"
            className="bg-gradient-to-r from-blue-500 to-cyan-600 rounded-lg shadow-lg p-3 hover:scale-110 transition-all transform hover:rotate-3 group animate-bounce-in stagger-3"
            title="Documentation"
          >
            <BookOpen className="w-5 h-5 text-white group-hover:rotate-12 transition-transform" />
          </a>
        </div>
      </div>

      {/* Horizontal Category Navigation */}
      <div className="mb-8 animate-fade-in" style={{ animationDelay: "0.3s" }}>
        <div className="mb-4 animate-slide-up" style={{ animationDelay: "0.4s" }}>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
            {selectedCategory === "All" ? "All Verifications" : selectedCategory}
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            {filteredCards.length} verification service{filteredCards.length !== 1 ? 's' : ''} available
          </p>
        </div>

        {/* Horizontal Category Tabs */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-2 hover-lift">
          <div className="flex flex-wrap gap-2">
            {categories.map((category) => {
              const count = getCategoryCount(category.name)
              const isActive = selectedCategory === category.name
              
              return (
                <button
                  key={category.name}
                  onClick={() => setSelectedCategory(category.name)}
                  className={`flex items-center gap-2 px-5 py-3 rounded-xl transition-all duration-300 transform hover:scale-105 active:scale-95 group ${
                    isActive
                      ? `bg-gradient-to-r ${category.color} text-white shadow-lg scale-105`
                      : "bg-gray-50 dark:bg-gray-700/50 text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                  }`}
                >
                  <div className={`${
                    isActive ? "text-white" : "text-gray-500 dark:text-gray-400 group-hover:text-gray-700 dark:group-hover:text-gray-200"
                  }`}>
                    {category.icon}
                  </div>
                  <span className="font-semibold whitespace-nowrap">{category.name}</span>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                    isActive
                      ? "bg-white/20 text-white"
                      : "bg-gray-200 dark:bg-gray-600 text-gray-700 dark:text-gray-300"
                  }`}>
                    {count}
                  </span>
                </button>
              )
            })}
          </div>
        </div>
      </div>

      {/* Verification Cards Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCards.map((card, index) => (
          <div 
            key={card.verificationType}
            className="animate-scale-in"
            style={{ animationDelay: `${0.5 + (index * 0.1)}s` }}
          >
            <Card
              title={card.title}
              description={card.description}
              placeholder={card.placeholder}
              buttonText="Verify"
              verificationType={card.verificationType}
              price={prices[card.verificationType] || card.defaultPrice}
              priceLoading={loadingPrices}
            />
          </div>
        ))}
      </section>

      {/* Empty State */}
      {filteredCards.length === 0 && (
        <div className="text-center py-16 animate-fade-in">
          <div className="text-6xl mb-4 animate-bounce">🔍</div>
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            No verifications found
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            Try selecting a different category
          </p>
        </div>
      )}
    </div>
  )
}
