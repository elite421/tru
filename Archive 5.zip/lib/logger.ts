/**
 * Logger utility for writing system logs
 * Logs are stored in logs/system.json file
 */

type LogLevel = "info" | "success" | "warning" | "error";

interface LogOptions {
  level: LogLevel;
  category: string;
  message: string;
  details?: any;
  user_id?: string;
  ip_address?: string;
}

export async function log(options: LogOptions) {
  try {
    // In production, you might want to send this to an external logging service
    // For now, we'll call the API endpoint
    await fetch("/api/admin/logs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(options),
    });
  } catch (error) {
    // Fail silently to not disrupt the main application
    console.error("Failed to write log:", error);
  }
}

// Convenience methods
export const logger = {
  info: (category: string, message: string, details?: any, user_id?: string) =>
    log({ level: "info", category, message, details, user_id }),
  
  success: (category: string, message: string, details?: any, user_id?: string) =>
    log({ level: "success", category, message, details, user_id }),
  
  warning: (category: string, message: string, details?: any, user_id?: string) =>
    log({ level: "warning", category, message, details, user_id }),
  
  error: (category: string, message: string, details?: any, user_id?: string) =>
    log({ level: "error", category, message, details, user_id }),
};
