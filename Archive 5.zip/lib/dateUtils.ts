/**
 * Date formatting utilities to prevent hydration mismatches
 * These functions ensure consistent date formatting between server and client
 */

export function formatDate(date: string | Date): string {
  try {
    const d = new Date(date)
    if (isNaN(d.getTime())) return "Invalid Date"
    
    // Use ISO string and format manually for consistency
    const year = d.getFullYear()
    const month = String(d.getMonth() + 1).padStart(2, '0')
    const day = String(d.getDate()).padStart(2, '0')
    
    return `${year}-${month}-${day}`
  } catch {
    return "Invalid Date"
  }
}

export function formatDateTime(date: string | Date): string {
  try {
    const d = new Date(date)
    if (isNaN(d.getTime())) return "Invalid Date"
    
    // Use ISO string and format manually for consistency
    const year = d.getFullYear()
    const month = String(d.getMonth() + 1).padStart(2, '0')
    const day = String(d.getDate()).padStart(2, '0')
    const hours = String(d.getHours()).padStart(2, '0')
    const minutes = String(d.getMinutes()).padStart(2, '0')
    
    return `${year}-${month}-${day} ${hours}:${minutes}`
  } catch {
    return "Invalid Date"
  }
}

export function formatDateShort(date: string | Date): string {
  try {
    const d = new Date(date)
    if (isNaN(d.getTime())) return "Invalid Date"
    
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    const month = months[d.getMonth()]
    const year = d.getFullYear()
    
    return `${month} ${year}`
  } catch {
    return "Invalid Date"
  }
}

export function formatTime(date: string | Date): string {
  try {
    const d = new Date(date)
    if (isNaN(d.getTime())) return "Invalid Time"
    
    const hours = String(d.getHours()).padStart(2, '0')
    const minutes = String(d.getMinutes()).padStart(2, '0')
    
    return `${hours}:${minutes}`
  } catch {
    return "Invalid Time"
  }
}
