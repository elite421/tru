"use client"

import { usePathname } from "next/navigation"
import Navbar from "@/component/Navbaar"
import Footer from "@/component/footer"

export default function ConditionalLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname()
  const isAdminRoute = pathname?.startsWith('/admin')

  return (
    <>
      {!isAdminRoute && <Navbar />}
      <div className={`flex flex-col min-h-screen ${isAdminRoute ? 'w-full' : 'flex-1'}`}>
        <main className="flex-1">
          {children}
        </main>
        {!isAdminRoute && <Footer />}
      </div>
    </>
  )
}
