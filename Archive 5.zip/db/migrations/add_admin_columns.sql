-- Add admin-related columns to users table
-- Run this if you want admin functionality

-- Add is_admin column (boolean flag)
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS is_admin BOOLEAN DEFAULT false;

-- Add role column (for future role-based access control)
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS role VARCHAR(50) DEFAULT 'user';

-- Create index for faster admin lookups
CREATE INDEX IF NOT EXISTS idx_users_is_admin ON users(is_admin) WHERE is_admin = true;
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

-- Example: Make a specific user admin
-- UPDATE users SET is_admin = true, role = 'admin' WHERE email = 'your-admin@example.com';

-- Example: Create a new admin user (update password_hash with bcrypt hash)
-- INSERT INTO users (email, password_hash, full_name, is_admin, role)
-- VALUES ('admin@truverify.com', '$2a$10$...', 'Admin User', true, 'admin');

-- Verify the changes
SELECT id, email, full_name, is_admin, role FROM users LIMIT 5;
