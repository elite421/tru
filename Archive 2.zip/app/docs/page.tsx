"use client"

import { useState, useEffect } from "react"
import { Button } from "@/component/ui/button"
import { Copy, Check } from "lucide-react"
import ApiKeyManager from "@/component/ApiKeyManager"

export default function DocsPage() {
  const [copiedCode, setCopiedCode] = useState<string | null>(null)
  const [selectedApi, setSelectedApi] = useState("pan")
  const [selectedLang, setSelectedLang] = useState<"curl" | "javascript" | "python">("curl")

  const copyToClipboard = (code: string, id: string) => {
    navigator.clipboard.writeText(code)
    setCopiedCode(id)
    setTimeout(() => setCopiedCode(null), 2000)
  }

  const apiEndpoints = [
    { id: "pan", name: "PAN Verification - Basic", endpoint: "/api/verification/pan", price: "₹5" },
    { id: "pan-plus", name: "PAN Verification - Plus", endpoint: "/api/verification/pan-plus", price: "₹7" },
    { id: "aadhaar-ekyc", name: "Aadhaar eKYC", endpoint: "/api/verification/aadhaar-ekyc", price: "₹8" },
    { id: "driving-license", name: "Driving License", endpoint: "/api/verification/driving-license", price: "₹8" },
    { id: "rc", name: "Vehicle RC", endpoint: "/api/verification/rc", price: "₹7" },
    { id: "bank-account", name: "Bank Account", endpoint: "/api/verification/bank-account", price: "₹6" },
    { id: "ifsc", name: "IFSC Code", endpoint: "/api/verification/ifsc", price: "₹2" },
    { id: "upi", name: "UPI Verification", endpoint: "/api/verification/upi", price: "₹4" },
    { id: "upi-advanced", name: "UPI Advanced", endpoint: "/api/verification/upi-advanced", price: "₹6" },
    { id: "gst", name: "GST Basic", endpoint: "/api/verification/gst", price: "₹7" },
    { id: "gst-advanced", name: "GST Advanced", endpoint: "/api/verification/gst-advanced", price: "₹10" },
    { id: "gstin-by-pan", name: "GSTIN by PAN", endpoint: "/api/verification/gstin-by-pan", price: "₹6" },
    { id: "track-gstr", name: "Track GSTR", endpoint: "/api/verification/track-gstr", price: "₹8" },
    { id: "cin", name: "CIN Verification", endpoint: "/api/verification/cin", price: "₹8" },
    { id: "din", name: "DIN Verification", endpoint: "/api/verification/din", price: "₹8" },
    { id: "tan", name: "TAN Verification", endpoint: "/api/verification/tan", price: "₹5" },
    { id: "tds-compliance", name: "TDS Compliance", endpoint: "/api/verification/tds-compliance", price: "₹7" },
    { id: "udyam", name: "Udyam Verification", endpoint: "/api/verification/udyam", price: "₹10" },
    { id: "udyog", name: "Udyog Verification", endpoint: "/api/verification/udyog", price: "₹10" },
    { id: "aadhaar-to-uan", name: "Aadhaar to UAN", endpoint: "/api/epfo/aadhaar-to-uan", price: "₹7" },
    { id: "pan-to-uan", name: "PAN to UAN", endpoint: "/api/epfo/pan-to-uan", price: "₹7" },
    { id: "uan-employment", name: "UAN to Employment", endpoint: "/api/epfo/uan-employment", price: "₹9" },
    { id: "mobile-to-name", name: "Mobile to Name", endpoint: "/api/mobile-intelligence/mobile-to-name", price: "₹6" },
    { id: "mobile-to-pan", name: "Mobile to PAN", endpoint: "/api/mobile-intelligence/mobile-to-pan", price: "₹8" },
    { id: "mobile-to-dl", name: "Mobile to DL", endpoint: "/api/mobile-intelligence/mobile-to-dl", price: "₹8" },
    { id: "mobile-to-uan", name: "Mobile to UAN", endpoint: "/api/mobile-intelligence/mobile-to-uan", price: "₹7" },
    { id: "mobile-digital-age", name: "Mobile Digital Age", endpoint: "/api/mobile-intelligence/mobile-digital-age", price: "₹6" },
    { id: "mobile-network", name: "Mobile Network Details", endpoint: "/api/mobile-intelligence/mobile-network", price: "₹4" },
    { id: "mobile-to-upi", name: "Mobile to UPI", endpoint: "/api/mobile-intelligence/mobile-to-upi", price: "₹6" },
    { id: "ocr-aadhaar", name: "Aadhaar OCR", endpoint: "/api/ocr/aadhaar", price: "₹10" },
    { id: "ocr-pan", name: "PAN OCR", endpoint: "/api/ocr/pan", price: "₹8" },
    { id: "ocr-voter-id", name: "Voter ID OCR", endpoint: "/api/ocr/voter-id", price: "₹10" },
    { id: "ocr-dl", name: "DL OCR", endpoint: "/api/ocr/dl", price: "₹10" },
    { id: "ocr-cheque", name: "Bank Cheque OCR", endpoint: "/api/ocr/cheque", price: "₹8" },
    { id: "ocr-gstin", name: "GSTIN Certificate OCR", endpoint: "/api/ocr/gstin", price: "₹10" },
    { id: "face-match", name: "Face Match", endpoint: "/api/biometric/face-match", price: "₹15" },
    { id: "liveness-check", name: "Liveness Check", endpoint: "/api/biometric/liveness-check", price: "₹12" },
    { id: "credit-report", name: "Credit Report", endpoint: "/api/financial/credit-report", price: "₹50" },
  ]

  const codeExamples: Record<string, { curl: string; javascript: string; python: string }> = {
    pan: {
      curl: `curl -X POST https://your-domain.com/api/verification/pan \\
  -H "Content-Type: application/json" \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -d '{"panNumber": "ABCDE1234F"}'`,
      javascript: `const response = await fetch('https://your-domain.com/api/verification/pan', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_API_KEY'
  },
  body: JSON.stringify({ panNumber: 'ABCDE1234F' })
});

const data = await response.json();
console.log(data);`,
      python: `import requests

url = "https://your-domain.com/api/verification/pan"
headers = {
    "Content-Type": "application/json",
    "Authorization": "Bearer YOUR_API_KEY"
}
data = {"panNumber": "ABCDE1234F"}

response = requests.post(url, headers=headers, json=data)
print(response.json())`,
    },
    "aadhaar-ekyc": {
      curl: `curl -X POST https://your-domain.com/api/verification/aadhaar-ekyc \\
  -H "Content-Type: application/json" \\
  -H "Authorization: Bearer YOUR_API_KEY" \\
  -d '{"aadhaarNumber": "123456789012"}'`,
      javascript: `const response = await fetch('https://your-domain.com/api/verification/aadhaar-ekyc', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': 'Bearer YOUR_API_KEY'
  },
  body: JSON.stringify({ aadhaarNumber: '123456789012' })
});

const data = await response.json();
console.log(data);`,
      python: `import requests

url = "https://your-domain.com/api/verification/aadhaar-ekyc"
headers = {
    "Content-Type": "application/json",
    "Authorization": "Bearer YOUR_API_KEY"
}
data = {"aadhaarNumber": "123456789012"}

response = requests.post(url, headers=headers, json=data)
print(response.json())`,
    },
    // Add more code examples for other APIs
  }

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-12">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent mb-4">
            API Documentation
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Complete guide to integrate TruVerify APIs into your business applications
          </p>
        </div>

        {/* API Key Manager */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 mb-8">
          <ApiKeyManager />
        </div>

        {/* Quick Start */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 mb-8">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">🚀 Quick Start</h2>
          <div className="space-y-4">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center font-bold">1</div>
              <div>
                <h3 className="font-semibold text-lg text-gray-900 dark:text-white">Get Your API Key</h3>
                <p className="text-gray-600 dark:text-gray-400">Sign up and generate your unique API key from the dashboard</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center font-bold">2</div>
              <div>
                <h3 className="font-semibold text-lg text-gray-900 dark:text-white">Make API Calls</h3>
                <p className="text-gray-600 dark:text-gray-400">Use your API key to authenticate and start verifying</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-8 h-8 bg-indigo-600 text-white rounded-full flex items-center justify-center font-bold">3</div>
              <div>
                <h3 className="font-semibold text-lg text-gray-900 dark:text-white">Pay As You Go</h3>
                <p className="text-gray-600 dark:text-gray-400">Only pay for what you use, with transparent pricing</p>
              </div>
            </div>
          </div>
        </div>

        {/* API Endpoints */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 mb-8">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">📡 Available Endpoints</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {apiEndpoints.map((api) => (
              <button
                key={api.id}
                onClick={() => setSelectedApi(api.id)}
                className={`p-4 rounded-xl border-2 transition-all text-left ${
                  selectedApi === api.id
                    ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-900/20"
                    : "border-gray-200 dark:border-gray-700 hover:border-indigo-400"
                }`}
              >
                <h3 className="font-bold text-gray-900 dark:text-white mb-1">{api.name}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-2">{api.endpoint}</p>
                <span className="inline-block bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-3 py-1 rounded-full text-xs font-semibold">
                  {api.price}/API
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Code Examples */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 mb-8">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">💻 Code Examples</h2>
          
          {/* Language Tabs */}
          <div className="flex gap-2 mb-6 border-b border-gray-200 dark:border-gray-700">
            {["curl", "javascript", "python"].map((lang) => (
              <button
                key={lang}
                onClick={() => setSelectedLang(lang as "curl" | "javascript" | "python")}
                className={`px-6 py-3 font-semibold capitalize border-b-2 transition-colors ${
                  selectedLang === lang
                    ? "border-indigo-600 text-indigo-600 dark:text-indigo-400"
                    : "border-transparent text-gray-600 dark:text-gray-400 hover:border-indigo-400 hover:text-indigo-500"
                }`}
              >
                {lang === "javascript" ? "JavaScript" : lang.toUpperCase()}
              </button>
            ))}
          </div>

          {/* Code Display */}
          <div className="relative">
            <div className="bg-gray-900 rounded-xl p-6 overflow-x-auto">
              <pre className="text-sm text-green-400 font-mono whitespace-pre-wrap">
                {codeExamples[selectedApi]?.[selectedLang] || codeExamples.pan[selectedLang]}
              </pre>
            </div>
            <button
              onClick={() => copyToClipboard(
                codeExamples[selectedApi]?.[selectedLang] || codeExamples.pan[selectedLang],
                `${selectedApi}-${selectedLang}`
              )}
              className="absolute top-4 right-4 p-2 bg-gray-700 hover:bg-gray-600 rounded-lg transition-colors"
            >
              {copiedCode === `${selectedApi}-${selectedLang}` ? (
                <Check size={20} className="text-green-400" />
              ) : (
                <Copy size={20} className="text-gray-300" />
              )}
            </button>
          </div>
        </div>

        {/* Pricing */}
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl shadow-xl p-8 text-white mb-8">
          <h2 className="text-3xl font-bold mb-4">💰 Simple Pricing</h2>
          <p className="text-xl mb-6">Pay only for what you use. No hidden fees, no subscriptions.</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6">
              <h3 className="text-2xl font-bold mb-2">₹2-₹4</h3>
              <p className="text-white/80">IFSC & Basic Verifications</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6">
              <h3 className="text-2xl font-bold mb-2">₹5-₹10</h3>
              <p className="text-white/80">PAN, Aadhaar, GST, EPFO Services</p>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-6">
              <h3 className="text-2xl font-bold mb-2">₹12-₹50</h3>
              <p className="text-white/80">Biometric & Credit Reports</p>
            </div>
          </div>
        </div>

        {/* Support */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">🤝 Need Help?</h2>
          <p className="text-gray-600 dark:text-gray-400 mb-6">
            Our team is here to help you integrate our APIs seamlessly into your business.
          </p>
          <Button className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-8 py-3 rounded-xl">
            Contact Support
          </Button>
        </div>
      </div>
    </div>
  )
}
