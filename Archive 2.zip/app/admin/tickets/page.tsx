"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { 
  Ticket,
  Search,
  RefreshCw,
  AlertTriangle,
  CheckCircle,
  Clock,
  User,
  Tag,
  MessageCircle,
  XCircle
} from "lucide-react"
import { Button } from "@/component/ui/button"

type SupportTicket = {
  id: number
  user_id: number | null
  user_email: string
  user_name: string | null
  subject: string
  description: string
  category: string
  priority: string
  status: string
  admin_notes: string | null
  assigned_to: number | null
  created_at: string
  updated_at: string
  closed_at: string | null
}

export default function AdminTicketsPage() {
  const router = useRouter()
  const [tickets, setTickets] = useState<SupportTicket[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterStatus, setFilterStatus] = useState("all")
  const [filterPriority, setFilterPriority] = useState("all")
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null)
  const [adminNotes, setAdminNotes] = useState("")
  const [stats, setStats] = useState({
    total: 0,
    open_count: 0,
    in_progress: 0,
    closed_count: 0,
    urgent: 0,
    high: 0
  })

  useEffect(() => {
    checkAuth()
    fetchTickets()
  }, [filterStatus, filterPriority])

  const checkAuth = () => {
    const adminUser = sessionStorage.getItem("admin_user")
    if (!adminUser) {
      router.push("/admin/login")
    }
  }

  const fetchTickets = async () => {
    try {
      setLoading(true)
      let url = "/api/admin/tickets?"
      const params = []
      if (filterStatus !== "all") params.push(`status=${filterStatus}`)
      if (filterPriority !== "all") params.push(`priority=${filterPriority}`)
      url += params.join("&")
      
      const response = await fetch(url)
      
      if (response.ok) {
        const data = await response.json()
        setTickets(data.tickets || [])
        setStats(data.stats || stats)
      }
    } catch (error) {
      console.error("Error fetching tickets:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleUpdate = async (id: number, updates: any) => {
    try {
      const response = await fetch("/api/admin/tickets", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, ...updates })
      })

      if (response.ok) {
        fetchTickets()
        if (selectedTicket?.id === id) {
          setSelectedTicket({ ...selectedTicket, ...updates })
        }
      }
    } catch (error) {
      console.error("Error updating ticket:", error)
    }
  }

  const handleSaveNotes = async () => {
    if (!selectedTicket || !adminNotes.trim()) return

    try {
      const response = await fetch("/api/admin/tickets", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ 
          id: selectedTicket.id, 
          admin_notes: adminNotes
        })
      })

      if (response.ok) {
        setAdminNotes("")
        fetchTickets()
        alert("Notes saved successfully!")
      }
    } catch (error) {
      console.error("Error saving notes:", error)
      alert("Failed to save notes")
    }
  }

  const filteredTickets = tickets.filter(ticket => {
    const matchesSearch = 
      ticket.subject?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.user_email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.user_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      ticket.description?.toLowerCase().includes(searchTerm.toLowerCase())
    
    return matchesSearch
  })

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "urgent": return "bg-red-500/20 text-red-400 border-red-400"
      case "high": return "bg-orange-500/20 text-orange-400 border-orange-400"
      case "medium": return "bg-yellow-500/20 text-yellow-400 border-yellow-400"
      case "low": return "bg-green-500/20 text-green-400 border-green-400"
      default: return "bg-gray-500/20 text-gray-400 border-gray-400"
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "open": return "bg-blue-500/20 text-blue-400 border-blue-400"
      case "in-progress": return "bg-yellow-500/20 text-yellow-400 border-yellow-400"
      case "closed": return "bg-gray-500/20 text-gray-400 border-gray-400"
      default: return "bg-gray-500/20 text-gray-400 border-gray-400"
    }
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "technical": return <AlertTriangle className="w-4 h-4" />
      case "billing": return <Tag className="w-4 h-4" />
      default: return <MessageCircle className="w-4 h-4" />
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Support Tickets</h1>
              <p className="text-gray-400">Manage user support requests</p>
            </div>
            <Button
              onClick={fetchTickets}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-6 gap-6 mb-6">
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Total</p>
                <p className="text-2xl font-bold text-white">{stats.total}</p>
              </div>
              <Ticket className="w-8 h-8 text-blue-400" />
            </div>
          </div>
          
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Open</p>
                <p className="text-2xl font-bold text-blue-400">{stats.open_count}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-blue-400" />
            </div>
          </div>
          
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">In Progress</p>
                <p className="text-2xl font-bold text-yellow-400">{stats.in_progress}</p>
              </div>
              <Clock className="w-8 h-8 text-yellow-400" />
            </div>
          </div>
          
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Closed</p>
                <p className="text-2xl font-bold text-gray-400">{stats.closed_count}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-gray-400" />
            </div>
          </div>
          
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Urgent</p>
                <p className="text-2xl font-bold text-red-400">{stats.urgent}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-red-400" />
            </div>
          </div>
          
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">High</p>
                <p className="text-2xl font-bold text-orange-400">{stats.high}</p>
              </div>
              <AlertTriangle className="w-8 h-8 text-orange-400" />
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white/5 border border-white/10 rounded-xl p-4 mb-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search tickets..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-400"
              />
            </div>
            
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
            >
              <option value="all">All Status</option>
              <option value="open">Open</option>
              <option value="in-progress">In Progress</option>
              <option value="closed">Closed</option>
            </select>

            <select
              value={filterPriority}
              onChange={(e) => setFilterPriority(e.target.value)}
              className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
            >
              <option value="all">All Priorities</option>
              <option value="urgent">Urgent</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
          </div>
        </div>

        {/* Tickets List */}
        <div className="bg-white/5 border border-white/10 rounded-xl overflow-hidden">
          {loading ? (
            <div className="p-12 text-center">
              <RefreshCw className="w-12 h-12 animate-spin text-white mx-auto mb-4" />
              <p className="text-gray-400">Loading tickets...</p>
            </div>
          ) : filteredTickets.length === 0 ? (
            <div className="p-12 text-center">
              <Ticket className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-400">No tickets found</p>
            </div>
          ) : (
            <div className="divide-y divide-white/10">
              {filteredTickets.map((ticket) => (
                <div
                  key={ticket.id}
                  onClick={() => {
                    setSelectedTicket(ticket)
                    setAdminNotes(ticket.admin_notes || "")
                  }}
                  className="p-4 hover:bg-white/5 cursor-pointer transition-colors"
                >
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className={`px-2 py-1 rounded text-xs font-bold border ${getStatusColor(ticket.status)}`}>
                          {ticket.status.toUpperCase()}
                        </span>
                        <span className={`px-2 py-1 rounded text-xs font-bold border ${getPriorityColor(ticket.priority)}`}>
                          {ticket.priority.toUpperCase()}
                        </span>
                        <span className="text-xs text-gray-400 flex items-center gap-1">
                          {getCategoryIcon(ticket.category)}
                          {ticket.category}
                        </span>
                      </div>
                      
                      <h3 className="text-white font-semibold mb-1">#{ticket.id} - {ticket.subject}</h3>
                      
                      <p className="text-sm text-gray-300 line-clamp-2 mb-2">{ticket.description}</p>
                      
                      <div className="flex items-center gap-4 text-xs text-gray-400">
                        <span className="flex items-center gap-1">
                          <User className="w-3 h-3" />
                          {ticket.user_name || ticket.user_email}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {new Date(ticket.created_at).toLocaleString()}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Ticket Detail Modal */}
      {selectedTicket && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setSelectedTicket(null)}>
          <div className="bg-gray-800 rounded-2xl shadow-2xl max-w-4xl w-full p-6 max-h-[90vh] overflow-auto" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-white flex items-center gap-2">
                <Ticket className="w-6 h-6" />
                Ticket #{selectedTicket.id}
              </h3>
              <button
                onClick={() => setSelectedTicket(null)}
                className="text-gray-400 hover:text-white"
              >
                <XCircle className="w-6 h-6" />
              </button>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center gap-4 flex-wrap">
                <div>
                  <label className="text-xs text-gray-400 block mb-1">Status</label>
                  <select
                    value={selectedTicket.status}
                    onChange={(e) => handleUpdate(selectedTicket.id, { status: e.target.value })}
                    className="px-3 py-1 bg-white/10 border border-white/20 rounded text-white text-sm"
                  >
                    <option value="open">Open</option>
                    <option value="in-progress">In Progress</option>
                    <option value="closed">Closed</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs text-gray-400 block mb-1">Priority</label>
                  <select
                    value={selectedTicket.priority}
                    onChange={(e) => handleUpdate(selectedTicket.id, { priority: e.target.value })}
                    className="px-3 py-1 bg-white/10 border border-white/20 rounded text-white text-sm"
                  >
                    <option value="low">Low</option>
                    <option value="medium">Medium</option>
                    <option value="high">High</option>
                    <option value="urgent">Urgent</option>
                  </select>
                </div>
              </div>

              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-sm text-gray-400 mb-1">Subject</p>
                <p className="text-white font-semibold text-lg">{selectedTicket.subject}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/5 rounded-lg p-4">
                  <p className="text-sm text-gray-400 mb-1 flex items-center gap-2">
                    <User className="w-4 h-4" />
                    User
                  </p>
                  <p className="text-white font-semibold">{selectedTicket.user_name || "N/A"}</p>
                  <p className="text-sm text-gray-400">{selectedTicket.user_email}</p>
                </div>

                <div className="bg-white/5 rounded-lg p-4">
                  <p className="text-sm text-gray-400 mb-1 flex items-center gap-2">
                    <Tag className="w-4 h-4" />
                    Category
                  </p>
                  <p className="text-white font-semibold capitalize">{selectedTicket.category}</p>
                </div>
              </div>

              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-sm text-gray-400 mb-2">Description</p>
                <p className="text-white whitespace-pre-wrap">{selectedTicket.description}</p>
              </div>

              {selectedTicket.admin_notes && (
                <div className="bg-blue-900/20 border border-blue-500/30 rounded-lg p-4">
                  <p className="text-sm text-blue-400 mb-2">Previous Admin Notes</p>
                  <p className="text-white whitespace-pre-wrap">{selectedTicket.admin_notes}</p>
                </div>
              )}

              {/* Admin Notes Section */}
              <div className="border-t border-white/10 pt-4">
                <label className="block text-sm text-gray-400 mb-2">Admin Notes</label>
                <textarea
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e.target.value)}
                  placeholder="Add internal notes about this ticket..."
                  className="w-full h-32 px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-400 resize-none"
                />
                <Button
                  onClick={handleSaveNotes}
                  disabled={!adminNotes.trim()}
                  className="mt-3 bg-blue-600 hover:bg-blue-700 text-white"
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Save Notes
                </Button>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/5 rounded-lg p-4">
                  <p className="text-sm text-gray-400">Created</p>
                  <p className="text-white">{new Date(selectedTicket.created_at).toLocaleString()}</p>
                </div>
                
                {selectedTicket.closed_at && (
                  <div className="bg-white/5 rounded-lg p-4">
                    <p className="text-sm text-gray-400">Closed</p>
                    <p className="text-white">{new Date(selectedTicket.closed_at).toLocaleString()}</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
