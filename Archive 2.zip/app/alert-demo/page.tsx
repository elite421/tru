"use client"

import { useAlert } from "@/component/AlertProvider"
import { Button } from "@/component/ui/button"

export default function AlertDemoPage() {
  const alert = useAlert()

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-12 text-center animate-fade-in">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
            Modern Alert System
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Click the buttons below to see different alert types
          </p>
        </div>

        {/* Alert Type Buttons */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 mb-8 animate-scale-in">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
            Alert Types
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button
              onClick={() => alert.success("Operation completed successfully!")}
              className="bg-green-600 hover:bg-green-700 text-white py-3 h-auto"
            >
              Show Success Alert
            </Button>

            <Button
              onClick={() => alert.error("Something went wrong. Please try again.")}
              className="bg-red-600 hover:bg-red-700 text-white py-3 h-auto"
            >
              Show Error Alert
            </Button>

            <Button
              onClick={() => alert.warning("Please review your input before proceeding.")}
              className="bg-yellow-600 hover:bg-yellow-700 text-white py-3 h-auto"
            >
              Show Warning Alert
            </Button>

            <Button
              onClick={() => alert.info("Here's some useful information for you.")}
              className="bg-blue-600 hover:bg-blue-700 text-white py-3 h-auto"
            >
              Show Info Alert
            </Button>
          </div>
        </div>

        {/* Alert with Titles */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 mb-8 animate-scale-in" style={{ animationDelay: "0.1s" }}>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
            Alerts with Titles
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button
              onClick={() => alert.success("Your changes have been saved.", "Success!")}
              className="bg-green-600 hover:bg-green-700 text-white py-3 h-auto"
            >
              Success with Title
            </Button>

            <Button
              onClick={() => alert.error("Unable to connect to the server.", "Connection Error")}
              className="bg-red-600 hover:bg-red-700 text-white py-3 h-auto"
            >
              Error with Title
            </Button>

            <Button
              onClick={() => alert.warning("Your session will expire soon.", "Warning")}
              className="bg-yellow-600 hover:bg-yellow-700 text-white py-3 h-auto"
            >
              Warning with Title
            </Button>

            <Button
              onClick={() => alert.info("New features are now available.", "Update Available")}
              className="bg-blue-600 hover:bg-blue-700 text-white py-3 h-auto"
            >
              Info with Title
            </Button>
          </div>
        </div>

        {/* Custom Duration */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 mb-8 animate-scale-in" style={{ animationDelay: "0.2s" }}>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
            Custom Duration
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button
              onClick={() => alert.showAlert("success", "Quick alert (2s)", "Fast", 2000)}
              className="bg-gradient-to-r from-green-600 to-emerald-600 hover:opacity-90 text-white py-3 h-auto"
            >
              2 Second Alert
            </Button>

            <Button
              onClick={() => alert.showAlert("info", "Normal alert (5s)", "Default", 5000)}
              className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:opacity-90 text-white py-3 h-auto"
            >
              5 Second Alert
            </Button>

            <Button
              onClick={() => alert.showAlert("warning", "Long alert (10s)", "Slow", 10000)}
              className="bg-gradient-to-r from-yellow-600 to-orange-600 hover:opacity-90 text-white py-3 h-auto"
            >
              10 Second Alert
            </Button>
          </div>
        </div>

        {/* Multiple Alerts */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 animate-scale-in" style={{ animationDelay: "0.3s" }}>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
            Multiple Alerts
          </h2>
          
          <Button
            onClick={() => {
              alert.success("First operation completed")
              setTimeout(() => alert.info("Processing next step..."), 500)
              setTimeout(() => alert.warning("Almost done..."), 1000)
              setTimeout(() => alert.success("All operations completed!", "Done!"), 1500)
            }}
            className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-90 text-white py-4 h-auto text-lg font-semibold"
          >
            Show Multiple Alerts
          </Button>
        </div>

        {/* Usage Instructions */}
        <div className="mt-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl shadow-2xl p-8 text-white">
          <h2 className="text-2xl font-bold mb-4">How to Use</h2>
          <div className="space-y-4 text-white/90">
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <p className="font-semibold mb-2">1. Import the hook:</p>
              <code className="text-sm bg-black/30 px-3 py-1 rounded">
                import {`{ useAlert }`} from "@/component/AlertProvider"
              </code>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <p className="font-semibold mb-2">2. Use in your component:</p>
              <code className="text-sm bg-black/30 px-3 py-1 rounded block mb-2">
                const alert = useAlert()
              </code>
            </div>
            
            <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
              <p className="font-semibold mb-2">3. Show alerts:</p>
              <div className="space-y-2 text-sm">
                <code className="bg-black/30 px-3 py-1 rounded block">
                  alert.success("Message")
                </code>
                <code className="bg-black/30 px-3 py-1 rounded block">
                  alert.error("Message", "Title")
                </code>
                <code className="bg-black/30 px-3 py-1 rounded block">
                  alert.showAlert("warning", "Message", "Title", 3000)
                </code>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
