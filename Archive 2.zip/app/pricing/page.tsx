"use client"

import { useRouter } from "next/navigation"
import { useState } from "react"
import { CheckCircle, Sparkles } from "lucide-react"

export default function Pricing() {
  const router = useRouter()
  const [selectedPlan, setSelectedPlan] = useState("")

  const handlePlanSelect = (plan: string) => {
    setSelectedPlan(plan)
    // Redirect to checkout or subscription page
    router.push(`/checkout?plan=${plan}`)
  }

  const handleFreeTrial = () => {
    router.push("/verify?trial=true")
  }

  const handleContactSales = () => {
    router.push("/contact?subject=Enterprise%20Plan")
  }

  const handleSignup = () => {
    router.push("/signup")
  }

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 py-20 px-6">
      {/* Heading */}
      <div className="text-center mb-12 animate-fade-in">
        <div className="inline-flex items-center gap-2 mb-4">
          <Sparkles className="w-8 h-8 text-yellow-500 animate-pulse" />
          <h1 className="text-5xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">Pricing Plans</h1>
          <Sparkles className="w-8 h-8 text-yellow-500 animate-pulse" />
        </div>
        <p className="text-xl text-gray-600 dark:text-gray-300 animate-slide-up">Choose the plan that fits your needs</p>
      </div>

      {/* Pricing Cards */}
      <section className="grid gap-10 sm:grid-cols-2 max-w-5xl w-full mx-auto mb-20">
        {/* Basic Plan */}
        <div className="bg-white dark:bg-gray-800 rounded-3xl p-10 shadow-xl hover:shadow-2xl hover:-translate-y-2 transition-all duration-300 border-2 border-gray-200 dark:border-gray-700 animate-slide-in-left">
          <h3 className="text-2xl font-semibold mb-2 text-gray-900 dark:text-white">Basic</h3>
          <p className="text-gray-600 dark:text-gray-400 mb-6">Ideal for individuals and startups</p>
          <p className="text-5xl font-bold mb-8 text-gray-900 dark:text-white">
            ₹200<span className="text-lg font-medium text-gray-600 dark:text-gray-400">/mo</span>
          </p>
          <ul className="space-y-4 text-gray-700 dark:text-gray-300 mb-10">
            <li className="flex items-center gap-2 animate-fade-in" style={{ animationDelay: "0.1s" }}>
              <CheckCircle className="text-green-500 w-5 h-5" /> Access to all APIs
            </li>
            <li className="flex items-center gap-2 animate-fade-in" style={{ animationDelay: "0.2s" }}>
              <CheckCircle className="text-green-500 w-5 h-5" /> Plug & play integration
            </li>
            <li className="flex items-center gap-2 animate-fade-in" style={{ animationDelay: "0.3s" }}>
              <CheckCircle className="text-green-500 w-5 h-5" /> Cancel anytime
            </li>
          </ul>
          <button 
            onClick={() => handlePlanSelect("basic")}
            className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-90 hover:scale-105 text-white py-3 rounded-xl font-semibold text-lg transition-all transform active:scale-95"
          >
            Get Started
          </button>
        </div>

        {/* Standard Plan */}
        <div className="bg-white dark:bg-gray-800 rounded-3xl p-10 shadow-xl hover:shadow-2xl hover:-translate-y-2 transition-all duration-300 relative overflow-hidden border-2 border-indigo-500 animate-slide-in-right">
          <div className="absolute top-0 right-0 bg-yellow-400 text-black text-sm font-semibold px-3 py-1 rounded-bl-lg animate-bounce">
            Most Popular
          </div>
          <h3 className="text-2xl font-semibold mb-2 text-gray-900 dark:text-white">Standard</h3>
          <p className="text-gray-600 dark:text-gray-400 mb-6">Perfect for businesses</p>
          <p className="text-5xl font-bold mb-8 text-gray-900 dark:text-white">
            ₹500<span className="text-lg font-medium text-gray-600 dark:text-gray-400">/mo</span>
          </p>
          <ul className="space-y-4 text-gray-700 dark:text-gray-300 mb-10">
            <li className="flex items-center gap-2 animate-fade-in" style={{ animationDelay: "0.1s" }}>
              <CheckCircle className="text-yellow-500 w-5 h-5" /> Everything in Basic
            </li>
            <li className="flex items-center gap-2 animate-fade-in" style={{ animationDelay: "0.2s" }}>
              <CheckCircle className="text-yellow-500 w-5 h-5" /> Priority support
            </li>
            <li className="flex items-center gap-2 animate-fade-in" style={{ animationDelay: "0.3s" }}>
              <CheckCircle className="text-yellow-500 w-5 h-5" /> Industry-specific rates
            </li>
          </ul>
          <button 
            onClick={() => handlePlanSelect("standard")}
            className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-90 hover:scale-105 text-white py-3 rounded-xl font-semibold text-lg transition-all transform active:scale-95"
          >
            Choose Plan
          </button>
        </div>
      </section>

      {/* Free Trial Section */}
      <section className="w-full flex justify-center max-w-5xl mx-auto mb-20 animate-fade-in" style={{ animationDelay: "0.4s" }}>
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-3xl p-10 text-center w-full shadow-2xl hover:scale-105 transition-transform duration-300">
          <h3 className="text-3xl font-bold mb-4 text-white animate-pulse">Start Your Free Trial</h3>
          <p className="text-white/90 mb-6">
            Experience all premium features for 7 days — no credit card required.
          </p>
          <button 
            onClick={handleFreeTrial}
            className="bg-white text-indigo-700 hover:bg-gray-100 hover:scale-110 py-3 px-8 rounded-xl font-semibold text-lg transition-all transform active:scale-95"
          >
            Start Free Trial
          </button>
        </div>
      </section>

      <section className="w-full flex justify-center max-w-5xl mx-auto mb-16 animate-slide-up" style={{ animationDelay: "0.5s" }}>
        <div className="text-center max-w-2xl">
          <p className="text-gray-600 dark:text-gray-400 text-lg">
            Need a custom plan? Contact our sales team for enterprise solutions tailored to your needs.
          </p>
          <button 
            onClick={handleContactSales}
            className="mt-6 bg-gradient-to-r from-indigo-600 to-purple-600 hover:opacity-90 hover:scale-110 text-white py-3 px-8 rounded-xl font-semibold text-lg transition-all transform active:scale-95"
          >
            Contact Sales
          </button>
        </div>      
      </section>

    </div>
  );
}
