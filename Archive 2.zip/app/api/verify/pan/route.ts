import { NextRequest, NextResponse } from "next/server";
import { deepvueService } from "@/lib/deepvue";
import { query } from "@/db/db";
import { getVerificationCost } from "@/lib/pricing";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, pan } = body;

    if (!userId || !pan) {
      return NextResponse.json(
        { success: false, error: "User ID and PAN are required" },
        { status: 400 }
      );
    }

    // Check cache first
    const cacheKey = pan.toUpperCase();
    const cacheResult = await query(
      "SELECT verification_data, access_count FROM verification_cache WHERE verification_type = $1 AND verification_key = $2",
      ["pan", cacheKey]
    );

    let deepvueResponse;
    let cacheHit = false;
    
    if (cacheResult.rows.length > 0) {
      // Cache hit - use cached data
      deepvueResponse = cacheResult.rows[0].verification_data;
      cacheHit = true;
      
      // Update cache access count and last accessed time
      await query(
        "UPDATE verification_cache SET access_count = access_count + 1, last_accessed_at = CURRENT_TIMESTAMP WHERE verification_type = $1 AND verification_key = $2",
        ["pan", cacheKey]
      );
    } else {
      // Cache miss - call DeepVue API
      deepvueResponse = await deepvueService.verifyPAN(pan);
      
      // Store in cache for future use
      await query(
        "INSERT INTO verification_cache (verification_type, verification_key, verification_data) VALUES ($1, $2, $3) ON CONFLICT (verification_type, verification_key) DO UPDATE SET verification_data = $3, last_accessed_at = CURRENT_TIMESTAMP",
        ["pan", cacheKey, JSON.stringify(deepvueResponse)]
      );
    }

    // Check wallet balance
    const walletResult = await query(
      "SELECT balance FROM wallets WHERE user_id = $1",
      [userId]
    );

    if (walletResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "Wallet not found" },
        { status: 404 }
      );
    }

    const currentBalance = parseFloat(walletResult.rows[0].balance);
    
    // Get verification cost based on user's pricing plan
    const verificationCost = await getVerificationCost(userId, "pan");

    if (currentBalance < verificationCost) {
      return NextResponse.json(
        { success: false, error: "Insufficient wallet balance" },
        { status: 400 }
      );
    }

    // Deduct amount from wallet
    await query(
      "UPDATE wallets SET balance = balance - $1 WHERE user_id = $2",
      [verificationCost, userId]
    );

    // Save verification history
    await query(
      `INSERT INTO verification_history 
       (user_id, verification_type, status, details, amount_charged) 
       VALUES ($1, $2, $3, $4, $5)`,
      [userId, "pan", "completed", JSON.stringify(deepvueResponse), verificationCost]
    );

    // Save to transactions table
    await query(
      `INSERT INTO transactions 
       (user_id, verification_type, amount, status, cache_hit, details) 
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [userId, "pan", verificationCost, "success", cacheHit, JSON.stringify(deepvueResponse)]
    );

    return NextResponse.json(
      {
        success: true,
        data: deepvueResponse,
        cacheHit,
        wallet: {
          amountDeducted: verificationCost,
          newBalance: currentBalance - verificationCost,
        },
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("PAN verification error:", error);
    // Record failed transaction
    try {
      const body = await request.json();
      await query(
        `INSERT INTO transactions 
         (user_id, verification_type, amount, status, details) 
         VALUES ($1, $2, $3, $4, $5)`,
        [body.userId, "pan", 0, "failed", JSON.stringify({ error: error.message })]
      );
    } catch (e) {
      console.error("Failed to record transaction:", e);
    }

    return NextResponse.json(
      { success: false, error: error.message || "Verification failed" },
      { status: 500 }
    );
  }
}
