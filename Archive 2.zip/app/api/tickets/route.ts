import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

// GET: Fetch user's support tickets
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");

    if (!userId) {
      return NextResponse.json(
        { success: false, error: "User ID is required" },
        { status: 400 }
      );
    }

    // Get user's tickets
    const ticketsResult = await query(
      `SELECT id, user_id, user_email, subject, description, category, 
              priority, status, admin_notes, created_at, updated_at, closed_at 
       FROM support_tickets 
       WHERE user_id = $1 
       ORDER BY created_at DESC`,
      [userId]
    );

    const tickets = ticketsResult.rows.map((row) => ({
      id: row.id,
      userId: row.user_id,
      userEmail: row.user_email,
      subject: row.subject,
      description: row.description,
      category: row.category,
      priority: row.priority,
      status: row.status,
      adminNotes: row.admin_notes,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
      closedAt: row.closed_at,
    }));

    return NextResponse.json(
      { success: true, tickets },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Tickets fetch error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to fetch tickets" },
      { status: 500 }
    );
  }
}

// POST: Create a new support ticket
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, userEmail, subject, description, category, priority } = body;

    if (!userId || !userEmail || !subject || !description) {
      return NextResponse.json(
        { success: false, error: "User ID, email, subject, and description are required" },
        { status: 400 }
      );
    }

    // Create ticket
    const ticketResult = await query(
      `INSERT INTO support_tickets 
       (user_id, user_email, subject, description, category, priority, status) 
       VALUES ($1, $2, $3, $4, $5, $6, $7) 
       RETURNING *`,
      [
        userId,
        userEmail,
        subject,
        description,
        category || "technical",
        priority || "medium",
        "open"
      ]
    );

    const ticket = ticketResult.rows[0];

    return NextResponse.json(
      {
        success: true,
        message: "Support ticket created successfully",
        ticket: {
          id: ticket.id,
          userId: ticket.user_id,
          userEmail: ticket.user_email,
          subject: ticket.subject,
          description: ticket.description,
          category: ticket.category,
          priority: ticket.priority,
          status: ticket.status,
          createdAt: ticket.created_at,
        },
      },
      { status: 201 }
    );
  } catch (error: any) {
    console.error("Ticket creation error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to create ticket" },
      { status: 500 }
    );
  }
}
