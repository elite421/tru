import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");

    if (!userId) {
      return NextResponse.json(
        { success: false, error: "User ID is required" },
        { status: 400 }
      );
    }

    // Get or create wallet for user
    const walletResult = await query(
      `SELECT * FROM wallets WHERE user_id = $1`,
      [userId]
    );

    let balance = 0;

    if (walletResult.rows.length === 0) {
      // Create wallet if it doesn't exist
      const createWallet = await query(
        `INSERT INTO wallets (user_id, balance) VALUES ($1, $2) RETURNING *`,
        [userId, 0]
      );
      balance = parseFloat(createWallet.rows[0].balance);
    } else {
      balance = parseFloat(walletResult.rows[0].balance);
    }

    return NextResponse.json(
      { success: true, balance },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Wallet balance error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to fetch wallet balance" },
      { status: 500 }
    );
  }
}
