import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");

    if (!userId) {
      return NextResponse.json(
        { success: false, error: "User ID is required" },
        { status: 400 }
      );
    }

    // Get user's pricing plan
    const userResult = await query(
      `SELECT pricing_plan_id FROM users WHERE id = $1`,
      [userId]
    );

    if (userResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "User not found" },
        { status: 404 }
      );
    }

    const pricingPlanId = userResult.rows[0].pricing_plan_id;

    if (!pricingPlanId) {
      // Return default pricing
      return NextResponse.json(
        {
          success: true,
          rates: [
            { verification_type: "email", price: 2 },
            { verification_type: "phone", price: 3 },
            { verification_type: "aadhar", price: 5 },
            { verification_type: "pan", price: 5 },
            { verification_type: "driving-license", price: 8 },
            { verification_type: "passport", price: 10 },
            { verification_type: "gst", price: 7 },
            { verification_type: "bank-account", price: 6 },
            { verification_type: "voter-id", price: 5 },
          ],
        },
        { status: 200 }
      );
    }

    // Get pricing plan rates
    const ratesResult = await query(
      `SELECT verification_type, price 
       FROM pricing_plan_rates 
       WHERE pricing_plan_id = $1`,
      [pricingPlanId]
    );

    const rates = ratesResult.rows.map((row) => ({
      verification_type: row.verification_type,
      price: parseFloat(row.price),
    }));

    return NextResponse.json(
      { success: true, rates },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Pricing plans error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to fetch pricing plans" },
      { status: 500 }
    );
  }
}
