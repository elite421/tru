import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

export async function GET(request: NextRequest) {
  try {
    // Fetch users with their pricing plans
    const usersResult = await query(
      `SELECT 
        u.id, 
        u.email, 
        u.phone, 
        u.full_name,
        u.created_at,
        u.pricing_plan_id,
        u.plan_expires_at,
        pp.name as plan_name
       FROM users u
       LEFT JOIN pricing_plans pp ON u.pricing_plan_id = pp.id
       ORDER BY u.created_at DESC`
    );

    const users = usersResult.rows.map((row) => ({
      id: row.id,
      email: row.email,
      phone: row.phone,
      fullName: row.full_name,
      createdAt: row.created_at,
      planName: row.plan_name,
      planExpiresAt: row.plan_expires_at,
    }));

    return NextResponse.json(
      { success: true, users },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Admin users fetch error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to fetch users" },
      { status: 500 }
    );
  }
}
