import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");

    let sql = `
      SELECT 
        cm.id,
        cm.user_id,
        cm.name,
        cm.email,
        cm.phone,
        cm.company_name,
        cm.subject,
        cm.message,
        cm.status,
        cm.admin_reply,
        cm.replied_at,
        cm.created_at,
        cm.updated_at,
        u.email as user_email
      FROM contact_messages cm
      LEFT JOIN users u ON cm.user_id = u.id
    `;

    const params = [];
    if (status && status !== "all") {
      sql += " WHERE cm.status = $1";
      params.push(status);
    }

    sql += " ORDER BY cm.created_at DESC LIMIT 100";

    const result = await query(sql, params);

    // Get statistics
    const statsResult = await query(`
      SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN status = 'unread' THEN 1 END) as unread,
        COUNT(CASE WHEN status = 'read' THEN 1 END) as read_count,
        COUNT(CASE WHEN status = 'replied' THEN 1 END) as replied,
        COUNT(CASE WHEN status = 'resolved' THEN 1 END) as resolved
      FROM contact_messages
    `);

    return NextResponse.json({
      success: true,
      messages: result.rows,
      stats: statsResult.rows[0]
    });
  } catch (error: any) {
    console.error("Contact messages fetch error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to fetch messages" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { name, email, phone, company_name, subject, message, user_id } = body;

    if (!name || !email || !message) {
      return NextResponse.json(
        { success: false, error: "Name, email, and message are required" },
        { status: 400 }
      );
    }

    const result = await query(
      `INSERT INTO contact_messages (user_id, name, email, phone, company_name, subject, message, status)
       VALUES ($1, $2, $3, $4, $5, $6, $7, 'unread')
       RETURNING *`,
      [user_id || null, name, email, phone || null, company_name || null, subject || null, message]
    );

    return NextResponse.json({
      success: true,
      message: result.rows[0]
    });
  } catch (error: any) {
    console.error("Contact message creation error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to create message" },
      { status: 500 }
    );
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, status, admin_reply } = body;

    if (!id) {
      return NextResponse.json(
        { success: false, error: "Message ID is required" },
        { status: 400 }
      );
    }

    let sql = "UPDATE contact_messages SET updated_at = CURRENT_TIMESTAMP";
    const params: any[] = [];
    let paramIndex = 1;

    if (status) {
      sql += `, status = $${paramIndex}`;
      params.push(status);
      paramIndex++;
    }

    if (admin_reply !== undefined) {
      sql += `, admin_reply = $${paramIndex}, replied_at = CURRENT_TIMESTAMP`;
      params.push(admin_reply);
      paramIndex++;
    }

    sql += ` WHERE id = $${paramIndex} RETURNING *`;
    params.push(id);

    const result = await query(sql, params);

    if (result.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "Message not found" },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      message: result.rows[0]
    });
  } catch (error: any) {
    console.error("Contact message update error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to update message" },
      { status: 500 }
    );
  }
}
