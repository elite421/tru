import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const status = searchParams.get("status");
    const priority = searchParams.get("priority");

    let sql = `
      SELECT 
        st.id,
        st.user_id,
        st.user_email,
        st.subject,
        st.description,
        st.category,
        st.priority,
        st.status,
        st.admin_notes,
        st.assigned_to,
        st.created_at,
        st.updated_at,
        st.closed_at,
        u.full_name as user_name
      FROM support_tickets st
      LEFT JOIN users u ON st.user_id = u.id
      WHERE 1=1
    `;

    const params = [];
    let paramIndex = 1;

    if (status && status !== "all") {
      sql += ` AND st.status = $${paramIndex}`;
      params.push(status);
      paramIndex++;
    }

    if (priority && priority !== "all") {
      sql += ` AND st.priority = $${paramIndex}`;
      params.push(priority);
      paramIndex++;
    }

    sql += " ORDER BY st.created_at DESC LIMIT 100";

    const result = await query(sql, params);

    // Get statistics
    const statsResult = await query(`
      SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN status = 'open' THEN 1 END) as open_count,
        COUNT(CASE WHEN status = 'in-progress' THEN 1 END) as in_progress,
        COUNT(CASE WHEN status = 'closed' THEN 1 END) as closed_count,
        COUNT(CASE WHEN priority = 'urgent' THEN 1 END) as urgent,
        COUNT(CASE WHEN priority = 'high' THEN 1 END) as high
      FROM support_tickets
    `);

    return NextResponse.json({
      success: true,
      tickets: result.rows,
      stats: statsResult.rows[0]
    });
  } catch (error: any) {
    console.error("Tickets fetch error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to fetch tickets" },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { user_id, user_email, subject, description, category, priority } = body;

    if (!user_email || !subject || !description) {
      return NextResponse.json(
        { success: false, error: "Email, subject, and description are required" },
        { status: 400 }
      );
    }

    const result = await query(
      `INSERT INTO support_tickets (user_id, user_email, subject, description, category, priority, status)
       VALUES ($1, $2, $3, $4, $5, $6, 'open')
       RETURNING *`,
      [user_id || null, user_email, subject, description, category || 'technical', priority || 'medium']
    );

    return NextResponse.json({
      success: true,
      ticket: result.rows[0]
    });
  } catch (error: any) {
    console.error("Ticket creation error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to create ticket" },
      { status: 500 }
    );
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json();
    const { id, status, priority, admin_notes, assigned_to } = body;

    if (!id) {
      return NextResponse.json(
        { success: false, error: "Ticket ID is required" },
        { status: 400 }
      );
    }

    let sql = "UPDATE support_tickets SET updated_at = CURRENT_TIMESTAMP";
    const params: any[] = [];
    let paramIndex = 1;

    if (status) {
      sql += `, status = $${paramIndex}`;
      params.push(status);
      paramIndex++;
      
      if (status === 'closed') {
        sql += `, closed_at = CURRENT_TIMESTAMP`;
      }
    }

    if (priority) {
      sql += `, priority = $${paramIndex}`;
      params.push(priority);
      paramIndex++;
    }

    if (admin_notes !== undefined) {
      sql += `, admin_notes = $${paramIndex}`;
      params.push(admin_notes);
      paramIndex++;
    }

    if (assigned_to !== undefined) {
      sql += `, assigned_to = $${paramIndex}`;
      params.push(assigned_to);
      paramIndex++;
    }

    sql += ` WHERE id = $${paramIndex} RETURNING *`;
    params.push(id);

    const result = await query(sql, params);

    if (result.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "Ticket not found" },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      ticket: result.rows[0]
    });
  } catch (error: any) {
    console.error("Ticket update error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to update ticket" },
      { status: 500 }
    );
  }
}
