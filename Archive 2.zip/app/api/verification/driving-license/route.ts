import { NextRequest, NextResponse } from "next/server";
import { deepvueService } from "@/lib/deepvue";
import { query } from "@/db/db";
import { calculateGST, extractDeepVueTransactionId } from "@/lib/gstCalculation";
import { getUserVerificationPrice } from "@/lib/pricing";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, licenseNumber, dob, action, requestId } = body;

    if (!userId) {
      return NextResponse.json(
        { success: false, error: "User ID is required" },
        { status: 400 }
      );
    }

    // Step 1: Post verification request
    if (!action || action === "post") {
      if (!licenseNumber || !dob) {
        return NextResponse.json(
          { success: false, error: "License number and date of birth are required" },
          { status: 400 }
        );
      }

      // Validate date format (YYYY-MM-DD)
      const dateRegex = /^\d{4}-\d{2}-\d{2}$/;
      if (!dateRegex.test(dob)) {
        return NextResponse.json(
          { success: false, error: "Invalid date format. Use YYYY-MM-DD" },
          { status: 400 }
        );
      }

      const postResponse = await deepvueService.postDrivingLicense(licenseNumber, dob);

      return NextResponse.json(
        {
          success: true,
          action: "verification_posted",
          requestId: postResponse.request_id || postResponse.data?.request_id,
          message: "Verification request submitted. Use the request ID to fetch results.",
        },
        { status: 200 }
      );
    }

    // Step 2: Get verification results
    if (action === "get") {
      if (!requestId) {
        return NextResponse.json(
          { success: false, error: "Request ID is required" },
          { status: 400 }
        );
      }

      const getResponse = await deepvueService.getDrivingLicense(requestId);

      // Check if verification is complete
      if (getResponse.status === "pending" || getResponse.data?.status === "pending") {
        return NextResponse.json(
          {
            success: true,
            status: "pending",
            message: "Verification in progress. Please try again in a few moments.",
          },
          { status: 200 }
        );
      }

      // Get user-specific or default pricing from database
      const basePrice = await getUserVerificationPrice(userId, "driving-license");
      if (basePrice === null) {
        return NextResponse.json(
          { success: false, error: "Pricing not available for this verification type" },
          { status: 500 }
        );
      }

      // Calculate GST (18%)
      const gstBreakdown = calculateGST(basePrice);

      // Check wallet balance
      const walletResult = await query(
        "SELECT * FROM wallets WHERE user_id = $1",
        [userId]
      );

      if (walletResult.rows.length === 0) {
        return NextResponse.json(
          { success: false, error: "Wallet not found" },
          { status: 404 }
        );
      }

      const currentBalance = parseFloat(walletResult.rows[0].balance);

      if (currentBalance < gstBreakdown.totalAmount) {
        return NextResponse.json(
          { success: false, error: `Insufficient wallet balance. Required: ₹${gstBreakdown.totalAmount} (Base: ₹${gstBreakdown.baseAmount} + GST: ₹${gstBreakdown.gstAmount})` },
          { status: 400 }
        );
      }

      // Extract DeepVue transaction ID
      const deepvueTransactionId = extractDeepVueTransactionId(getResponse);

      const wallet = walletResult.rows[0];
      const newBalance = currentBalance - gstBreakdown.totalAmount;

      // Deduct amount from wallet
      await query(
        "UPDATE wallets SET balance = $1 WHERE id = $2",
        [newBalance, wallet.id]
      );

      // Record wallet transaction with GST breakdown
      await query(
        `INSERT INTO wallet_transactions 
         (wallet_id, user_id, transaction_type, amount, base_amount, gst_amount, gst_percentage, deepvue_transaction_id, balance_before, balance_after, description, reference_type, status) 
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`,
        [
          wallet.id,
          userId,
          "debit",
          gstBreakdown.totalAmount,
          gstBreakdown.baseAmount,
          gstBreakdown.gstAmount,
          gstBreakdown.gstPercentage,
          deepvueTransactionId,
          currentBalance,
          newBalance,
          `Driving License verification - Base: ₹${gstBreakdown.baseAmount}, GST (18%): ₹${gstBreakdown.gstAmount}`,
          "verification",
          "completed"
        ]
      );

      // Save verification record
      await query(
        `INSERT INTO verification_history 
         (user_id, verification_type, status, details, amount_charged) 
         VALUES ($1, $2, $3, $4, $5)`,
        [
          userId,
          "driving-license",
          "completed",
          JSON.stringify(getResponse),
          gstBreakdown.totalAmount,
        ]
      );

      // Save to transactions table with GST breakdown
      await query(
        `INSERT INTO transactions 
         (user_id, verification_type, amount, base_amount, gst_amount, gst_percentage, deepvue_transaction_id, status, cache_hit, details) 
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
        [
          userId,
          "driving-license",
          gstBreakdown.totalAmount,
          gstBreakdown.baseAmount,
          gstBreakdown.gstAmount,
          gstBreakdown.gstPercentage,
          deepvueTransactionId,
          "success",
          false,
          JSON.stringify(getResponse)
        ]
      );

      return NextResponse.json(
        {
          success: true,
          data: getResponse,
          deepvueTransactionId,
          wallet: {
            baseAmount: gstBreakdown.baseAmount,
            gstAmount: gstBreakdown.gstAmount,
            gstPercentage: gstBreakdown.gstPercentage,
            totalAmount: gstBreakdown.totalAmount,
            amountDeducted: gstBreakdown.totalAmount,
            newBalance,
          },
        },
        { status: 200 }
      );
    }

    return NextResponse.json(
      { success: false, error: "Invalid action. Use 'post' or 'get'" },
      { status: 400 }
    );
  } catch (error: any) {
    console.error("Driving license verification error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Verification failed" },
      { status: 500 }
    );
  }
}
