import { NextRequest, NextResponse } from "next/server";
import { deepvueService } from "@/lib/deepvue";
import { query } from "@/db/db";
import { calculateGST, extractDeepVueTransactionId } from "@/lib/gstCalculation";
import { getUserVerificationPrice } from "@/lib/pricing";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, gstinNumber } = body;

    if (!userId || !gstinNumber) {
      return NextResponse.json(
        { success: false, error: "User ID and GSTIN number are required" },
        { status: 400 }
      );
    }

    const gstinRegex = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
    if (!gstinRegex.test(gstinNumber)) {
      return NextResponse.json(
        { success: false, error: "Invalid GSTIN format" },
        { status: 400 }
      );
    }

    // Get user-specific or default pricing from database
    const basePrice = await getUserVerificationPrice(userId, "gst-advanced");
    if (basePrice === null) {
      return NextResponse.json(
        { success: false, error: "Pricing not available for this verification type" },
        { status: 500 }
      );
    }

    // Calculate GST (18%)
    const gstBreakdown = calculateGST(basePrice);

    const cacheKey = gstinNumber.toUpperCase();
    const cacheResult = await query(
      "SELECT verification_data FROM verification_cache WHERE verification_type = $1 AND verification_key = $2",
      ["gst_advanced", cacheKey]
    );

    let deepvueResponse;
    let cacheHit = false;
    
    if (cacheResult.rows.length > 0) {
      deepvueResponse = cacheResult.rows[0].verification_data;
      cacheHit = true;
      await query(
        "UPDATE verification_cache SET access_count = access_count + 1, last_accessed_at = CURRENT_TIMESTAMP WHERE verification_type = $1 AND verification_key = $2",
        ["gst_advanced", cacheKey]
      );
    } else {
      deepvueResponse = await deepvueService.verifyGSTAdvanced(gstinNumber);
      await query(
        "INSERT INTO verification_cache (verification_type, verification_key, verification_data) VALUES ($1, $2, $3) ON CONFLICT (verification_type, verification_key) DO UPDATE SET verification_data = $3, last_accessed_at = CURRENT_TIMESTAMP",
        ["gst_advanced", cacheKey, JSON.stringify(deepvueResponse)]
      );
    }

    const walletResult = await query(
      "SELECT balance FROM wallets WHERE user_id = $1",
      [userId]
    );

    if (walletResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "Wallet not found" },
        { status: 404 }
      );
    }

    const currentBalance = parseFloat(walletResult.rows[0].balance);

    if (currentBalance < gstBreakdown.totalAmount) {
      return NextResponse.json(
        { success: false, error: "Insufficient wallet balance" },
        { status: 400 }
      );
    }

    await query(
      "UPDATE wallets SET balance = balance - $1 WHERE user_id = $2",
      [gstBreakdown.totalAmount, userId]
    );

    await query(
      `INSERT INTO verification_history 
       (user_id, verification_type, status, details, amount_charged) 
       VALUES ($1, $2, $3, $4, $5)`,
      [userId, "gst_advanced", "completed", JSON.stringify(deepvueResponse), gstBreakdown.totalAmount]
    );

    await query(
      `INSERT INTO transactions 
       (user_id, verification_type, amount, base_amount, gst_amount, gst_percentage, status, cache_hit, details) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
      [userId, "gst_advanced", gstBreakdown.totalAmount, gstBreakdown.baseAmount, gstBreakdown.gstAmount, gstBreakdown.gstPercentage, "success", cacheHit, JSON.stringify(deepvueResponse)]
    );

    return NextResponse.json(
      {
        success: true,
        data: deepvueResponse,
        cacheHit,
        wallet: {
          baseAmount: gstBreakdown.baseAmount,
          gstAmount: gstBreakdown.gstAmount,
          gstPercentage: gstBreakdown.gstPercentage,
          totalAmount: gstBreakdown.totalAmount,
          amountDeducted: gstBreakdown.totalAmount,
          newBalance: currentBalance - gstBreakdown.totalAmount,
        },
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("GST Advanced verification error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Verification failed" },
      { status: 500 }
    );
  }
}
