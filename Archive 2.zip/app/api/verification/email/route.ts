import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";
import { deepvueService } from "@/lib/deepvue";
import { calculateGST } from "@/lib/gstCalculation";
import { getUserVerificationPrice } from "@/lib/pricing";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, email, action, otp } = body;

    if (!userId || !email) {
      return NextResponse.json(
        { success: false, error: "User ID and email are required" },
        { status: 400 }
      );
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { success: false, error: "Invalid email format" },
        { status: 400 }
      );
    }

    // Check cache first
    const cacheKey = email.toLowerCase();
    const cacheResult = await query(
      "SELECT verification_data FROM verification_cache WHERE verification_type = $1 AND verification_key = $2",
      ["email", cacheKey]
    );

    let verificationData;
    let cacheHit = false;
    
    if (cacheResult.rows.length > 0) {
      verificationData = cacheResult.rows[0].verification_data;
      cacheHit = true;
      await query(
        "UPDATE verification_cache SET access_count = access_count + 1, last_accessed_at = CURRENT_TIMESTAMP WHERE verification_type = $1 AND verification_key = $2",
        ["email", cacheKey]
      );
    } else {
      // Call DeepVue API
      verificationData = await deepvueService.verifyEmail(email);
      
      // Store in cache
      await query(
        "INSERT INTO verification_cache (verification_type, verification_key, verification_data) VALUES ($1, $2, $3) ON CONFLICT (verification_type, verification_key) DO UPDATE SET verification_data = $3, last_accessed_at = CURRENT_TIMESTAMP",
        ["email", cacheKey, JSON.stringify(verificationData)]
      );
    }

    // Step 1: Generate OTP
    if (!action || action === "generate_otp") {
      const generatedOTP = Math.floor(100000 + Math.random() * 900000).toString();
      // Get user-specific or default pricing from database
      const basePrice = await getUserVerificationPrice(userId, "email");
      if (basePrice === null) {
        return NextResponse.json(
          { success: false, error: "Pricing not available for this verification type" },
          { status: 500 }
        );
      }

      const gstBreakdown = calculateGST(basePrice);
      const expires = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

      // Store OTP in database
      await query(
        `INSERT INTO otp_verifications (email, otp, expires_at, created_at) 
         VALUES ($1, $2, $3, CURRENT_TIMESTAMP) 
         ON CONFLICT (email) 
         DO UPDATE SET otp = $2, expires_at = $3, created_at = CURRENT_TIMESTAMP`,
        [email, generatedOTP, expires]
      );

      // In production, send email here
      console.log(`OTP for ${email}: ${generatedOTP}`);

      return NextResponse.json(
        {
          success: true,
          action: "otp_generated",
          message: "OTP sent to email",
          // For demo purposes only - remove in production
          otp: generatedOTP,
        },
        { status: 200 }
      );
    }

    // Step 2: Verify OTP
    if (action === "verify_otp") {
      if (!otp) {
        return NextResponse.json(
          { success: false, error: "OTP is required" },
          { status: 400 }
        );
      }

      // Retrieve OTP from database
      const otpResult = await query(
        "SELECT otp, expires_at FROM otp_verifications WHERE email = $1",
        [email]
      );

      if (otpResult.rows.length === 0) {
        return NextResponse.json(
          { success: false, error: "OTP not found or expired" },
          { status: 400 }
        );
      }

      const storedOtpData = otpResult.rows[0];

      if (new Date() > new Date(storedOtpData.expires_at)) {
        await query("DELETE FROM otp_verifications WHERE email = $1", [email]);
        return NextResponse.json(
          { success: false, error: "OTP expired" },
          { status: 400 }
        );
      }

      if (storedOtpData.otp !== otp) {
        return NextResponse.json(
          { success: false, error: "Invalid OTP" },
          { status: 400 }
        );
      }

      // OTP verified, remove from database
      await query("DELETE FROM otp_verifications WHERE email = $1", [email]);

      // Check wallet balance
      const walletResult = await query(
        "SELECT balance FROM wallets WHERE user_id = $1",
        [userId]
      );

      if (walletResult.rows.length === 0) {
        return NextResponse.json(
          { success: false, error: "Wallet not found" },
          { status: 404 }
        );
      }

      const currentBalance = parseFloat(walletResult.rows[0].balance);
      const verificationCost = 2; // ₹2 for email verification

      if (currentBalance < verificationCost) {
        return NextResponse.json(
          { success: false, error: "Insufficient wallet balance" },
          { status: 400 }
        );
      }

      // Deduct amount from wallet
      await query(
        "UPDATE wallets SET balance = balance - $1 WHERE user_id = $2",
        [verificationCost, userId]
      );

      // Save verification record
      await query(
        `INSERT INTO verification_history 
         (user_id, verification_type, status, details, amount_charged) 
         VALUES ($1, $2, $3, $4, $5)`,
        [
          userId,
          "email",
          "completed",
          JSON.stringify({ email, verified: true }),
          verificationCost,
        ]
      );

      // Save to transactions table
      await query(
        `INSERT INTO transactions 
         (user_id, verification_type, amount, status, cache_hit, details) 
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [userId, "email", verificationCost, "success", cacheHit, JSON.stringify(verificationData)]
      );

      return NextResponse.json(
        {
          success: true,
          data: verificationData,
          cacheHit,
          wallet: {
            amountDeducted: verificationCost,
            newBalance: currentBalance - verificationCost,
          },
        },
        { status: 200 }
      );
    }

    return NextResponse.json(
      { success: false, error: "Invalid action" },
      { status: 400 }
    );
  } catch (error: any) {
    console.error("Email verification error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Verification failed" },
      { status: 500 }
    );
  }
}
