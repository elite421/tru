import { NextRequest, NextResponse } from "next/server";
import { deepvueService } from "@/lib/deepvue";
import { query } from "@/db/db";
import { getCachedOrFetch } from "@/lib/verificationCache";
import { calculateGST, extractDeepVueTransactionId } from "@/lib/gstCalculation";
import { getUserVerificationPrice } from "@/lib/pricing";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, panNumber } = body;

    if (!userId || !panNumber) {
      return NextResponse.json(
        { success: false, error: "User ID and PAN number are required" },
        { status: 400 }
      );
    }

    // Validate PAN format
    const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]$/;
    if (!panRegex.test(panNumber)) {
      return NextResponse.json(
        { success: false, error: "Invalid PAN format" },
        { status: 400 }
      );
    }

    // Get user-specific or default pricing from database
    const basePrice = await getUserVerificationPrice(userId, "tds-compliance");
    if (basePrice === null) {
      return NextResponse.json(
        { success: false, error: "Pricing not available for this verification type" },
        { status: 500 }
      );
    }

    const gstBreakdown = calculateGST(basePrice);
    const cacheKey = panNumber.toUpperCase();
    const cacheResult = await query(
      "SELECT verification_data FROM verification_cache WHERE verification_type = $1 AND verification_key = $2",
      ["tds_compliance", cacheKey]
    );

    let deepvueResponse;
    let cacheHit = false;
    
    if (cacheResult.rows.length > 0) {
      deepvueResponse = cacheResult.rows[0].verification_data;
      cacheHit = true;
      await query(
        "UPDATE verification_cache SET access_count = access_count + 1, last_accessed_at = CURRENT_TIMESTAMP WHERE verification_type = $1 AND verification_key = $2",
        ["tds_compliance", cacheKey]
      );
    } else {
      deepvueResponse = await deepvueService.checkTDSCompliance(panNumber);
      await query(
        "INSERT INTO verification_cache (verification_type, verification_key, verification_data) VALUES ($1, $2, $3) ON CONFLICT (verification_type, verification_key) DO UPDATE SET verification_data = $3, last_accessed_at = CURRENT_TIMESTAMP",
        ["tds_compliance", cacheKey, JSON.stringify(deepvueResponse)]
      );
    }

    const walletResult = await query(
      "SELECT balance FROM wallets WHERE user_id = $1",
      [userId]
    );

    if (walletResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "Wallet not found" },
        { status: 404 }
      );
    }

    const currentBalance = parseFloat(walletResult.rows[0].balance);
    const verificationCost = 7;

    if (currentBalance < verificationCost) {
      return NextResponse.json(
        { success: false, error: "Insufficient wallet balance" },
        { status: 400 }
      );
    }

    await query(
      "UPDATE wallets SET balance = balance - $1 WHERE user_id = $2",
      [verificationCost, userId]
    );

    await query(
      `INSERT INTO verification_history 
       (user_id, verification_type, status, details, amount_charged) 
       VALUES ($1, $2, $3, $4, $5)`,
      [userId, "tds_compliance", "completed", JSON.stringify(deepvueResponse), verificationCost]
    );

    await query(
      `INSERT INTO transactions 
       (user_id, verification_type, amount, status, cache_hit, details) 
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [userId, "tds_compliance", verificationCost, "success", cacheHit, JSON.stringify(deepvueResponse)]
    );

    return NextResponse.json(
      {
        success: true,
        data: deepvueResponse,
        cacheHit,
        wallet: {
          amountDeducted: verificationCost,
          newBalance: currentBalance - verificationCost,
        },
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("TDS compliance check error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Verification failed" },
      { status: 500 }
    );
  }
}
