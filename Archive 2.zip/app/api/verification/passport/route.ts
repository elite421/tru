import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";
import { calculateGST, extractDeepVueTransactionId } from "@/lib/gstCalculation";

const BASE_VERIFICATION_COST = 10;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, passportNumber, dateOfBirth } = body;

    if (!userId || !passportNumber || !dateOfBirth) {
      return NextResponse.json(
        { success: false, error: "User ID, passport number, and date of birth are required" },
        { status: 400 }
      );
    }

    // Validate passport format (typically 8 characters: 1 letter followed by 7 digits)
    const passportRegex = /^[A-Z][0-9]{7}$/;
    if (!passportRegex.test(passportNumber)) {
      return NextResponse.json(
        { success: false, error: "Invalid passport format. Expected format: A1234567" },
        { status: 400 }
      );
    }

    // Calculate GST (18%)
    const gstBreakdown = calculateGST(BASE_VERIFICATION_COST);

    // Check wallet balance
    const walletResult = await query(
      "SELECT * FROM wallets WHERE user_id = $1",
      [userId]
    );

    if (walletResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "Wallet not found" },
        { status: 404 }
      );
    }

    const currentBalance = parseFloat(walletResult.rows[0].balance);

    if (currentBalance < gstBreakdown.totalAmount) {
      return NextResponse.json(
        { success: false, error: `Insufficient wallet balance. Required: ₹${gstBreakdown.totalAmount} (Base: ₹${gstBreakdown.baseAmount} + GST: ₹${gstBreakdown.gstAmount})` },
        { status: 400 }
      );
    }

    // Mock passport verification (DeepVue doesn't have direct passport API)
    const mockResponse = {
      success: true,
      data: {
        passportNumber: passportNumber,
        type: "Ordinary",
        dateOfBirth: dateOfBirth,
        dateOfIssue: "2020-01-15",
        dateOfExpiry: "2030-01-14",
        placeOfIssue: "New Delhi",
        country: "India",
        status: "Active",
        isValid: true,
      }
    };

    // Extract transaction ID (mock won't have one, but keeping pattern consistent)
    const deepvueTransactionId = extractDeepVueTransactionId(mockResponse);

    const wallet = walletResult.rows[0];
    const newBalance = currentBalance - gstBreakdown.totalAmount;

    // Deduct amount from wallet
    await query(
      "UPDATE wallets SET balance = $1 WHERE id = $2",
      [newBalance, wallet.id]
    );

    // Record wallet transaction with GST breakdown
    await query(
      `INSERT INTO wallet_transactions 
       (wallet_id, user_id, transaction_type, amount, base_amount, gst_amount, gst_percentage, deepvue_transaction_id, balance_before, balance_after, description, reference_type, status) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`,
      [
        wallet.id,
        userId,
        "debit",
        gstBreakdown.totalAmount,
        gstBreakdown.baseAmount,
        gstBreakdown.gstAmount,
        gstBreakdown.gstPercentage,
        deepvueTransactionId,
        currentBalance,
        newBalance,
        `Passport verification - Base: ₹${gstBreakdown.baseAmount}, GST (18%): ₹${gstBreakdown.gstAmount}`,
        "verification",
        "completed"
      ]
    );

    // Save verification record
    await query(
      `INSERT INTO verification_history 
       (user_id, verification_type, status, details, amount_charged) 
       VALUES ($1, $2, $3, $4, $5)`,
      [
        userId,
        "passport",
        "completed",
        JSON.stringify(mockResponse),
        gstBreakdown.totalAmount,
      ]
    );

    // Save to transactions table with GST breakdown
    await query(
      `INSERT INTO transactions 
       (user_id, verification_type, amount, base_amount, gst_amount, gst_percentage, deepvue_transaction_id, status, cache_hit, details) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
      [
        userId,
        "passport",
        gstBreakdown.totalAmount,
        gstBreakdown.baseAmount,
        gstBreakdown.gstAmount,
        gstBreakdown.gstPercentage,
        deepvueTransactionId,
        "success",
        false,
        JSON.stringify(mockResponse)
      ]
    );

    return NextResponse.json(
      {
        success: true,
        data: mockResponse.data,
        deepvueTransactionId,
        wallet: {
          baseAmount: gstBreakdown.baseAmount,
          gstAmount: gstBreakdown.gstAmount,
          gstPercentage: gstBreakdown.gstPercentage,
          totalAmount: gstBreakdown.totalAmount,
          amountDeducted: gstBreakdown.totalAmount,
          newBalance,
        },
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Passport verification error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Verification failed" },
      { status: 500 }
    );
  }
}
