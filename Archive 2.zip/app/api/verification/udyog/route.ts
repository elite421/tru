import { NextRequest, NextResponse } from "next/server";
import { deepvueService } from "@/lib/deepvue";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { step, udyogAadhaarNumber, requestId } = body;

    if (step === "post") {
      // Step 1: Post Udyog request
      if (!udyogAadhaarNumber) {
        return NextResponse.json(
          { success: false, error: "Udyog Aadhaar number is required" },
          { status: 400 }
        );
      }

      const result = await deepvueService.postUdyogDetails(udyogAadhaarNumber);

      return NextResponse.json({
        success: true,
        data: result,
        message: "Udyog verification request submitted. Use request_id to fetch results.",
      });
    } else if (step === "get") {
      // Step 2: Get Udyog results
      if (!requestId) {
        return NextResponse.json(
          { success: false, error: "Request ID is required" },
          { status: 400 }
        );
      }

      const result = await deepvueService.getUdyogDetails(requestId);

      return NextResponse.json({
        success: true,
        data: result,
      });
    } else {
      return NextResponse.json(
        { success: false, error: "Invalid step. Use 'post' or 'get'" },
        { status: 400 }
      );
    }
  } catch (error: any) {
    console.error("Udyog verification error:", error);
    return NextResponse.json(
      {
        success: false,
        error: error.message || "Failed to verify Udyog",
      },
      { status: 500 }
    );
  }
}
