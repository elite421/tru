import { NextRequest, NextResponse } from "next/server";
import { deepvueService } from "@/lib/deepvue";
import { query } from "@/db/db";
import { getCachedOrFetch } from "@/lib/verificationCache";
import { calculateGST, extractDeepVueTransactionId } from "@/lib/gstCalculation";

const BASE_VERIFICATION_COST = 5;

// Generate OTP for Aadhar verification
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, aadhar, action, otp, referenceId } = body;

    if (!userId || !aadhar) {
      return NextResponse.json(
        { success: false, error: "User ID and Aadhar number are required" },
        { status: 400 }
      );
    }

    // Validate Aadhar format (12 digits)
    const aadharRegex = /^[0-9]{12}$/;
    if (!aadharRegex.test(aadhar)) {
      return NextResponse.json(
        { success: false, error: "Invalid Aadhar format. Must be 12 digits" },
        { status: 400 }
      );
    }

    // Step 1: Generate OTP
    if (!action || action === "generate_otp") {
      const otpResponse = await deepvueService.generateAadhaarOTP(aadhar);

      return NextResponse.json(
        {
          success: true,
          action: "otp_generated",
          referenceId: otpResponse.reference_id || otpResponse.data?.reference_id,
          message: "OTP sent to registered mobile number",
        },
        { status: 200 }
      );
    }

    // Step 2: Verify OTP
    if (action === "verify_otp") {
      if (!otp || !referenceId) {
        return NextResponse.json(
          { success: false, error: "OTP and reference ID are required" },
          { status: 400 }
        );
      }

      // Calculate GST (18%)
      const gstBreakdown = calculateGST(BASE_VERIFICATION_COST);

      // Check wallet balance
      const walletResult = await query(
        "SELECT * FROM wallets WHERE user_id = $1",
        [userId]
      );

      if (walletResult.rows.length === 0) {
        return NextResponse.json(
          { success: false, error: "Wallet not found" },
          { status: 404 }
        );
      }

      const currentBalance = parseFloat(walletResult.rows[0].balance);

      if (currentBalance < gstBreakdown.totalAmount) {
        return NextResponse.json(
          { success: false, error: `Insufficient wallet balance. Required: ₹${gstBreakdown.totalAmount} (Base: ₹${gstBreakdown.baseAmount} + GST: ₹${gstBreakdown.gstAmount})` },
          { status: 400 }
        );
      }

      // Get cached or fresh verification data
      const cacheKey = aadhar.replace(/\s/g, '');
      const { data: verifyResponse, cacheHit } = await getCachedOrFetch(
        "aadhar",
        cacheKey,
        () => deepvueService.verifyAadhaarOTP(otp, referenceId)
      );

      // Extract DeepVue transaction ID
      const deepvueTransactionId = extractDeepVueTransactionId(verifyResponse);

      const wallet = walletResult.rows[0];
      const newBalance = currentBalance - gstBreakdown.totalAmount;

      // Deduct amount from wallet
      await query(
        "UPDATE wallets SET balance = $1 WHERE id = $2",
        [newBalance, wallet.id]
      );

      // Record wallet transaction with GST breakdown
      await query(
        `INSERT INTO wallet_transactions 
         (wallet_id, user_id, transaction_type, amount, base_amount, gst_amount, gst_percentage, deepvue_transaction_id, balance_before, balance_after, description, reference_type, status) 
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`,
        [
          wallet.id,
          userId,
          "debit",
          gstBreakdown.totalAmount,
          gstBreakdown.baseAmount,
          gstBreakdown.gstAmount,
          gstBreakdown.gstPercentage,
          deepvueTransactionId,
          currentBalance,
          newBalance,
          `Aadhar verification${cacheHit ? ' (cached)' : ''} - Base: ₹${gstBreakdown.baseAmount}, GST (18%): ₹${gstBreakdown.gstAmount}`,
          "verification",
          "completed"
        ]
      );

      // Save verification record
      await query(
        `INSERT INTO verification_history 
         (user_id, verification_type, status, details, amount_charged) 
         VALUES ($1, $2, $3, $4, $5)`,
        [
          userId,
          "aadhar",
          verifyResponse.success ? "completed" : "failed",
          JSON.stringify(verifyResponse),
          gstBreakdown.totalAmount,
        ]
      );

      // Save to transactions table with GST breakdown
      await query(
        `INSERT INTO transactions 
         (user_id, verification_type, amount, base_amount, gst_amount, gst_percentage, deepvue_transaction_id, status, cache_hit, details) 
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
        [
          userId,
          "aadhar",
          gstBreakdown.totalAmount,
          gstBreakdown.baseAmount,
          gstBreakdown.gstAmount,
          gstBreakdown.gstPercentage,
          deepvueTransactionId,
          "success",
          cacheHit,
          JSON.stringify(verifyResponse)
        ]
      );

      return NextResponse.json(
        {
          success: true,
          data: verifyResponse,
          cacheHit,
          deepvueTransactionId,
          wallet: {
            baseAmount: gstBreakdown.baseAmount,
            gstAmount: gstBreakdown.gstAmount,
            gstPercentage: gstBreakdown.gstPercentage,
            totalAmount: gstBreakdown.totalAmount,
            amountDeducted: gstBreakdown.totalAmount,
            newBalance,
          },
        },
        { status: 200 }
      );
    }

    return NextResponse.json(
      { success: false, error: "Invalid action" },
      { status: 400 }
    );
  } catch (error: any) {
    console.error("Aadhar verification error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Verification failed" },
      { status: 500 }
    );
  }
}
