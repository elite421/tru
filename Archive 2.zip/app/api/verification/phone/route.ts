import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";
import { deepvueService } from "@/lib/deepvue";
import { getCachedOrFetch } from "@/lib/verificationCache";
import { calculateGST, extractDeepVueTransactionId } from "@/lib/gstCalculation";

const BASE_VERIFICATION_COST = 3;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, phone } = body;

    if (!userId || !phone) {
      return NextResponse.json(
        { success: false, error: "User ID and phone number are required" },
        { status: 400 }
      );
    }

    // Validate phone format (10 digits)
    const phoneRegex = /^[0-9]{10}$/;
    if (!phoneRegex.test(phone)) {
      return NextResponse.json(
        { success: false, error: "Invalid phone format. Must be 10 digits" },
        { status: 400 }
      );
    }

    // Calculate GST (18%)
    const gstBreakdown = calculateGST(BASE_VERIFICATION_COST);

    // Check wallet balance
    const walletResult = await query(
      "SELECT * FROM wallets WHERE user_id = $1",
      [userId]
    );

    if (walletResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "Wallet not found" },
        { status: 404 }
      );
    }

    const currentBalance = parseFloat(walletResult.rows[0].balance);

    if (currentBalance < gstBreakdown.totalAmount) {
      return NextResponse.json(
        { success: false, error: `Insufficient wallet balance. Required: ₹${gstBreakdown.totalAmount} (Base: ₹${gstBreakdown.baseAmount} + GST: ₹${gstBreakdown.gstAmount})` },
        { status: 400 }
      );
    }

    // Get cached or fresh verification data
    const cacheKey = phone.replace(/\D/g, '');
    const { data: verificationData, cacheHit } = await getCachedOrFetch(
      "phone",
      cacheKey,
      () => deepvueService.verifyPhone(phone)
    );

    // Extract DeepVue transaction ID
    const deepvueTransactionId = extractDeepVueTransactionId(verificationData);

    const wallet = walletResult.rows[0];
    const newBalance = currentBalance - gstBreakdown.totalAmount;

    // Deduct from wallet
    await query(
      "UPDATE wallets SET balance = $1 WHERE id = $2",
      [newBalance, wallet.id]
    );

    // Record wallet transaction with GST breakdown
    await query(
      `INSERT INTO wallet_transactions 
       (wallet_id, user_id, transaction_type, amount, base_amount, gst_amount, gst_percentage, deepvue_transaction_id, balance_before, balance_after, description, reference_type, status) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`,
      [
        wallet.id,
        userId,
        "debit",
        gstBreakdown.totalAmount,
        gstBreakdown.baseAmount,
        gstBreakdown.gstAmount,
        gstBreakdown.gstPercentage,
        deepvueTransactionId,
        currentBalance,
        newBalance,
        `Phone verification${cacheHit ? ' (cached)' : ''} - Base: ₹${gstBreakdown.baseAmount}, GST (18%): ₹${gstBreakdown.gstAmount}`,
        "verification",
        "completed"
      ]
    );

    // Save to verification history
    await query(
      `INSERT INTO verification_history 
       (user_id, verification_type, status, details, amount_charged) 
       VALUES ($1, $2, $3, $4, $5)`,
      [userId, "phone", "completed", JSON.stringify(verificationData), gstBreakdown.totalAmount]
    );

    // Save to transactions table with GST breakdown
    await query(
      `INSERT INTO transactions 
       (user_id, verification_type, amount, base_amount, gst_amount, gst_percentage, deepvue_transaction_id, status, cache_hit, details) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
      [
        userId,
        "phone",
        gstBreakdown.totalAmount,
        gstBreakdown.baseAmount,
        gstBreakdown.gstAmount,
        gstBreakdown.gstPercentage,
        deepvueTransactionId,
        "success",
        cacheHit,
        JSON.stringify(verificationData)
      ]
    );

    return NextResponse.json(
      {
        success: true,
        data: verificationData,
        cacheHit,
        deepvueTransactionId,
        wallet: {
          baseAmount: gstBreakdown.baseAmount,
          gstAmount: gstBreakdown.gstAmount,
          gstPercentage: gstBreakdown.gstPercentage,
          totalAmount: gstBreakdown.totalAmount,
          amountDeducted: gstBreakdown.totalAmount,
          newBalance,
        },
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Phone verification error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Verification failed" },
      { status: 500 }
    );
  }
}
