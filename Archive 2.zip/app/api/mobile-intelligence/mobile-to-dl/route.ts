import { NextRequest, NextResponse } from "next/server";
import { deepvueService } from "@/lib/deepvue";
import { query } from "@/db/db";

const VERIFICATION_COST = 8;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, mobileNumber } = body;

    if (!userId || !mobileNumber) {
      return NextResponse.json(
        { success: false, error: "User ID and mobile number are required" },
        { status: 400 }
      );
    }

    const cacheKey = mobileNumber.toUpperCase();
    const cacheResult = await query(
      "SELECT verification_data FROM verification_cache WHERE verification_type = $1 AND verification_key = $2",
      ["mobile-to-dl", cacheKey]
    );

    let deepvueResponse;
    let cacheHit = false;
    
    if (cacheResult.rows.length > 0) {
      deepvueResponse = cacheResult.rows[0].verification_data;
      cacheHit = true;
      await query(
        "UPDATE verification_cache SET access_count = access_count + 1, last_accessed_at = CURRENT_TIMESTAMP WHERE verification_type = $1 AND verification_key = $2",
        ["mobile-to-dl", cacheKey]
      );
    } else {
      deepvueResponse = await deepvueService.mobileToDL(mobileNumber);
      await query(
        "INSERT INTO verification_cache (verification_type, verification_key, verification_data) VALUES ($1, $2, $3) ON CONFLICT (verification_type, verification_key) DO UPDATE SET verification_data = $3, last_accessed_at = CURRENT_TIMESTAMP",
        ["mobile-to-dl", cacheKey, JSON.stringify(deepvueResponse)]
      );
    }

    const walletResult = await query("SELECT * FROM wallets WHERE user_id = $1", [userId]);
    if (walletResult.rows.length === 0 || parseFloat(walletResult.rows[0].balance) < VERIFICATION_COST) {
      return NextResponse.json({ success: false, error: "Insufficient wallet balance" }, { status: 400 });
    }

    const wallet = walletResult.rows[0];
    const currentBalance = parseFloat(wallet.balance);
    const newBalance = currentBalance - VERIFICATION_COST;

    await query("UPDATE wallets SET balance = $1 WHERE id = $2", [newBalance, wallet.id]);
    await query(
      `INSERT INTO wallet_transactions (wallet_id, user_id, transaction_type, amount, balance_before, balance_after, description, reference_type, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
      [wallet.id, userId, "debit", VERIFICATION_COST, currentBalance, newBalance, "Mobile to DL", "verification", "completed"]
    );

    return NextResponse.json({
      success: true,
      data: deepvueResponse,
      cacheHit,
      wallet: { amountDeducted: VERIFICATION_COST, newBalance },
    });
  } catch (error: any) {
    console.error("Mobile to DL error:", error);
    return NextResponse.json({ success: false, error: error.message || "Verification failed" }, { status: 500 });
  }
}
