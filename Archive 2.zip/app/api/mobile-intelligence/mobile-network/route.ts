import { NextRequest, NextResponse } from "next/server";
import { deepvueService } from "@/lib/deepvue";
import { query } from "@/db/db";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, mobileNumber } = body;

    if (!userId || !mobileNumber) {
      return NextResponse.json(
        { success: false, error: "User ID and mobile number are required" },
        { status: 400 }
      );
    }

    const mobileRegex = /^[6-9][0-9]{9}$/;
    if (!mobileRegex.test(mobileNumber)) {
      return NextResponse.json(
        { success: false, error: "Invalid mobile number format" },
        { status: 400 }
      );
    }

    const deepvueResponse = await deepvueService.mobileToNetworkDetails(mobileNumber);

    const walletResult = await query(
      "SELECT balance FROM wallets WHERE user_id = $1",
      [userId]
    );

    if (walletResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "Wallet not found" },
        { status: 404 }
      );
    }

    const currentBalance = parseFloat(walletResult.rows[0].balance);
    const verificationCost = 4;

    if (currentBalance < verificationCost) {
      return NextResponse.json(
        { success: false, error: "Insufficient wallet balance" },
        { status: 400 }
      );
    }

    await query(
      "UPDATE wallets SET balance = balance - $1 WHERE user_id = $2",
      [verificationCost, userId]
    );

    await query(
      `INSERT INTO verification_history 
       (user_id, verification_type, status, details, amount_charged) 
       VALUES ($1, $2, $3, $4, $5)`,
      [userId, "mobile_network", "completed", JSON.stringify(deepvueResponse), verificationCost]
    );

    return NextResponse.json(
      {
        success: true,
        data: deepvueResponse,
        wallet: {
          amountDeducted: verificationCost,
          newBalance: currentBalance - verificationCost,
        },
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Mobile network details error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Service failed" },
      { status: 500 }
    );
  }
}
