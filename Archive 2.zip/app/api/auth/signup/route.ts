import { NextRequest, NextResponse } from "next/server"
import { query } from "@/db/db"
import bcrypt from "bcrypt"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { fullName, email, phone, password } = body

    // Validation
    if (!fullName || !email || !password) {
      return NextResponse.json(
        { error: "Full name, email, and password are required" },
        { status: 400 }
      )
    }

    // Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: "Invalid email format" },
        { status: 400 }
      )
    }

    // Password length validation
    if (password.length < 6) {
      return NextResponse.json(
        { error: "Password must be at least 6 characters" },
        { status: 400 }
      )
    }

    // Check if user already exists
    const existingUser = await query(
      "SELECT id FROM users WHERE email = $1",
      [email.toLowerCase()]
    )

    if (existingUser.rows.length > 0) {
      return NextResponse.json(
        { error: "Email already registered" },
        { status: 409 }
      )
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10)

    // Insert user
    const userResult = await query(
      `INSERT INTO users (full_name, email, phone, password_hash, created_at)
       VALUES ($1, $2, $3, $4, CURRENT_TIMESTAMP)
       RETURNING id, full_name, email, phone, created_at`,
      [fullName.trim(), email.toLowerCase(), phone || null, hashedPassword]
    )

    const user = userResult.rows[0]

    // Create wallet for the user with initial balance of 0
    await query(
      `INSERT INTO wallets (user_id, balance, created_at, updated_at)
       VALUES ($1, 0, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)`,
      [user.id]
    )

    console.log(`[Signup] New user created: ${user.email} (ID: ${user.id}) with wallet initialized`)

    return NextResponse.json(
      {
        success: true,
        message: "Account created successfully!",
        user: {
          id: user.id,
          fullName: user.full_name,
          email: user.email,
          phone: user.phone
        }
      },
      { status: 201 }
    )
  } catch (error: any) {
    console.error("Signup error:", error)
    return NextResponse.json(
      { error: "Failed to create account. Please try again." },
      { status: 500 }
    )
  }
}
