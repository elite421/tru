import { NextRequest, NextResponse } from "next/server"
import { query } from "@/db/db"
import bcrypt from "bcrypt"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, password } = body

    // Validation
    if (!email || !password) {
      return NextResponse.json(
        { error: "Email and password are required" },
        { status: 400 }
      )
    }

    // Find user by email
    const userResult = await query(
      `SELECT id, full_name, email, phone, password_hash, created_at 
       FROM users 
       WHERE email = $1`,
      [email.toLowerCase()]
    )

    if (userResult.rows.length === 0) {
      return NextResponse.json(
        { error: "Invalid email or password" },
        { status: 401 }
      )
    }

    const user = userResult.rows[0]

    // Verify password
    const isValidPassword = await bcrypt.compare(password, user.password_hash)

    if (!isValidPassword) {
      return NextResponse.json(
        { error: "Invalid email or password" },
        { status: 401 }
      )
    }

    // Get wallet balance
    const walletResult = await query(
      "SELECT balance FROM wallets WHERE user_id = $1",
      [user.id]
    )

    const walletBalance = walletResult.rows.length > 0 
      ? parseFloat(walletResult.rows[0].balance) 
      : 0

    console.log(`[Login] User logged in: ${user.email} (ID: ${user.id})`)

    // Return user data (excluding password)
    return NextResponse.json(
      {
        success: true,
        message: "Login successful",
        user: {
          id: user.id,
          fullName: user.full_name,
          email: user.email,
          phone: user.phone,
          walletBalance: walletBalance,
          createdAt: user.created_at
        }
      },
      { status: 200 }
    )
  } catch (error: any) {
    console.error("Login error:", error)
    return NextResponse.json(
      { error: "An error occurred during login" },
      { status: 500 }
    )
  }
}
