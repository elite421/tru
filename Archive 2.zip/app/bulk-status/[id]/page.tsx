'use client'

import { useState, useEffect } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { Button } from '@/component/ui/button'
import { ArrowLeft, XCircle } from 'lucide-react'
import { useToast } from '@/component/ToastProvider'

export default function BulkStatusPage() {
  const { showToast } = useToast()
  const params = useParams()
  const router = useRouter()
  const id = params.id as string
  
  useEffect(() => {
    showToast('Bulk verification feature is not available in this version', 'info')
  }, [id])

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 flex items-center justify-center">
      <div className="max-w-md w-full bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-12 text-center">
        <XCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          Feature Not Available
        </h1>
        <p className="text-gray-600 dark:text-gray-400 mb-6">
          Bulk verification feature has been removed from this version. Please use manual verification instead.
        </p>
        <div className="flex gap-3">
          <Button
            onClick={() => router.push('/')}
            className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 text-white"
          >
            Go to Dashboard
          </Button>
          <Button
            onClick={() => router.back()}
            variant="outline"
            className="flex-1"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Go Back
          </Button>
        </div>
      </div>
    </div>
  )
}
