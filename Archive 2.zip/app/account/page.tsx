"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import ApiKeyManager from "@/component/ApiKeyManager"
import { Button } from "@/component/ui/button"
import { User, Mail, Phone, Calendar, CreditCard, Download, Eye, EyeOff, Lock } from "lucide-react"
import { useToast } from "@/component/ToastProvider"
import PasswordChangeModal from "@/component/PasswordChangeModal"
import { formatDate, formatDateTime, formatDateShort } from "@/lib/dateUtils"

export default function AccountPage() {
  const router = useRouter()
  const { showToast } = useToast()
  const [user, setUser] = useState<any>(null)
  const [userData, setUserData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [walletBalance, setWalletBalance] = useState(0)
  const [showUserId, setShowUserId] = useState(false)
  const [showPasswordModal, setShowPasswordModal] = useState(false)
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [activityStats, setActivityStats] = useState({
    totalVerifications: 0,
    activeApiKeys: 0,
    apiRequestsThisMonth: 0
  })

  // Check authentication
  useEffect(() => {
    const userData = sessionStorage.getItem("user")
    if (!userData) {
      router.push("/login")
      return
    }
    
    try {
      const parsedUser = JSON.parse(userData)
      setUser(parsedUser)
    } catch (e) {
      router.push("/login")
    }
  }, [router])

  useEffect(() => {
    if (user) {
      fetchUserData()
      fetchWalletBalance()
      fetchActivityStats()
    }
  }, [user])

  const fetchUserData = async () => {
    if (!user) return
    
    try {
      // Use actual logged-in user's ID
      const userId = user.id
      console.log('[Account] Fetching user data for userId:', userId)
      
      const response = await fetch(`/api/user/${userId}`)
      console.log('[Account] API response status:', response.status)
      
      if (response.ok) {
        const data = await response.json()
        console.log('[Account] User data loaded:', data)
        setUserData({
          id: `USR-${data.user.id}`,
          fullName: data.user.full_name || data.user.fullName || "N/A",
          email: data.user.email,
          phone: data.user.phone || "Not provided",
          emailVerified: data.user.email_verified || data.user.emailVerified || false,
          phoneVerified: data.user.phone_verified || data.user.phoneVerified || false,
          createdAt: formatDateShort(data.user.created_at || data.user.createdAt),
          lastLogin: data.user.last_login ? formatDateTime(data.user.last_login) : data.user.lastLogin ? formatDateTime(data.user.lastLogin) : "Never",
        })
      } else {
        const errorText = await response.text()
        console.error('[Account] Failed to fetch user data:', response.status, errorText)
      }
    } catch (error) {
      console.error('[Account] Error fetching user data:', error)
    } finally {
      setLoading(false)
    }
  }

  const fetchWalletBalance = async () => {
    if (!user) return
    
    try {
      // Use actual logged-in user's ID
      const userId = user.id
      const url = `/api/wallet/balance?userId=${userId}`
      const response = await fetch(url)
      const data = await response.json()
      if (data.success) {
        setWalletBalance(data.balance)
      }
    } catch (error) {
      console.error("Failed to fetch wallet balance:", error)
    }
  }

  const fetchActivityStats = async () => {
    if (!user) return
    
    try {
      const userId = user.id
      
      // Fetch verification count
      const verificationResponse = await fetch(`/api/verification/history?userId=${userId}&limit=1000&offset=0`)
      if (verificationResponse.ok) {
        const verificationData = await verificationResponse.json()
        const totalVerifications = verificationData.success && verificationData.history 
          ? verificationData.history.length 
          : 0
        
        setActivityStats({
          totalVerifications,
          activeApiKeys: 0, // API keys feature not implemented yet
          apiRequestsThisMonth: 0 // Request tracking not implemented yet
        })
      }
    } catch (error) {
      console.error("Failed to fetch activity stats:", error)
    }
  }

  const handleChangePassword = () => {
    setShowPasswordModal(true)
  }

  const handleDeleteAccount = () => {
    const confirmed = window.confirm(
      'Are you sure you want to delete your account? This action cannot be undone.'
    )
    if (confirmed) {
      // In production: call API to delete account
      showToast('This feature will logout and delete your account permanently.', 'warning')
    }
  }

  const exportAccountData = () => {
    if (!userData) return
    const dataStr = JSON.stringify(userData, null, 2)
    const dataBlob = new Blob([dataStr], { type: "application/json" })
    const url = URL.createObjectURL(dataBlob)
    const link = document.createElement("a")
    link.href = url
    link.download = `truverify-account-${userData.id}.json`
    link.click()
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-600 mx-auto mb-4"></div>
          <p className="text-gray-600 dark:text-gray-400">Loading your account...</p>
        </div>
      </div>
    )
  }

  if (!userData) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-600 dark:text-red-400">Failed to load user data. Please login again.</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent mb-2">
            Account Settings
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Manage your profile, API keys, and preferences
          </p>
        </div>

        {/* User Profile Section */}
        <div className="bg-white dark:bg-gray-800 border-0 shadow-xl rounded-2xl overflow-hidden">
          <div className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 h-32"></div>
          <div className="px-8 pb-8">
            <div className="flex flex-col md:flex-row md:items-end md:justify-between -mt-16">
              <div className="flex items-end gap-6">
                <div className="w-32 h-32 rounded-full bg-white dark:bg-gray-700 border-4 border-white dark:border-gray-800 shadow-xl flex items-center justify-center">
                  <User size={48} className="text-indigo-600" />
                </div>
                <div className="mb-4">
                  <h2 className="text-3xl font-bold text-gray-900 dark:text-white">
                    {userData.fullName}
                  </h2>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-sm text-gray-500 dark:text-gray-400 font-mono">
                      {showUserId ? userData.id : "••••••••••••"}
                    </span>
                    <button
                      onClick={() => setShowUserId(!showUserId)}
                      className="p-1 hover:bg-gray-100 dark:hover:bg-gray-700 rounded transition-colors"
                    >
                      {showUserId ? (
                        <EyeOff size={16} className="text-gray-500" />
                      ) : (
                        <Eye size={16} className="text-gray-500" />
                      )}
                    </button>
                  </div>
                </div>
              </div>
              <Button
                onClick={exportAccountData}
                className="mt-4 md:mt-0 bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:opacity-90"
              >
                <Download size={20} className="mr-2" />
                Export Data
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
              <div className="flex items-center gap-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
                <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                  <Mail size={24} className="text-blue-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Email</p>
                  <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
                    {userData.email}
                  </p>
                  {userData.emailVerified && (
                    <span className="text-xs text-green-600">✓ Verified</span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
                <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-lg">
                  <Phone size={24} className="text-green-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Phone</p>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    {userData.phone}
                  </p>
                  {userData.phoneVerified && (
                    <span className="text-xs text-green-600">✓ Verified</span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
                <div className="p-3 bg-purple-100 dark:bg-purple-900/30 rounded-lg">
                  <Calendar size={24} className="text-purple-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Member Since</p>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    {userData.createdAt}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-4 p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl">
                <div className="p-3 bg-yellow-100 dark:bg-yellow-900/30 rounded-lg">
                  <CreditCard size={24} className="text-yellow-600" />
                </div>
                <div>
                  <p className="text-sm text-gray-500 dark:text-gray-400">Wallet Balance</p>
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    ₹{walletBalance.toFixed(2)}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* API Keys Management Section */}
        <div className="bg-white dark:bg-gray-800 border-0 shadow-xl rounded-2xl p-8">
          <ApiKeyManager />
        </div>

        {/* Account Actions */}
        <div className="bg-white dark:bg-gray-800 border-0 shadow-xl rounded-2xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
            Account Management
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Button 
              onClick={handleChangePassword}
              variant="outline" 
              className="w-full justify-start text-left hover:bg-indigo-50 dark:hover:bg-indigo-900/20"
            >
              <Lock className="mr-2" size={20} />
              Change Password
            </Button>
            <Button 
              onClick={() => window.location.href = '/wallet'}
              variant="outline" 
              className="w-full justify-start text-left hover:bg-green-50 dark:hover:bg-green-900/20"
            >
              <CreditCard className="mr-2" size={20} />
              Manage Wallet
            </Button>
            <Button 
              onClick={exportAccountData}
              variant="outline" 
              className="w-full justify-start text-left hover:bg-blue-50 dark:hover:bg-blue-900/20"
            >
              <Download className="mr-2" size={20} />
              Export Account Data
            </Button>
            <Button 
              onClick={handleDeleteAccount}
              variant="outline" 
              className="w-full justify-start text-left text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-900/20"
            >
              <User className="mr-2" size={20} />
              Delete Account
            </Button>
          </div>
        </div>

        {/* Activity Summary */}
        <div className="bg-white dark:bg-gray-800 border-0 shadow-xl rounded-2xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
            Account Activity
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-6 bg-gradient-to-br from-blue-50 to-indigo-50 dark:from-blue-900/20 dark:to-indigo-900/20 rounded-xl">
              <p className="text-3xl font-bold text-indigo-600 dark:text-indigo-400">{activityStats.totalVerifications}</p>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">Total Verifications</p>
            </div>
            <div className="text-center p-6 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20 rounded-xl">
              <p className="text-3xl font-bold text-green-600 dark:text-green-400">{activityStats.activeApiKeys}</p>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">Active API Keys</p>
            </div>
            <div className="text-center p-6 bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-xl">
              <p className="text-3xl font-bold text-purple-600 dark:text-purple-400">{activityStats.apiRequestsThisMonth}</p>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">API Requests This Month</p>
            </div>
          </div>
        </div>
      </div>

      {/* Password Change Modal */}
      <PasswordChangeModal 
        isOpen={showPasswordModal}
        onClose={() => setShowPasswordModal(false)}
      />
    </div>
  )
}
