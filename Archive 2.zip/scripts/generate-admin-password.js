const bcrypt = require('bcryptjs');

const password = 'Aman123';
const saltRounds = 10;

bcrypt.hash(password, saltRounds, function(err, hash) {
  if (err) {
    console.error('Error generating hash:', err);
    return;
  }
  
  console.log('\n✅ Password hash generated successfully!\n');
  console.log('Password:', password);
  console.log('Hash:', hash);
  console.log('\nRun this SQL to update the admin password:\n');
  console.log(`UPDATE admin_users SET password_hash = '${hash}' WHERE username = 'admin';\n`);
});
