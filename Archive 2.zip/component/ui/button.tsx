import * as React from "react";

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "default" | "outline";
}

export const Button: React.FC<ButtonProps> = ({
  variant = "default",
  className,
  children,
  ...props
}) => {
  const base = "px-4 py-2 rounded-lg font-medium transition";
  const styles =
    variant === "outline"
      ? "border border-gray-300 hover:bg-gray-100"
      : "bg-black text-white hover:bg-gray-800";

  return (
    <button className={`${base} ${styles} ${className}`} {...props}>
      {children}
    </button>
  );
};
