"use client"

import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { useState, useEffect } from "react"
import { ChevronRight, ChevronLeft, Menu, X, ChevronDown, LayoutDashboard, Users, Receipt, Key, DollarSign, LogOut, FileText, Mail, Ticket, Shield, User, Wallet as WalletIcon } from "lucide-react"

// Define types for navigation links
interface RegularLink {
  name: string
  href: string
}

interface AdminLink {
  name: string
  href: string
  icon: React.ReactNode
}

type NavLink = RegularLink | AdminLink

// Type guard to check if a link is an admin link
const isAdminLink = (link: NavLink): link is AdminLink => {
  return 'icon' in link
}

export default function Navbar() {
  const pathname = usePathname()
  const router = useRouter()
  const [isExpanded, setIsExpanded] = useState(true)
  const [isMobileOpen, setIsMobileOpen] = useState(false)
  const [timeoutId, setTimeoutId] = useState<NodeJS.Timeout | null>(null)
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({})
  const [isAdmin, setIsAdmin] = useState(false)
  const [user, setUser] = useState<any>(null)

  // Check if user is logged in and if admin
  useEffect(() => {
    const checkAuthStatus = () => {
      const adminUser = sessionStorage.getItem("admin_user")
      const regularUser = sessionStorage.getItem("user")
      
      setIsAdmin(!!adminUser)
      
      if (regularUser) {
        try {
          setUser(JSON.parse(regularUser))
        } catch (e) {
          setUser(null)
        }
      } else {
        setUser(null)
      }
    }
    
    checkAuthStatus()
    
    // Listen for storage changes
    window.addEventListener('storage', checkAuthStatus)
    
    // Also check periodically in case sessionStorage changes
    const interval = setInterval(checkAuthStatus, 1000)
    
    return () => {
      window.removeEventListener('storage', checkAuthStatus)
      clearInterval(interval)
    }
  }, [])

  const handleAdminLogout = async () => {
    await fetch("/api/admin/logout", { method: "POST" })
    sessionStorage.removeItem("admin_user")
    setIsAdmin(false)
    router.push("/admin/login")
  }

  const handleUserLogout = () => {
    sessionStorage.removeItem("user")
    setUser(null)
    router.push("/login")
  }

  const links: RegularLink[] = [
    { name: "Dashboard", href: "/" },
    { name: "Account", href: "/account" },
    { name: "Wallet", href: "/wallet" },
    { name: "Reports", href: "/reports" },
    { name: "Transactions", href: "/transactions" },
    { name: "Features", href: "/features" },
    { name: "Advanced Services", href: "/advanced-services" },
    { name: "Pricing", href: "/pricing" },
    { name: "Help", href: "/help" },
    { name: "Docs", href: "/docs" },
    { name: "Contact", href: "/contact" },
  ]

  const adminLinks: AdminLink[] = [
    { name: "Admin Dashboard", href: "/admin", icon: <LayoutDashboard className="w-4 h-4" /> },
    { name: "Users", href: "/admin/users", icon: <Users className="w-4 h-4" /> },
    { name: "Transactions", href: "/admin/transactions", icon: <Receipt className="w-4 h-4" /> },
    { name: "API Keys", href: "/admin/api-keys", icon: <Key className="w-4 h-4" /> },
    { name: "Pricing Plans", href: "/admin-pricing", icon: <DollarSign className="w-4 h-4" /> },
    { name: "System Logs", href: "/admin/logs", icon: <FileText className="w-4 h-4" /> },
    { name: "Messages", href: "/admin/messages", icon: <Mail className="w-4 h-4" /> },
    { name: "Support Tickets", href: "/admin/tickets", icon: <Ticket className="w-4 h-4" /> },
  ]

  const verificationCategories = [
    {
      category: "Identity Verification",
      items: [
        { name: "Aadhaar eKYC", href: "/verify/aadhaar-ekyc" },
        { name: "PAN Card Basic", href: "/verify/pan" },
        { name: "PAN Card Plus", href: "/verify/pan-plus" },
        { name: "Driving License", href: "/verify/driving-license" },
        { name: "Vehicle RC", href: "/verify/rc" },
      ]
    },
    {
      category: "Business Verification",
      items: [
        { name: "GST Basic", href: "/verify/gst" },
        { name: "GST Advanced", href: "/verify/gst-advanced" },
        { name: "GSTIN by PAN", href: "/verify/gstin-by-pan" },
        { name: "Track GSTR", href: "/verify/track-gstr" },
        { name: "CIN Verification", href: "/verify/cin" },
        { name: "DIN Verification", href: "/verify/din" },
      ]
    },
    {
      category: "Financial Verification",
      items: [
        { name: "Bank Account", href: "/verify/bank-account" },
        { name: "IFSC Code", href: "/verify/ifsc" },
        { name: "UPI Verification", href: "/verify/upi" },
        { name: "UPI Advanced", href: "/verify/upi-advanced" },
        { name: "Credit Report", href: "/verify/credit-report" },
      ]
    },
    {
      category: "Tax & Compliance",
      items: [
        { name: "TAN Verification", href: "/verify/tan" },
        { name: "TDS Compliance", href: "/verify/tds-compliance" },
      ]
    },
    {
      category: "EPFO Services",
      items: [
        { name: "Aadhaar to UAN", href: "/verify/aadhaar-to-uan" },
        { name: "PAN to UAN", href: "/verify/pan-to-uan" },
        { name: "UAN to Employment", href: "/verify/uan-employment" },
      ]
    },
    {
      category: "Mobile Intelligence",
      items: [
        { name: "Mobile to Name", href: "/verify/mobile-to-name" },
        { name: "Mobile to PAN", href: "/verify/mobile-to-pan" },
        { name: "Mobile to DL", href: "/verify/mobile-to-dl" },
        { name: "Mobile to UAN", href: "/verify/mobile-to-uan" },
        { name: "Mobile to Digital Age", href: "/verify/mobile-digital-age" },
        { name: "Mobile Network Details", href: "/verify/mobile-network" },
        { name: "Mobile to Multiple UPI", href: "/verify/mobile-to-upi" },
      ]
    },
    {
      category: "Document OCR",
      items: [
        { name: "Aadhaar OCR", href: "/verify/ocr-aadhaar" },
        { name: "PAN OCR", href: "/verify/ocr-pan" },
        { name: "Voter ID OCR", href: "/verify/ocr-voter-id" },
        { name: "DL OCR", href: "/verify/ocr-dl" },
        { name: "Bank Cheque OCR", href: "/verify/ocr-cheque" },
        { name: "GSTIN Certificate OCR", href: "/verify/ocr-gstin" },
      ]
    },
    {
      category: "Biometric Services",
      items: [
        { name: "Face Match", href: "/verify/face-match" },
        { name: "Liveness Check", href: "/verify/liveness-check" },
      ]
    },
    {
      category: "MSME Services",
      items: [
        { name: "Udyam Details", href: "/verify/udyam" },
        { name: "Udyog Details", href: "/verify/udyog" },
      ]
    },
  ]

  // Check if on verification page
  const isOnVerifyPage = pathname.startsWith("/verify")
  
  // Use verification links if on verify page, otherwise normal links
  const displayLinks: NavLink[] = isOnVerifyPage ? [] : (isAdmin ? [...links, ...adminLinks] : links)

  const toggleSidebar = () => {
    setIsExpanded(!isExpanded)
    
    // Clear existing timeout
    if (timeoutId) {
      clearTimeout(timeoutId)
    }
    
    // Auto-close after 5 seconds if expanding
    if (!isExpanded) {
      const id = setTimeout(() => {
        setIsExpanded(false)
      }, 5000)
      setTimeoutId(id)
    }
  }

  const toggleCategory = (category: string) => {
    setExpandedCategories(prev => ({
      ...prev,
      [category]: !prev[category]
    }))
  }

  // Cleanup timeout on unmount
  useEffect(() => {
    return () => {
      if (timeoutId) {
        clearTimeout(timeoutId)
      }
    }
  }, [timeoutId])

  return (
    <>
      {/* Mobile Menu Toggle Button */}
      <button
        onClick={() => setIsMobileOpen(!isMobileOpen)}
        className="md:hidden fixed top-4 left-4 z-[60] bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-full p-3 shadow-lg"
      >
        {isMobileOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Overlay for mobile */}
      {isMobileOpen && (
        <div
          className="md:hidden fixed inset-0 bg-black/50 z-40"
          onClick={() => setIsMobileOpen(false)}
        />
      )}

      {/* Sidebar Navigation */}
      <nav className={`fixed left-0 top-0 h-screen bg-gradient-to-b from-indigo-900 via-purple-800 to-blue-900 text-white shadow-2xl rounded-r-3xl z-50 transition-all duration-300 overflow-y-auto ${
        isExpanded ? "w-64" : "w-20"
      } ${
        isMobileOpen ? "translate-x-0" : "-translate-x-full md:translate-x-0"
      }`}>
        {/* Desktop Toggle Button */}
        <button
          onClick={toggleSidebar}
          className="hidden md:block absolute -right-3 top-8 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white rounded-full p-2 shadow-lg transition-all duration-300 hover:scale-110"
        >
          {isExpanded ? <ChevronLeft size={20} /> : <ChevronRight size={20} />}
        </button>

        <div className="flex flex-col h-full p-6">
        {/* Logo at Top */}
        <div className="mb-8 text-center">
          <div className={`font-extrabold bg-gradient-to-r from-yellow-300 via-pink-400 to-purple-500 bg-clip-text text-transparent drop-shadow-[0_0_15px_rgba(255,255,255,0.4)] transition-all duration-300 ${
            isExpanded ? "text-3xl" : "text-xl"
          }`}>
            {isExpanded ? "TruVerify" : "TV"}
          </div>
          {isExpanded && (
            <p className="text-xs text-white/60">Verification Platform</p>
          )}
        </div>

        {/* Navigation Links */}
        <div className="flex flex-col space-y-2 flex-1">
          {/* Admin Badge */}
          {isAdmin && !isOnVerifyPage && (
            <div className="mb-4 px-4 py-2 bg-gradient-to-r from-red-500/20 to-orange-500/20 rounded-xl border border-red-400/30">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-red-400" />
                {isExpanded && <span className="text-xs font-semibold text-red-300">Admin Mode</span>}
              </div>
            </div>
          )}

          {/* Back to Dashboard button when on verify pages */}
          {isOnVerifyPage && (
            <Link
              href="/"
              className="px-4 py-3 text-sm font-medium rounded-xl transition-all duration-200 bg-white/10 text-white hover:bg-white/20 mb-2 flex items-center gap-2"
            >
              <ChevronLeft className="w-4 h-4" />
              {isExpanded && <span>Back to Dashboard</span>}
            </Link>
          )}

          {/* Display normal links or verification categories */}
          {isOnVerifyPage ? (
            // Verification Categories
            verificationCategories.map((cat) => (
              <div key={cat.category}>
                <button
                  onClick={() => toggleCategory(cat.category)}
                  className={`w-full px-4 py-2 text-sm font-semibold rounded-xl transition-all duration-200 text-white/90 hover:bg-white/10 flex items-center justify-between ${
                    !isExpanded ? "justify-center" : ""
                  }`}
                >
                  {isExpanded ? (
                    <>
                      <span>{cat.category}</span>
                      <ChevronDown className={`w-4 h-4 transition-transform ${expandedCategories[cat.category] ? 'rotate-180' : ''}`} />
                    </>
                  ) : (
                    <span className="text-xs">{cat.category.charAt(0)}</span>
                  )}
                </button>
                {(expandedCategories[cat.category] || !isExpanded) && isExpanded && (
                  <div className="ml-2 mt-1 space-y-1">
                    {cat.items.map((link) => (
                      <Link
                        key={link.href}
                        href={link.href}
                        className={`block px-4 py-2 text-xs rounded-lg transition-all duration-200 ${
                          pathname === link.href
                            ? "bg-white/20 text-yellow-300 shadow-lg"
                            : "text-white/70 hover:text-white hover:bg-white/10"
                        }`}
                      >
                        {link.name}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))
          ) : (
            // Normal Links
            displayLinks.map((link: NavLink) => {
              const isAdmin = isAdminLink(link)
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  title={!isExpanded ? link.name : ""}
                  className={`px-4 py-3 text-sm font-medium rounded-xl transition-all duration-200 flex items-center gap-2 ${
                    pathname === link.href
                      ? isAdmin 
                        ? "bg-red-500/20 text-red-300 shadow-lg border border-red-400/30"
                        : "bg-white/20 text-yellow-300 shadow-lg"
                      : isAdmin
                        ? "text-red-300/80 hover:text-red-200 hover:bg-red-500/10"
                        : "text-white/80 hover:text-white hover:bg-white/10"
                  } ${!isExpanded ? "justify-center" : ""}` }
                >
                  {isAdmin && link.icon}
                  {isExpanded ? link.name : (isAdmin ? '' : link.name.charAt(0))}
                </Link>
              )
            })
          )}

          {/* Admin Logout Button */}
          {isAdmin && !isOnVerifyPage && (
            <button
              onClick={handleAdminLogout}
              className={`mt-4 px-4 py-3 text-sm font-medium rounded-xl transition-all duration-200 flex items-center gap-2 bg-red-600/20 text-red-400 hover:bg-red-600/30 hover:text-red-300 border border-red-500/30 ${
                !isExpanded ? "justify-center" : ""
              }`}
            >
              <LogOut className="w-4 h-4" />
              {isExpanded && <span>Admin Logout</span>}
            </button>
          )}

          {/* User Authentication Section */}
          {!isAdmin && !isOnVerifyPage && (
            <div className="mt-auto pt-4 border-t border-white/10">
              {user ? (
                /* Logged in user info */
                <div className="space-y-3">
                  <div className={`px-4 py-3 bg-white/10 rounded-xl ${!isExpanded ? "text-center" : ""}`}>
                    {isExpanded ? (
                      <>
                        <div className="flex items-center gap-2 mb-2">
                          <User className="w-4 h-4 text-blue-400" />
                          <span className="text-sm font-semibold text-white truncate">
                            {user.fullName || user.email}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-gray-400">
                          <WalletIcon className="w-3 h-3" />
                          <span>₹{user.walletBalance?.toFixed(2) || '0.00'}</span>
                        </div>
                      </>
                    ) : (
                      <User className="w-5 h-5 text-blue-400 mx-auto" />
                    )}
                  </div>
                  
                  <button
                    onClick={handleUserLogout}
                    className={`w-full px-4 py-3 text-sm font-medium rounded-xl transition-all duration-200 flex items-center gap-2 bg-white/10 text-white hover:bg-white/20 ${
                      !isExpanded ? "justify-center" : ""
                    }`}
                  >
                    <LogOut className="w-4 h-4" />
                    {isExpanded && <span>Logout</span>}
                  </button>
                </div>
              ) : (
                /* Not logged in - show login/signup */
                <div className="space-y-2">
                  <Link
                    href="/login"
                    className={`w-full px-4 py-3 text-sm font-medium rounded-xl transition-all duration-200 flex items-center gap-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white shadow-lg ${
                      !isExpanded ? "justify-center" : ""
                    }`}
                  >
                    <LogOut className="w-4 h-4 rotate-180" />
                    {isExpanded && <span>Sign In</span>}
                  </Link>
                  
                  <Link
                    href="/signup"
                    className={`w-full px-4 py-3 text-sm font-medium rounded-xl transition-all duration-200 flex items-center gap-2 bg-white/10 text-white hover:bg-white/20 border border-white/20 ${
                      !isExpanded ? "justify-center" : ""
                    }`}
                  >
                    <User className="w-4 h-4" />
                    {isExpanded && <span>Sign Up</span>}
                  </Link>
                </div>
              )}
            </div>
          )}
        </div>

        {/* App Info at Bottom */}
        <div className="mt-auto">
          {isExpanded && (
            <div className="text-center p-4 bg-white/5 rounded-xl">
              <p className="text-xs text-white/60">TruVerify v1.0</p>
              <p className="text-xs text-white/40 mt-1">Demo Mode</p>
            </div>
          )}
        </div>
      </div>
    </nav>

    {/* Spacer div to push content - only on desktop */}
    <div className={`hidden md:block flex-shrink-0 transition-all duration-300 ${
      isExpanded ? "w-64" : "w-20"
    }`} />
    </>
  )
}
