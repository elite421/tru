"use client"

import { useState, useEffect } from "react"
import { Button } from "@/component/ui/button"
import { Copy, Check, Trash2, Plus, Eye, EyeOff } from "lucide-react"

interface ApiKey {
  key: string
  fullKey: string
  name: string
  createdAt: string
  lastUsed: string | null
  usageCount: number
}

export default function ApiKeyManager() {
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([])
  const [showCreateForm, setShowCreateForm] = useState(false)
  const [newKeyName, setNewKeyName] = useState("")
  const [copiedKey, setCopiedKey] = useState<string | null>(null)
  const [visibleKeys, setVisibleKeys] = useState<Set<string>>(new Set())
  const [createdKey, setCreatedKey] = useState<string | null>(null)
  const userId = "1" // Demo mode - use default user ID

  useEffect(() => {
    fetchApiKeys()
  }, [])

  const fetchApiKeys = async () => {
    try {
      const response = await fetch(`/api/keys?userId=${userId}`)
      const data = await response.json()
      if (data.success) {
        setApiKeys(data.keys)
      }
    } catch (error) {
      console.error("Failed to fetch API keys:", error)
    }
  }

  const createApiKey = async () => {
    if (!newKeyName.trim()) return

    try {
      const response = await fetch("/api/keys", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newKeyName, userId }),
      })

      const data = await response.json()
      if (data.success) {
        setCreatedKey(data.apiKey)
        setNewKeyName("")
        setShowCreateForm(false)
        fetchApiKeys()
      }
    } catch (error) {
      console.error("Failed to create API key:", error)
    }
  }

  const deleteApiKey = async (apiKey: string) => {
    if (!confirm("Are you sure you want to delete this API key?")) return

    try {
      const response = await fetch(`/api/keys?key=${apiKey}`, {
        method: "DELETE",
      })

      const data = await response.json()
      if (data.success) {
        fetchApiKeys()
      }
    } catch (error) {
      console.error("Failed to delete API key:", error)
    }
  }

  const copyToClipboard = (key: string) => {
    navigator.clipboard.writeText(key)
    setCopiedKey(key)
    setTimeout(() => setCopiedKey(null), 2000)
  }

  const toggleKeyVisibility = (key: string) => {
    const newVisible = new Set(visibleKeys)
    if (newVisible.has(key)) {
      newVisible.delete(key)
    } else {
      newVisible.add(key)
    }
    setVisibleKeys(newVisible)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">API Keys</h2>
          <p className="text-gray-600 dark:text-gray-400">Manage your API keys for authentication</p>
        </div>
        <Button
          onClick={() => setShowCreateForm(true)}
          className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:opacity-90"
        >
          <Plus size={20} className="mr-2" />
          Create New Key
        </Button>
      </div>

      {/* Newly Created Key Alert */}
      {createdKey && (
        <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-green-800 dark:text-green-200 mb-2">
            ✓ API Key Created Successfully!
          </h3>
          <p className="text-sm text-green-700 dark:text-green-300 mb-4">
            Make sure to copy your API key now. You won't be able to see it again!
          </p>
          <div className="flex items-center gap-2 bg-white dark:bg-gray-800 p-4 rounded-lg font-mono text-sm">
            <code className="flex-1 text-gray-900 dark:text-white">{createdKey}</code>
            <button
              onClick={() => copyToClipboard(createdKey)}
              className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded transition-colors"
            >
              {copiedKey === createdKey ? (
                <Check size={20} className="text-green-600" />
              ) : (
                <Copy size={20} className="text-gray-600 dark:text-gray-400" />
              )}
            </button>
          </div>
          <Button
            onClick={() => setCreatedKey(null)}
            className="mt-4 bg-green-600 hover:bg-green-700 text-white"
          >
            I've saved my key
          </Button>
        </div>
      )}

      {/* Create Form Modal */}
      {showCreateForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 max-w-md w-full">
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Create New API Key</h3>
            <input
              type="text"
              placeholder="Enter key name (e.g., Production Server)"
              value={newKeyName}
              onChange={(e) => setNewKeyName(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none dark:bg-gray-700 dark:text-white mb-4"
            />
            <div className="flex gap-3">
              <Button
                onClick={createApiKey}
                className="flex-1 bg-indigo-600 hover:bg-indigo-700 text-white"
              >
                Create Key
              </Button>
              <Button
                onClick={() => {
                  setShowCreateForm(false)
                  setNewKeyName("")
                }}
                className="flex-1 bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600"
              >
                Cancel
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* API Keys List */}
      <div className="space-y-4">
        {apiKeys.length === 0 ? (
          <div className="bg-gray-50 dark:bg-gray-800 rounded-xl p-8 text-center">
            <p className="text-gray-600 dark:text-gray-400">No API keys yet. Create one to get started!</p>
          </div>
        ) : (
          apiKeys.map((apiKey) => (
            <div
              key={apiKey.key}
              className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl p-6 hover:shadow-lg transition-shadow"
            >
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-gray-900 dark:text-white">{apiKey.name}</h3>
                  <p className="text-sm text-gray-500 dark:text-gray-400">
                    Created: {new Date(apiKey.createdAt).toLocaleDateString()}
                  </p>
                </div>
                <button
                  onClick={() => deleteApiKey(apiKey.fullKey)}
                  className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                >
                  <Trash2 size={20} />
                </button>
              </div>

              <div className="flex items-center gap-2 bg-gray-50 dark:bg-gray-900 p-4 rounded-lg font-mono text-sm mb-4">
                <code className="flex-1 text-gray-900 dark:text-white">
                  {visibleKeys.has(apiKey.key) ? apiKey.fullKey : apiKey.key}
                </code>
                <button
                  onClick={() => toggleKeyVisibility(apiKey.key)}
                  className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded transition-colors"
                >
                  {visibleKeys.has(apiKey.key) ? (
                    <EyeOff size={20} className="text-gray-600 dark:text-gray-400" />
                  ) : (
                    <Eye size={20} className="text-gray-600 dark:text-gray-400" />
                  )}
                </button>
                <button
                  onClick={() => copyToClipboard(apiKey.fullKey)}
                  className="p-2 hover:bg-gray-200 dark:hover:bg-gray-700 rounded transition-colors"
                >
                  {copiedKey === apiKey.fullKey ? (
                    <Check size={20} className="text-green-600" />
                  ) : (
                    <Copy size={20} className="text-gray-600 dark:text-gray-400" />
                  )}
                </button>
              </div>

              <div className="flex gap-6 text-sm">
                <div>
                  <span className="text-gray-500 dark:text-gray-400">Last Used:</span>
                  <span className="ml-2 text-gray-900 dark:text-white">
                    {apiKey.lastUsed ? new Date(apiKey.lastUsed).toLocaleDateString() : "Never"}
                  </span>
                </div>
                <div>
                  <span className="text-gray-500 dark:text-gray-400">Usage:</span>
                  <span className="ml-2 text-gray-900 dark:text-white">{apiKey.usageCount} calls</span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  )
}
