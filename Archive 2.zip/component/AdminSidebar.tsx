"use client"

import { usePathname, useRouter } from "next/navigation"
import Link from "next/link"
import { 
  LayoutDashboard, 
  Users, 
  Receipt, 
  Key, 
  DollarSign,
  LogOut,
  Menu,
  X,
  FileText,
  Mail,
  Ticket
} from "lucide-react"
import { useState } from "react"

type NavItem = {
  name: string
  href: string
  icon: React.ReactNode
}

export default function AdminSidebar() {
  const pathname = usePathname()
  const router = useRouter()
  const [isMobileOpen, setIsMobileOpen] = useState(false)

  const navItems: NavItem[] = [
    { name: "Dashboard", href: "/admin", icon: <LayoutDashboard className="w-5 h-5" /> },
    { name: "Users", href: "/admin/users", icon: <Users className="w-5 h-5" /> },
    { name: "Transactions", href: "/admin/transactions", icon: <Receipt className="w-5 h-5" /> },
    { name: "API Keys", href: "/admin/api-keys", icon: <Key className="w-5 h-5" /> },
    { name: "Pricing Plans", href: "/admin-pricing", icon: <DollarSign className="w-5 h-5" /> },
  ]

  const handleLogout = async () => {
    await fetch("/api/admin/logout", { method: "POST" })
    sessionStorage.removeItem("admin_user")
    router.push("/admin/login")
  }

  return (
    <>
      {/* Mobile Menu Button */}
      <button
        onClick={() => setIsMobileOpen(!isMobileOpen)}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-gray-800 rounded-lg text-white"
      >
        {isMobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>

      {/* Sidebar */}
      <div
        className={`
          fixed lg:sticky top-0 left-0 h-screen bg-gray-900 border-r border-gray-800 
          transition-transform duration-300 z-40
          ${isMobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"}
          w-64
        `}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="p-6 border-b border-gray-800">
            <h2 className="text-xl font-bold text-white">Admin Panel</h2>
            <p className="text-sm text-gray-400 mt-1">TruVerify</p>
          </div>

          {/* Navigation */}
          <nav className="flex-1 p-4 space-y-2">
            {navItems.map((item) => {
              const isActive = pathname === item.href
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`
                    w-full flex items-center gap-3 px-4 py-3 rounded-lg
                    transition-colors font-medium
                    ${
                      isActive
                        ? "bg-blue-600 text-white"
                        : "text-gray-400 hover:bg-gray-800 hover:text-white"
                    }
                  `}
                >
                  {item.icon}
                  {item.name}
                </Link>
              )
            })}
            <Link
              href="/admin/logs"
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                pathname === "/admin/logs"
                  ? "bg-white/10 text-white"
                  : "text-gray-400 hover:bg-white/5 hover:text-white"
              }`}
            >
              <FileText className="w-5 h-5" />
              <span className="font-medium">System Logs</span>
            </Link>

            <Link
              href="/admin/messages"
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                pathname === "/admin/messages"
                  ? "bg-white/10 text-white"
                  : "text-gray-400 hover:bg-white/5 hover:text-white"
              }`}
            >
              <Mail className="w-5 h-5" />
              <span className="font-medium">Messages</span>
            </Link>

            <Link
              href="/admin/tickets"
              className={`flex items-center gap-3 px-4 py-3 rounded-lg transition-all ${
                pathname === "/admin/tickets"
                  ? "bg-white/10 text-white"
                  : "text-gray-400 hover:bg-white/5 hover:text-white"
              }`}
            >
              <Ticket className="w-5 h-5" />
              <span className="font-medium">Support Tickets</span>
            </Link>
          </nav>

          {/* Logout Button */}
          <div className="p-4 border-t border-gray-800">
            <button
              onClick={handleLogout}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-lg
                text-red-400 hover:bg-red-500/10 hover:text-red-300
                transition-colors font-medium"
            >
              <LogOut className="w-5 h-5" />
              Logout
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Overlay */}
      {isMobileOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/50 z-30"
          onClick={() => setIsMobileOpen(false)}
        />
      )}
    </>
  )
}
