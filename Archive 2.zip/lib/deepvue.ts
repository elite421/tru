// DeepVue API Integration Service
const DEEPVUE_BASE_URL = "https://production.deepvue.tech/v1";

interface DeepVueConfig {
  clientId: string;
  clientSecret: string;
}

interface DeepVueAuthResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
}

class DeepVueService {
  private config: DeepVueConfig;
  private accessToken: string | null = null;
  private tokenExpiry: number | null = null;

  constructor() {
    this.config = {
      clientId: process.env.DEEPVUE_CLIENT_ID || "",
      clientSecret: process.env.DEEPVUE_CLIENT_SECRET || "",
    };
  }

  // Authenticate and get access token
  private async authenticate(): Promise<string> {
    // Check if token is still valid
    if (this.accessToken && this.tokenExpiry && Date.now() < this.tokenExpiry) {
      return this.accessToken;
    }

    const formData = new FormData();
    formData.append("client_id", this.config.clientId);
    formData.append("client_secret", this.config.clientSecret);

    const response = await fetch(`${DEEPVUE_BASE_URL}/authorize`, {
      method: "POST",
      body: formData,
    });

    if (!response.ok) {
      throw new Error("DeepVue authentication failed");
    }

    const data: DeepVueAuthResponse = await response.json();
    this.accessToken = data.access_token;
    // Set expiry to 5 minutes before actual expiry for safety
    this.tokenExpiry = Date.now() + (data.expires_in - 300) * 1000;

    return this.accessToken;
  }

  // Generic request method
  private async request(
    endpoint: string,
    method: "GET" | "POST" = "GET",
    params?: Record<string, string>,
    body?: any
  ): Promise<any> {
    const token = await this.authenticate();

    const url = new URL(`${DEEPVUE_BASE_URL}${endpoint}`);
    if (params) {
      Object.entries(params).forEach(([key, value]) => {
        url.searchParams.append(key, value);
      });
    }

    const headers: Record<string, string> = {
      Authorization: `Bearer ${token}`,
      "x-api-key": this.config.clientSecret,
    };

    if (body) {
      headers["Content-Type"] = "application/json";
    }

    const response = await fetch(url.toString(), {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`DeepVue API error: ${errorText}`);
    }

    return await response.json();
  }

  // PAN Verification - Basic
  async verifyPAN(panNumber: string): Promise<any> {
    return this.request("/verification/panbasic", "GET", {
      pan_number: panNumber,
    });
  }

  // PAN Verification - Plus
  async verifyPANPlus(panNumber: string): Promise<any> {
    return this.request("/verification/pan-plus", "GET", {
      pan_number: panNumber,
    });
  }

  // Phone/Mobile Verification
  async verifyPhone(phoneNumber: string): Promise<any> {
    return this.request("/verification/phone", "GET", {
      phone_number: phoneNumber,
    });
  }

  // Email Verification
  async verifyEmail(email: string): Promise<any> {
    return this.request("/verification/email", "GET", {
      email: email,
    });
  }

  // Bank Account Verification
  async verifyBankAccount(
    accountNumber: string,
    ifsc: string,
    name?: string
  ): Promise<any> {
    const params: Record<string, string> = {
      account_number: accountNumber,
      ifsc: ifsc,
    };
    if (name) params.name = name;

    return this.request("/verification/bankaccount", "GET", params);
  }

  // GST Verification - Basic
  async verifyGST(gstinNumber: string): Promise<any> {
    return this.request("/verification/gstinlite", "GET", {
      gstin_number: gstinNumber,
    });
  }

  // GST Verification - Advanced
  async verifyGSTAdvanced(gstinNumber: string): Promise<any> {
    return this.request("/verification/gstin-advanced", "GET", {
      gstin_number: gstinNumber,
    });
  }

  // Search GSTIN by PAN
  async searchGSTINByPAN(panNumber: string): Promise<any> {
    return this.request("/verification/gstin/gstin-by-pan", "GET", {
      pan_number: panNumber,
    });
  }

  // Track GST Return Status
  async trackGSTR(gstinNumber: string, financialYear: string): Promise<any> {
    return this.request("/verification/gstin/track-gstr", "GET", {
      gstin_number: gstinNumber,
      financial_year: financialYear,
    });
  }

  // IFSC Verification
  async verifyIFSC(ifsc: string): Promise<any> {
    return this.request("/verification/ifsc", "GET", {
      ifsc: ifsc,
    });
  }

  // UPI Verification
  async verifyUPI(vpa: string): Promise<any> {
    return this.request("/verification/upi", "GET", {
      vpa: vpa,
    });
  }

  // UPI Verification - Advanced
  async verifyUPIAdvanced(vpa: string): Promise<any> {
    return this.request("/verification/upi-advanced", "GET", {
      vpa: vpa,
    });
  }

  // Mobile to VPA
  async mobileToVPA(mobileNumber: string): Promise<any> {
    return this.request("/verification/upi", "GET", {
      mobile_number: mobileNumber,
    });
  }

  // RC Verification Advanced
  async verifyRC(rcNumber: string): Promise<any> {
    return this.request("/verification/rc-advanced", "GET", {
      rc_number: rcNumber,
    });
  }

  // Driving License Verification (Async)
  async postDrivingLicense(dlNumber: string, dob: string): Promise<any> {
    return this.request("/verification/post-driving-license", "POST", {
      dl_number: dlNumber,
      dob: dob,
    });
  }

  async getDrivingLicense(requestId: string): Promise<any> {
    return this.request("/verification/get-driving-license", "GET", {
      request_id: requestId,
    });
  }

  // Vehicle RC Verification (Async)
  async postVehicleRC(rcNumber: string): Promise<any> {
    return this.request("/verification/post-vehicle-rc", "POST", {
      rc_number: rcNumber,
    });
  }

  async getVehicleRC(requestId: string): Promise<any> {
    return this.request("/verification/get-vehicle-rc", "GET", {
      request_id: requestId,
    });
  }

  // Aadhaar eKYC - Generate OTP (V2)
  async generateAadhaarOTP(
    aadhaarNumber: string,
    consent: string = "Y",
    purpose: string = "For KYC"
  ): Promise<any> {
    const headers = {
      "x-api-key": this.config.clientSecret,
      "client-id": this.config.clientId,
    };

    const url = new URL(`${DEEPVUE_BASE_URL}/ekyc/aadhaar/generate-otp`);
    url.searchParams.append("aadhaar_number", aadhaarNumber);
    url.searchParams.append("consent", consent);
    url.searchParams.append("purpose", purpose);

    const response = await fetch(url.toString(), {
      method: "POST",
      headers,
    });

    if (!response.ok) {
      throw new Error("Failed to generate Aadhaar OTP");
    }

    return await response.json();
  }

  // Aadhaar eKYC - Verify OTP (V2)
  async verifyAadhaarOTP(
    otp: string,
    referenceId: string,
    consent: string = "Y",
    purpose: string = "For KYC"
  ): Promise<any> {
    const headers = {
      "x-api-key": this.config.clientSecret,
      "client-id": this.config.clientId,
    };

    const url = new URL(`${DEEPVUE_BASE_URL}/ekyc/aadhaar/verify-otp`);
    url.searchParams.append("otp", otp);
    url.searchParams.append("reference_id", referenceId);
    url.searchParams.append("consent", consent);
    url.searchParams.append("purpose", purpose);

    const response = await fetch(url.toString(), {
      method: "POST",
      headers,
    });

    if (!response.ok) {
      throw new Error("Failed to verify Aadhaar OTP");
    }

    return await response.json();
  }

  // TAN Verification
  async verifyTAN(tanNumber: string): Promise<any> {
    return this.request("/verification/tax-payer/tan", "GET", {
      tan_number: tanNumber,
    });
  }

  // TDS Compliance Check
  async checkTDSCompliance(panNumber: string): Promise<any> {
    return this.request("/verification/tax-payer/tds/206-ab", "GET", {
      pan_number: panNumber,
    });
  }

  // EPFO - Aadhaar to UAN
  async aadhaarToUAN(aadhaarNumber: string): Promise<any> {
    return this.request("/verification/epfo/aadhaar-to-uan", "GET", {
      aadhaar_number: aadhaarNumber,
    });
  }

  // EPFO - PAN to UAN
  async panToUAN(panNumber: string): Promise<any> {
    return this.request("/verification/epfo/pan-to-uan", "GET", {
      pan_number: panNumber,
    });
  }

  // EPFO - UAN to Employment History
  async uanToEmploymentHistory(uanNumber: string): Promise<any> {
    return this.request("/verification/epfo/uan-to-employment-history", "GET", {
      uan_number: uanNumber,
    });
  }

  // MCA - CIN Verification
  async verifyCIN(cinNumber: string): Promise<any> {
    return this.request("/verification/mca/cin", "GET", {
      id_number: cinNumber,
    });
  }

  // MCA - DIN Verification
  async verifyDIN(dinNumber: string): Promise<any> {
    return this.request("/verification/mca/din", "GET", {
      id_number: dinNumber,
    });
  }

  // Mobile Intelligence - Mobile to Name
  async mobileToName(mobileNumber: string): Promise<any> {
    return this.request("/mobile-intelligence/mobile-to-name", "GET", {
      mobile_number: mobileNumber,
    });
  }

  // Mobile Intelligence - Mobile to PAN
  async mobileToPAN(mobileNumber: string): Promise<any> {
    return this.request("/mobile-intelligence/mobile-to-pan", "GET", {
      mobile_number: mobileNumber,
    });
  }

  // Mobile Intelligence - Mobile to DL
  async mobileToDL(mobileNumber: string): Promise<any> {
    return this.request("/mobile-intelligence/mobile-to-dl-details", "GET", {
      mobile_number: mobileNumber,
    });
  }

  // Mobile Intelligence - Mobile to Digital Age
  async mobileToDigitalAge(mobileNumber: string): Promise<any> {
    return this.request("/mobile-intelligence/mobile-to-digital-age", "GET", {
      mobile_number: mobileNumber,
    });
  }

  // Mobile Intelligence - Mobile to Network Details
  async mobileToNetworkDetails(mobileNumber: string): Promise<any> {
    return this.request("/mobile-intelligence/mobile-to-network-details", "GET", {
      mobile_number: mobileNumber,
    });
  }

  // Mobile Intelligence - Mobile to Multiple UPI
  async mobileToMultipleUPI(mobileNumber: string): Promise<any> {
    return this.request("/mobile-intelligence/mobile-to-multiple-upi", "GET", {
      mobile_number: mobileNumber,
    });
  }

  // Mobile Intelligence - Mobile to UAN List
  async mobileToUANList(mobileNumber: string): Promise<any> {
    return this.request("/mobile-intelligence/mobile-to-uan-list", "GET", {
      mobile_number: mobileNumber,
    });
  }

  // Credit Score/Report
  async getCreditReport(
    fullName: string,
    panNumber: string,
    mobileNumber: string,
    consent: string = "Y",
    purpose: string = "For Loan Eligibility Check"
  ): Promise<any> {
    return this.request("/financial-services/credit-bureau/credit-report", "GET", {
      full_name: fullName,
      pan_number: panNumber,
      mobile_number: mobileNumber,
      consent: consent,
      purpose: purpose,
    });
  }

  // MSME - Post Udyam Details
  async postUdyamDetails(udyamAadhaarNumber: string): Promise<any> {
    return this.request("/verification/async/post-udyam-details", "POST", {
      udyam_aadhaar_number: udyamAadhaarNumber,
    });
  }

  // MSME - Get Udyam Details
  async getUdyamDetails(requestId: string): Promise<any> {
    return this.request("/verification/async/get-udyam-details", "GET", {
      request_id: requestId,
    });
  }

  // MSME - Post Udyog Details
  async postUdyogDetails(udyogAadhaarNumber: string): Promise<any> {
    return this.request("/verification/async/post-udyog-details", "POST", {
      udyog_aadhaar_number: udyogAadhaarNumber,
    });
  }

  // MSME - Get Udyog Details
  async getUdyogDetails(requestId: string): Promise<any> {
    return this.request("/verification/async/get-udyog-details", "GET", {
      request_id: requestId,
    });
  }

  // Document OCR - Voter ID
  async extractVoterID(document1: string, document2: string, name: string): Promise<any> {
    const token = await this.authenticate();

    const response = await fetch(`${DEEPVUE_BASE_URL}/documents/extraction/ind_voter_id`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "x-api-key": this.config.clientSecret,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        document1,
        document2,
        name,
      }),
    });

    if (!response.ok) {
      throw new Error("Voter ID extraction failed");
    }

    return await response.json();
  }

  // Document OCR - PAN Card
  async extractPAN(document1: string, name: string): Promise<any> {
    const token = await this.authenticate();

    const response = await fetch(`${DEEPVUE_BASE_URL}/documents/extraction/ind_pancard`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "x-api-key": this.config.clientSecret,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        document1,
        name,
      }),
    });

    if (!response.ok) {
      throw new Error("PAN extraction failed");
    }

    return await response.json();
  }

  // Document OCR - Aadhaar
  async extractAadhaar(document1: string, document2: string, name: string): Promise<any> {
    const token = await this.authenticate();

    const response = await fetch(`${DEEPVUE_BASE_URL}/documents/extraction/ind_aadhaar`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "x-api-key": this.config.clientSecret,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        document1,
        document2,
        name,
      }),
    });

    if (!response.ok) {
      throw new Error("Aadhaar extraction failed");
    }

    return await response.json();
  }

  // Document OCR - Driving License
  async extractDrivingLicense(document1: string, document2: string, name: string): Promise<any> {
    const token = await this.authenticate();

    const response = await fetch(`${DEEPVUE_BASE_URL}/documents/extraction/ind_driving_license`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "x-api-key": this.config.clientSecret,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        document1,
        document2,
        name,
      }),
    });

    if (!response.ok) {
      throw new Error("Driving License extraction failed");
    }

    return await response.json();
  }

  // Document OCR - Bank Cheque
  async extractBankCheque(document1: string): Promise<any> {
    const token = await this.authenticate();

    const response = await fetch(`${DEEPVUE_BASE_URL}/documents/extraction/ind_bank_cheque`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "x-api-key": this.config.clientSecret,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        document1,
      }),
    });

    if (!response.ok) {
      throw new Error("Bank Cheque extraction failed");
    }

    return await response.json();
  }

  // Document OCR - GSTIN Certificate
  async extractGSTINCertificate(document1: string): Promise<any> {
    const token = await this.authenticate();

    const response = await fetch(`${DEEPVUE_BASE_URL}/documents/extraction/gstin-certificate`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "x-api-key": this.config.clientSecret,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        document1,
      }),
    });

    if (!response.ok) {
      throw new Error("GSTIN Certificate extraction failed");
    }

    return await response.json();
  }

  // Face Match
  async faceMatch(fileA: File, fileB: File): Promise<any> {
    const token = await this.authenticate();

    const formData = new FormData();
    formData.append("file_a", fileA);
    formData.append("file_b", fileB);

    const response = await fetch(`${DEEPVUE_BASE_URL}/facematch`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "x-api-key": this.config.clientSecret,
      },
      body: formData,
    });

    if (!response.ok) {
      throw new Error("Face match failed");
    }

    return await response.json();
  }

  // Liveness Check
  async livenessCheck(imageBase64: string): Promise<any> {
    const token = await this.authenticate();

    const response = await fetch(`${DEEPVUE_BASE_URL}/liveness-check`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "x-api-key": this.config.clientSecret,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        image: imageBase64,
      }),
    });

    if (!response.ok) {
      throw new Error("Liveness check failed");
    }

    return await response.json();
  }

  // ITR APIs - Create Client
  async createITRClient(username: string, password: string): Promise<any> {
    const token = await this.authenticate();

    const response = await fetch(`${DEEPVUE_BASE_URL}/verification/itr/create-client`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "x-api-key": this.config.clientSecret,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        username,
        password,
      }),
    });

    if (!response.ok) {
      throw new Error("ITR client creation failed");
    }

    return await response.json();
  }

  // ITR APIs - Download ITR
  async downloadITR(itrClientId: string): Promise<any> {
    const token = await this.authenticate();

    const response = await fetch(`${DEEPVUE_BASE_URL}/verification/itr/itr-download`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "x-api-key": this.config.clientSecret,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        itr_client_id: itrClientId,
      }),
    });

    if (!response.ok) {
      throw new Error("ITR download failed");
    }

    return await response.json();
  }

  // ITR APIs - Download 26AS
  async download26AS(itrClientId: string): Promise<any> {
    const token = await this.authenticate();

    const response = await fetch(`${DEEPVUE_BASE_URL}/verification/itr/26as-download`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "x-api-key": this.config.clientSecret,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        itr_client_id: itrClientId,
      }),
    });

    if (!response.ok) {
      throw new Error("26AS download failed");
    }

    return await response.json();
  }

  // ITR APIs - Get ITR Details
  async getITRDetails(itrClientId: string, itrId: string): Promise<any> {
    return this.request("/verification/itr/get-itr-details", "GET", {
      itr_client_id: itrClientId,
      itr_id: itrId,
    });
  }

  // ITR APIs - Get 26AS Details
  async get26ASDetails(itrClientId: string, tdsId: string): Promise<any> {
    return this.request("/verification/itr/get-26as-details", "GET", {
      itr_client_id: itrClientId,
      tds_id: tdsId,
    });
  }

  // GST Taxpayer APIs - Generate OTP
  async generateGSTTaxpayerOTP(gstinNumber: string, userName: string): Promise<any> {
    const token = await this.authenticate();

    const url = new URL(`${DEEPVUE_BASE_URL}/gst/tax-payer/generate-otp`);
    url.searchParams.append("gstin_number", gstinNumber);
    url.searchParams.append("user_name", userName);

    const response = await fetch(url.toString(), {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "x-api-key": this.config.clientSecret,
      },
    });

    if (!response.ok) {
      throw new Error("Failed to generate GST Taxpayer OTP");
    }

    return await response.json();
  }

  // GST Taxpayer APIs - Verify OTP
  async verifyGSTTaxpayerOTP(gstinNumber: string, userName: string, otp: string): Promise<any> {
    const token = await this.authenticate();

    const url = new URL(`${DEEPVUE_BASE_URL}/gst/tax-payer/verify-otp`);
    url.searchParams.append("gstin_number", gstinNumber);
    url.searchParams.append("user_name", userName);
    url.searchParams.append("otp", otp);

    const response = await fetch(url.toString(), {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "x-api-key": this.config.clientSecret,
      },
    });

    if (!response.ok) {
      throw new Error("Failed to verify GST Taxpayer OTP");
    }

    return await response.json();
  }

  // GST Taxpayer APIs - Session Expiry
  async getGSTTaxpayerSession(gstinNumber: string): Promise<any> {
    return this.request("/gst/tax-payer/session", "GET", {
      gstin_number: gstinNumber,
    });
  }

  // GST Taxpayer APIs - Refresh Session
  async refreshGSTTaxpayerSession(gstinNumber: string): Promise<any> {
    const token = await this.authenticate();

    const url = new URL(`${DEEPVUE_BASE_URL}/gst/tax-payer/refresh-session`);
    url.searchParams.append("gstin_number", gstinNumber);

    const response = await fetch(url.toString(), {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "x-api-key": this.config.clientSecret,
      },
    });

    if (!response.ok) {
      throw new Error("Failed to refresh GST Taxpayer session");
    }

    return await response.json();
  }

  // GST Taxpayer APIs - Cash ITC Balance
  async getGSTCashITCBalance(gstinNumber: string, year: string, month: string): Promise<any> {
    return this.request("/gst/tax-payer/ledgers/balance", "GET", {
      gstin_number: gstinNumber,
      year: year,
      month: month,
    });
  }

  // GST Taxpayer APIs - Cash Ledger
  async getGSTCashLedger(gstinNumber: string, fromDate: string, toDate: string): Promise<any> {
    return this.request("/gst/tax-payer/ledgers/cash", "GET", {
      gstin_number: gstinNumber,
      from_date: fromDate,
      to_date: toDate,
    });
  }

  // GST Taxpayer APIs - ITC Ledger
  async getGSTITCLedger(gstinNumber: string, fromDate: string, toDate: string): Promise<any> {
    return this.request("/gst/tax-payer/ledgers/itc", "GET", {
      gstin_number: gstinNumber,
      from_date: fromDate,
      to_date: toDate,
    });
  }

  // Digilocker APIs - Initiate Session
  async initiateDigilockerSession(consent: string, purpose: string, redirectUrl: string): Promise<any> {
    const headers = {
      "x-api-key": this.config.clientSecret,
      "client-id": this.config.clientId,
      "Content-Type": "application/json",
    };

    const response = await fetch(`${DEEPVUE_BASE_URL}/kyc/digilocker/initiate-session`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        consent,
        purpose,
        redirect_url: redirectUrl,
      }),
    });

    if (!response.ok) {
      throw new Error("Failed to initiate Digilocker session");
    }

    return await response.json();
  }

  // Digilocker APIs - Access Token
  async getDigilockerAccessToken(
    consent: string,
    purpose: string,
    initialDeepvueTransactionId: string,
    digilockerCode: string
  ): Promise<any> {
    const headers = {
      "x-api-key": this.config.clientSecret,
      "client-id": this.config.clientId,
      "Content-Type": "application/json",
    };

    const response = await fetch(`${DEEPVUE_BASE_URL}/kyc/digilocker/access-token`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        consent,
        purpose,
        initial_deepvue_transaction_id: initialDeepvueTransactionId,
        digilocker_code: digilockerCode,
      }),
    });

    if (!response.ok) {
      throw new Error("Failed to get Digilocker access token");
    }

    return await response.json();
  }

  // Digilocker APIs - E-Aadhaar
  async getDigilockerEAadhaar(consent: string, purpose: string, initialDeepvueTransactionId: string): Promise<any> {
    const headers = {
      "x-api-key": this.config.clientSecret,
      "client-id": this.config.clientId,
      "Content-Type": "application/json",
    };

    const response = await fetch(`${DEEPVUE_BASE_URL}/kyc/digilocker/eaadhaar`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        consent,
        purpose,
        initial_deepvue_transaction_id: initialDeepvueTransactionId,
      }),
    });

    if (!response.ok) {
      throw new Error("Failed to get E-Aadhaar from Digilocker");
    }

    return await response.json();
  }

  // Digilocker APIs - Issued Files
  async getDigilockerIssuedFiles(consent: string, purpose: string, initialDeepvueTransactionId: string): Promise<any> {
    const headers = {
      "x-api-key": this.config.clientSecret,
      "client-id": this.config.clientId,
      "Content-Type": "application/json",
    };

    const response = await fetch(`${DEEPVUE_BASE_URL}/kyc/digilocker/issued-files`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        consent,
        purpose,
        initial_deepvue_transaction_id: initialDeepvueTransactionId,
      }),
    });

    if (!response.ok) {
      throw new Error("Failed to get issued files from Digilocker");
    }

    return await response.json();
  }

  // Digilocker APIs - Download File
  async downloadDigilockerFile(consent: string, purpose: string, initialDeepvueTransactionId: string): Promise<any> {
    const headers = {
      "x-api-key": this.config.clientSecret,
      "client-id": this.config.clientId,
      "Content-Type": "application/json",
    };

    const response = await fetch(`${DEEPVUE_BASE_URL}/kyc/digilocker/file`, {
      method: "POST",
      headers,
      body: JSON.stringify({
        consent,
        purpose,
        initial_deepvue_transaction_id: initialDeepvueTransactionId,
      }),
    });

    if (!response.ok) {
      throw new Error("Failed to download file from Digilocker");
    }

    return await response.json();
  }

  // Passport Verification (Currently not directly available, would use OCR or custom endpoint)
  async verifyPassport(passportNumber: string, dateOfBirth: string): Promise<any> {
    // This is a placeholder - DeepVue may not have direct passport verification
    // You might need to use OCR or contact DeepVue for this endpoint
    throw new Error("Passport verification not directly supported by DeepVue");
  }
}

// Export singleton instance
export const deepvueService = new DeepVueService();
