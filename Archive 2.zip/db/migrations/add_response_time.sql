-- Migration: Add response_time to transactions table
-- This tracks API response time in milliseconds

-- Add response_time column to transactions table
ALTER TABLE transactions 
ADD COLUMN IF NOT EXISTS response_time INTEGER DEFAULT 0;

-- Add response_time column to wallet_transactions table
ALTER TABLE wallet_transactions 
ADD COLUMN IF NOT EXISTS response_time INTEGER DEFAULT 0;

-- Add index for performance queries
CREATE INDEX IF NOT EXISTS idx_transactions_response_time ON transactions(response_time);

-- Add comments
COMMENT ON COLUMN transactions.response_time IS 'API response time in milliseconds';
COMMENT ON COLUMN wallet_transactions.response_time IS 'API response time in milliseconds';
