-- Admin Authentication Table
-- This stores admin user credentials securely

CREATE TABLE IF NOT EXISTS admin_users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255),
    role VARCHAR(50) DEFAULT 'admin', -- 'super_admin', 'admin', 'viewer'
    is_active BOOLEAN DEFAULT TRUE,
    last_login TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for admin_users
CREATE INDEX IF NOT EXISTS idx_admin_users_username 
ON admin_users(username);

CREATE INDEX IF NOT EXISTS idx_admin_users_email 
ON admin_users(email);

CREATE INDEX IF NOT EXISTS idx_admin_users_is_active 
ON admin_users(is_active);

-- Admin sessions table
CREATE TABLE IF NOT EXISTS admin_sessions (
    id SERIAL PRIMARY KEY,
    admin_user_id INTEGER REFERENCES admin_users(id) ON DELETE CASCADE,
    session_token VARCHAR(500) UNIQUE NOT NULL,
    ip_address VARCHAR(50),
    user_agent TEXT,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create index for admin_sessions
CREATE INDEX IF NOT EXISTS idx_admin_sessions_token 
ON admin_sessions(session_token);

CREATE INDEX IF NOT EXISTS idx_admin_sessions_admin_user_id 
ON admin_sessions(admin_user_id);

CREATE INDEX IF NOT EXISTS idx_admin_sessions_expires_at 
ON admin_sessions(expires_at);

-- Add comments
COMMENT ON TABLE admin_users IS 'Stores admin user credentials and information';
COMMENT ON TABLE admin_sessions IS 'Stores active admin sessions for authentication';

-- Insert default admin user (password: admin123 - CHANGE THIS!)
-- Password hash generated using bcrypt with 10 rounds
INSERT INTO admin_users (username, email, password_hash, full_name, role)
VALUES (
    'admin',
    'admin@truverify.com',
    '$2b$10$rKvVPPZQz7RXGxXxCqYOi.FxkfJFJ0p0nQ0zQQhN7xYx8jXKW6p9S', -- password: admin123
    'System Administrator',
    'super_admin'
) ON CONFLICT (username) DO NOTHING;

SELECT 'Admin authentication tables created successfully!' as status;
