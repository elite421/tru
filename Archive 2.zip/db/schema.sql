-- TruVerify Database Schema
-- This file contains the database schema for the verification system

-- Create database if not exists (already handled in db.tsx)

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(15),
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255),
    company_name VARCHAR(255),
    email_verified BOOLEAN DEFAULT FALSE,
    phone_verified BOOLEAN DEFAULT FALSE,
    pricing_plan_id INTEGER, -- Reference to custom pricing plan
    plan_expires_at TIMESTAMP, -- When the custom plan expires
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP
);

-- Pricing Plans table
CREATE TABLE IF NOT EXISTS pricing_plans (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    description TEXT,
    is_default BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    created_by INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Contact Messages table (for user support/contact form)
CREATE TABLE IF NOT EXISTS contact_messages (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    company_name VARCHAR(255),
    subject VARCHAR(500),
    message TEXT NOT NULL,
    status VARCHAR(50) DEFAULT 'unread', -- 'unread', 'read', 'replied', 'resolved'
    admin_reply TEXT,
    replied_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Support Tickets table (for help desk and ticket management)
CREATE TABLE IF NOT EXISTS support_tickets (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    user_email VARCHAR(255) NOT NULL,
    subject VARCHAR(500) NOT NULL,
    description TEXT NOT NULL,
    category VARCHAR(50) DEFAULT 'technical', -- 'technical', 'billing', 'feature', 'other'
    priority VARCHAR(20) DEFAULT 'medium', -- 'low', 'medium', 'high', 'urgent'
    status VARCHAR(50) DEFAULT 'open', -- 'open', 'in-progress', 'closed'
    admin_notes TEXT,
    assigned_to INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    closed_at TIMESTAMP
);

-- Index for faster ticket queries
CREATE INDEX IF NOT EXISTS idx_support_tickets_user_id ON support_tickets(user_id);
CREATE INDEX IF NOT EXISTS idx_support_tickets_status ON support_tickets(status);
CREATE INDEX IF NOT EXISTS idx_support_tickets_created_at ON support_tickets(created_at DESC);

-- Admin Activity Log table
CREATE TABLE IF NOT EXISTS admin_activity_log (
    id SERIAL PRIMARY KEY,
    admin_username VARCHAR(255) NOT NULL,
    action VARCHAR(255) NOT NULL,
    description TEXT,
    entity_type VARCHAR(100), -- 'user', 'pricing_plan', 'message', etc.
    entity_id INTEGER,
    ip_address VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Pricing Plan Rates table
CREATE TABLE IF NOT EXISTS pricing_plan_rates (
    id SERIAL PRIMARY KEY,
    pricing_plan_id INTEGER REFERENCES pricing_plans(id) ON DELETE CASCADE,
    verification_type VARCHAR(50) NOT NULL, -- 'email', 'phone', 'aadhar', 'pan', 'gst', 'driving-license', 'passport', 'bank-account', 'voter-id'
    price DECIMAL(10, 2) NOT NULL CHECK (price >= 0),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(pricing_plan_id, verification_type)
);

-- Migration: Add pricing_plan_id column to users table if it doesn't exist
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name='users' AND column_name='pricing_plan_id') THEN
        ALTER TABLE users ADD COLUMN pricing_plan_id INTEGER;
    END IF;
END $$;

-- Migration: Add plan_expires_at column to users table if it doesn't exist
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name='users' AND column_name='plan_expires_at') THEN
        ALTER TABLE users ADD COLUMN plan_expires_at TIMESTAMP;
    END IF;
END $$;

-- Migration: Add company_name column to users table if it doesn't exist
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.columns 
                   WHERE table_name='users' AND column_name='company_name') THEN
        ALTER TABLE users ADD COLUMN company_name VARCHAR(255);
    END IF;
END $$;

-- Add foreign key constraint for users.pricing_plan_id
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM information_schema.table_constraints 
                   WHERE constraint_name='fk_users_pricing_plan') THEN
        ALTER TABLE users ADD CONSTRAINT fk_users_pricing_plan 
            FOREIGN KEY (pricing_plan_id) REFERENCES pricing_plans(id) ON DELETE SET NULL;
    END IF;
END $$;

-- Verification requests table
CREATE TABLE IF NOT EXISTS verification_requests (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    verification_type VARCHAR(50) NOT NULL, -- 'aadhar', 'pan', 'dl', 'passport', etc.
    document_number VARCHAR(100) DEFAULT '',
    status VARCHAR(20) NOT NULL DEFAULT 'pending', -- 'pending', 'processing', 'verified', 'failed', 'success'
    cost DECIMAL(10, 2) DEFAULT 0, -- Cost of the verification
    request_data JSONB, -- Store request parameters
    response_data JSONB, -- Store verification response
    verification_data JSONB, -- Store complete verification data
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    verified_at TIMESTAMP,
    expires_at TIMESTAMP
);

-- Aadhar verifications
CREATE TABLE IF NOT EXISTS aadhar_verifications (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    aadhar_number VARCHAR(12) UNIQUE NOT NULL,
    name VARCHAR(255),
    gender VARCHAR(10),
    dob DATE,
    address TEXT,
    verified BOOLEAN DEFAULT FALSE,
    verified_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- PAN verifications
CREATE TABLE IF NOT EXISTS pan_verifications (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    pan_number VARCHAR(10) UNIQUE NOT NULL,
    name VARCHAR(255),
    category VARCHAR(50),
    state VARCHAR(100),
    status VARCHAR(20),
    verified BOOLEAN DEFAULT FALSE,
    verified_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Driving license verifications
CREATE TABLE IF NOT EXISTS driving_license_verifications (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    license_number VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(255),
    dob DATE,
    address TEXT,
    issue_date DATE,
    expiry_date DATE,
    vehicle_classes JSONB,
    rto VARCHAR(100),
    state VARCHAR(100),
    verified BOOLEAN DEFAULT FALSE,
    verified_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Passport verifications
CREATE TABLE IF NOT EXISTS passport_verifications (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    passport_number VARCHAR(8) UNIQUE NOT NULL,
    file_number VARCHAR(20),
    name VARCHAR(255),
    dob DATE,
    place_of_birth VARCHAR(255),
    issue_date DATE,
    expiry_date DATE,
    place_of_issue VARCHAR(255),
    verified BOOLEAN DEFAULT FALSE,
    verified_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- GST verifications
CREATE TABLE IF NOT EXISTS gst_verifications (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    gst_number VARCHAR(15) UNIQUE NOT NULL,
    legal_name VARCHAR(255),
    trade_name VARCHAR(255),
    pan_number VARCHAR(10),
    registration_date DATE,
    status VARCHAR(50),
    state VARCHAR(100),
    business_address JSONB,
    verified BOOLEAN DEFAULT FALSE,
    verified_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Bank account verifications
CREATE TABLE IF NOT EXISTS bank_account_verifications (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    account_number VARCHAR(18) NOT NULL,
    ifsc_code VARCHAR(11) NOT NULL,
    account_holder_name VARCHAR(255),
    bank_name VARCHAR(255),
    branch_name VARCHAR(255),
    account_type VARCHAR(50),
    verified BOOLEAN DEFAULT FALSE,
    name_match BOOLEAN,
    verified_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(account_number, ifsc_code)
);

-- Voter ID verifications
CREATE TABLE IF NOT EXISTS voter_id_verifications (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    epic_number VARCHAR(10) UNIQUE NOT NULL,
    name VARCHAR(255),
    gender VARCHAR(10),
    age INTEGER,
    dob DATE,
    address JSONB,
    constituency JSONB,
    verified BOOLEAN DEFAULT FALSE,
    verified_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Email verifications (OTP)
CREATE TABLE IF NOT EXISTS email_verifications (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    otp VARCHAR(6) NOT NULL,
    verified BOOLEAN DEFAULT FALSE,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    verified_at TIMESTAMP
);

-- Phone verifications (OTP)
CREATE TABLE IF NOT EXISTS phone_verifications (
    id SERIAL PRIMARY KEY,
    phone_number VARCHAR(15) NOT NULL,
    otp VARCHAR(6) NOT NULL,
    verified BOOLEAN DEFAULT FALSE,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    verified_at TIMESTAMP
);

-- Audit log for all verifications
CREATE TABLE IF NOT EXISTS verification_audit_log (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    verification_type VARCHAR(50) NOT NULL,
    document_number VARCHAR(100),
    action VARCHAR(50) NOT NULL, -- 'initiated', 'verified', 'failed', 'expired'
    ip_address INET,
    user_agent TEXT,
    metadata JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Wallet table for user balances
CREATE TABLE IF NOT EXISTS wallets (
    id SERIAL PRIMARY KEY,
    user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    balance DECIMAL(10, 2) DEFAULT 0.00 NOT NULL CHECK (balance >= 0),
    currency VARCHAR(3) DEFAULT 'INR',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Wallet transactions table
CREATE TABLE IF NOT EXISTS wallet_transactions (
    id SERIAL PRIMARY KEY,
    wallet_id INTEGER REFERENCES wallets(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    transaction_type VARCHAR(20) NOT NULL, -- 'credit', 'debit'
    amount DECIMAL(10, 2) NOT NULL,
    base_amount DECIMAL(10, 2),
    gst_amount DECIMAL(10, 2),
    gst_percentage DECIMAL(5, 2) DEFAULT 18.00,
    deepvue_transaction_id VARCHAR(255),
    balance_before DECIMAL(10, 2) NOT NULL,
    balance_after DECIMAL(10, 2) NOT NULL,
    description TEXT,
    reference_type VARCHAR(50), -- 'verification', 'recharge', 'refund'
    reference_id INTEGER, -- ID of related verification or payment
    payment_method VARCHAR(50), -- 'card', 'upi', 'netbanking', etc.
    payment_id VARCHAR(255), -- External payment gateway transaction ID
    status VARCHAR(20) DEFAULT 'completed', -- 'pending', 'completed', 'failed'
    metadata JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Wallet recharge requests
CREATE TABLE IF NOT EXISTS wallet_recharge_requests (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    wallet_id INTEGER REFERENCES wallets(id) ON DELETE CASCADE,
    amount DECIMAL(10, 2) NOT NULL,
    payment_method VARCHAR(50),
    payment_gateway VARCHAR(50), -- 'razorpay', 'stripe', etc.
    payment_id VARCHAR(255),
    order_id VARCHAR(255) UNIQUE,
    status VARCHAR(20) DEFAULT 'pending', -- 'pending', 'processing', 'completed', 'failed', 'cancelled'
    payment_response JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP
);

-- Verification history table
CREATE TABLE IF NOT EXISTS verification_history (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    verification_type VARCHAR(100) NOT NULL,
    status VARCHAR(50) NOT NULL,
    details JSONB,
    amount_charged DECIMAL(10, 2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Verification cache table to store verified data
CREATE TABLE IF NOT EXISTS verification_cache (
    id SERIAL PRIMARY KEY,
    verification_type VARCHAR(100) NOT NULL,
    verification_key VARCHAR(500) NOT NULL,
    verification_data JSONB NOT NULL,
    deepvue_transaction_id VARCHAR(255),
    first_verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_accessed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    access_count INTEGER DEFAULT 1,
    UNIQUE(verification_type, verification_key)
);

-- Transactions table for all successful verifications
CREATE TABLE IF NOT EXISTS transactions (
    id SERIAL PRIMARY KEY,
    user_id VARCHAR(255) NOT NULL,
    verification_type VARCHAR(100) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    base_amount DECIMAL(10, 2),
    gst_amount DECIMAL(10, 2),
    gst_percentage DECIMAL(5, 2) DEFAULT 18.00,
    deepvue_transaction_id VARCHAR(255),
    status VARCHAR(50) DEFAULT 'success',
    cache_hit BOOLEAN DEFAULT false,
    details JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create index on transactions
CREATE INDEX IF NOT EXISTS idx_transactions_user 
ON transactions(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_transactions_status 
ON transactions(status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_transactions_deepvue_id 
ON transactions(deepvue_transaction_id);

-- Indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_verification_requests_user_id ON verification_requests(user_id);
CREATE INDEX IF NOT EXISTS idx_verification_requests_status ON verification_requests(status);
CREATE INDEX IF NOT EXISTS idx_verification_requests_type ON verification_requests(verification_type);
CREATE INDEX IF NOT EXISTS idx_verification_audit_log_user_id ON verification_audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_verification_audit_log_created_at ON verification_audit_log(created_at);
CREATE INDEX IF NOT EXISTS idx_aadhar_verifications_user_id ON aadhar_verifications(user_id);
CREATE INDEX IF NOT EXISTS idx_pan_verifications_user_id ON pan_verifications(user_id);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_phone ON users(phone);
CREATE INDEX IF NOT EXISTS idx_wallets_user_id ON wallets(user_id);
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_wallet_id ON wallet_transactions(wallet_id);
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_user_id ON wallet_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_created_at ON wallet_transactions(created_at);
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_deepvue_id ON wallet_transactions(deepvue_transaction_id);
CREATE INDEX IF NOT EXISTS idx_wallet_recharge_requests_user_id ON wallet_recharge_requests(user_id);
CREATE INDEX IF NOT EXISTS idx_wallet_recharge_requests_status ON wallet_recharge_requests(status);
CREATE INDEX IF NOT EXISTS idx_users_pricing_plan_id ON users(pricing_plan_id);
CREATE INDEX IF NOT EXISTS idx_users_plan_expires_at ON users(plan_expires_at);
CREATE INDEX IF NOT EXISTS idx_users_company_name ON users(company_name);
CREATE INDEX IF NOT EXISTS idx_contact_messages_status ON contact_messages(status);
CREATE INDEX IF NOT EXISTS idx_contact_messages_email ON contact_messages(email);
CREATE INDEX IF NOT EXISTS idx_contact_messages_user_id ON contact_messages(user_id);
CREATE INDEX IF NOT EXISTS idx_admin_activity_log_admin ON admin_activity_log(admin_username);
CREATE INDEX IF NOT EXISTS idx_admin_activity_log_created ON admin_activity_log(created_at);
CREATE INDEX IF NOT EXISTS idx_pricing_plan_rates_plan_id ON pricing_plan_rates(pricing_plan_id);
CREATE INDEX IF NOT EXISTS idx_pricing_plan_rates_type ON pricing_plan_rates(verification_type);
CREATE INDEX IF NOT EXISTS idx_pricing_plans_is_default ON pricing_plans(is_default);

-- Updated at trigger function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply updated_at trigger to all tables
DROP TRIGGER IF EXISTS update_users_updated_at ON users;
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_verification_requests_updated_at ON verification_requests;
CREATE TRIGGER update_verification_requests_updated_at BEFORE UPDATE ON verification_requests
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_aadhar_verifications_updated_at ON aadhar_verifications;
CREATE TRIGGER update_aadhar_verifications_updated_at BEFORE UPDATE ON aadhar_verifications
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_pan_verifications_updated_at ON pan_verifications;
CREATE TRIGGER update_pan_verifications_updated_at BEFORE UPDATE ON pan_verifications
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_driving_license_verifications_updated_at ON driving_license_verifications;
CREATE TRIGGER update_driving_license_verifications_updated_at BEFORE UPDATE ON driving_license_verifications
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_passport_verifications_updated_at ON passport_verifications;
CREATE TRIGGER update_passport_verifications_updated_at BEFORE UPDATE ON passport_verifications
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_gst_verifications_updated_at ON gst_verifications;
CREATE TRIGGER update_gst_verifications_updated_at BEFORE UPDATE ON gst_verifications
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_bank_account_verifications_updated_at ON bank_account_verifications;
CREATE TRIGGER update_bank_account_verifications_updated_at BEFORE UPDATE ON bank_account_verifications
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_voter_id_verifications_updated_at ON voter_id_verifications;
CREATE TRIGGER update_voter_id_verifications_updated_at BEFORE UPDATE ON voter_id_verifications
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_wallets_updated_at ON wallets;
CREATE TRIGGER update_wallets_updated_at BEFORE UPDATE ON wallets
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_wallet_recharge_requests_updated_at ON wallet_recharge_requests;
CREATE TRIGGER update_wallet_recharge_requests_updated_at BEFORE UPDATE ON wallet_recharge_requests
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_pricing_plans_updated_at ON pricing_plans;
CREATE TRIGGER update_pricing_plans_updated_at BEFORE UPDATE ON pricing_plans
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_pricing_plan_rates_updated_at ON pricing_plan_rates;
CREATE TRIGGER update_pricing_plan_rates_updated_at BEFORE UPDATE ON pricing_plan_rates
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_contact_messages_updated_at ON contact_messages;
CREATE TRIGGER update_contact_messages_updated_at BEFORE UPDATE ON contact_messages
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
