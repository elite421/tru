import { Client, Pool, QueryResult } from "pg";

// Next.js automatically loads .env.local files
const db_host = process.env.DB_HOST || 'localhost';
const db_port = Number(process.env.DB_PORT) || 5432;
const db_user = process.env.DB_USER || 'postgres';
const db_password = process.env.DB_PASSWORD || '123';

// Create a connection pool for better performance
const pool = new Pool({
    host: db_host,
    port: db_port,
    user: db_user,
    password: db_password,
    database: "truverify",
    max: 20, // Maximum number of clients in the pool
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 2000,
});

// Query function for executing SQL queries
export async function query(text: string, params?: any[]): Promise<QueryResult> {
    const start = Date.now();
    try {
        const res = await pool.query(text, params);
        const duration = Date.now() - start;
        console.log('Executed query', { text, duration, rows: res.rowCount });
        return res;
    } catch (error) {
        console.error('Database query error:', error);
        throw error;
    }
}

// Initialize database and create tables if needed
export async function Dbconfig() {
    const defaultClient = new Client({
        host: db_host,
        port: db_port,
        user: db_user,
        password: db_password,
        database: "postgres"
    });

    try {
        await defaultClient.connect();
        const checkdb = `SELECT 1 FROM pg_database WHERE datname = 'truverify';`;
        const res = await defaultClient.query(checkdb);
        if (res.rowCount === 0) {
            await defaultClient.query(`CREATE DATABASE truverify;`);
            console.log("Database truverify is created successfully");
        } else {
            console.log("Database already exists");
        }
    } catch (err: any) {
        console.log("Database creation error:", err.message);
    } finally {
        await defaultClient.end();
    }
}

// Export pool for direct access if needed
export { pool };

// Export default
export default { query, Dbconfig, pool };