"use client"

import { createContext, useContext, useState, useEffect, ReactNode } from "react"
import { useRouter } from "next/navigation"

interface User {
  userId: string
  email: string
  fullName?: string
  isAdmin?: boolean
}

interface UserContextType {
  user: User | null
  loading: boolean
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
  refreshUser: () => Promise<void>
}

const UserContext = createContext<UserContextType | undefined>(undefined)

export function UserProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  // Load user from localStorage on mount
  useEffect(() => {
    const loadUser = () => {
      const userId = localStorage.getItem("userId")
      const userEmail = localStorage.getItem("userEmail")
      const userName = localStorage.getItem("userName")
      const userToken = localStorage.getItem("userToken")
      const isAdmin = localStorage.getItem("isAdmin") === "true"

      if (userId && userEmail && userToken) {
        setUser({
          userId,
          email: userEmail,
          fullName: userName || undefined,
          isAdmin
        })
      }
      setLoading(false)
    }

    loadUser()
  }, [])

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      const response = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
        credentials: 'include' // Important: include cookies
      })

      if (response.ok) {
        const data = await response.json()
        
        // Store in localStorage for frontend access
        localStorage.setItem("userToken", data.token)
        localStorage.setItem("userId", data.user.id.toString())
        localStorage.setItem("userEmail", data.user.email)
        if (data.user.fullName) {
          localStorage.setItem("userName", data.user.fullName)
        }
        if (data.user.isAdmin) {
          localStorage.setItem("isAdmin", "true")
        }

        // Cookies are automatically set by the API response
        
        // Update state
        setUser({
          userId: data.user.id.toString(),
          email: data.user.email,
          fullName: data.user.fullName,
          isAdmin: data.user.isAdmin
        })

        return true
      }

      return false
    } catch (error) {
      console.error("Login error:", error)
      return false
    }
  }

  const logout = () => {
    // Clear localStorage
    localStorage.removeItem("userToken")
    localStorage.removeItem("userId")
    localStorage.removeItem("userEmail")
    localStorage.removeItem("userName")
    localStorage.removeItem("isAdmin")

    // Clear cookies by setting them to expire
    document.cookie = 'userToken=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT;'
    document.cookie = 'userId=; path=/; expires=Thu, 01 Jan 1970 00:00:01 GMT;'

    // Clear state
    setUser(null)

    // Redirect to login
    router.push("/login")
  }

  const refreshUser = async () => {
    const userId = localStorage.getItem("userId")
    if (!userId) return

    try {
      const response = await fetch(`/api/user/${userId}`)
      if (response.ok) {
        const data = await response.json()
        setUser({
          userId: data.id.toString(),
          email: data.email,
          fullName: data.full_name,
          isAdmin: data.isAdmin
        })
      }
    } catch (error) {
      console.error("Error refreshing user:", error)
    }
  }

  return (
    <UserContext.Provider value={{ user, loading, login, logout, refreshUser }}>
      {children}
    </UserContext.Provider>
  )
}

export function useUser() {
  const context = useContext(UserContext)
  if (!context) {
    throw new Error("useUser must be used within UserProvider")
  }
  return context
}
