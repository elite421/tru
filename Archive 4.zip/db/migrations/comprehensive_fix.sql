-- Comprehensive Database Fix
-- Run this on your Ubuntu server to fix all database issues
-- This script is idempotent (safe to run multiple times)

-- ============================================
-- STEP 1: Ensure users table exists properly
-- ============================================
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(15),
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(255),
    company_name VARCHAR(255),
    email_verified BOOLEAN DEFAULT FALSE,
    phone_verified BOOLEAN DEFAULT FALSE,
    pricing_plan_id INTEGER,
    plan_expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP
);

-- ============================================
-- STEP 2: Create pricing tables
-- ============================================
CREATE TABLE IF NOT EXISTS pricing_plans (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    description TEXT,
    is_default BOOLEAN DEFAULT FALSE,
    is_active BOOLEAN DEFAULT TRUE,
    created_by INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- STEP 3: Create wallet tables
-- ============================================
CREATE TABLE IF NOT EXISTS wallets (
    id SERIAL PRIMARY KEY,
    user_id INTEGER UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    balance DECIMAL(10, 2) DEFAULT 0.00 NOT NULL CHECK (balance >= 0),
    currency VARCHAR(3) DEFAULT 'INR',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- STEP 4: Drop and recreate transactions table with correct data types
-- ============================================
DROP TABLE IF EXISTS transactions CASCADE;

CREATE TABLE transactions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    verification_type VARCHAR(100) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    base_amount DECIMAL(10, 2),
    gst_amount DECIMAL(10, 2),
    gst_percentage DECIMAL(5, 2) DEFAULT 18.00,
    deepvue_transaction_id VARCHAR(255),
    response_time INTEGER,
    status VARCHAR(50) DEFAULT 'success',
    cache_hit BOOLEAN DEFAULT false,
    details JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create indexes on transactions
CREATE INDEX IF NOT EXISTS idx_transactions_user 
ON transactions(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_transactions_status 
ON transactions(status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_transactions_deepvue_id 
ON transactions(deepvue_transaction_id);

CREATE INDEX IF NOT EXISTS idx_transactions_type
ON transactions(verification_type);

-- ============================================
-- STEP 5: Drop and recreate verification_history with correct data types
-- ============================================
DROP TABLE IF EXISTS verification_history CASCADE;

CREATE TABLE verification_history (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    verification_type VARCHAR(100) NOT NULL,
    status VARCHAR(50) NOT NULL,
    details JSONB,
    amount_charged DECIMAL(10, 2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create indexes on verification_history
CREATE INDEX IF NOT EXISTS idx_verification_history_user 
ON verification_history(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_verification_history_type 
ON verification_history(verification_type);

CREATE INDEX IF NOT EXISTS idx_verification_history_status
ON verification_history(status);

-- ============================================
-- STEP 6: Create OTP verification tables
-- ============================================
CREATE TABLE IF NOT EXISTS email_verifications (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    otp VARCHAR(6) NOT NULL,
    verified BOOLEAN DEFAULT FALSE,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    verified_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS phone_verifications (
    id SERIAL PRIMARY KEY,
    phone_number VARCHAR(15) NOT NULL,
    otp VARCHAR(6) NOT NULL,
    verified BOOLEAN DEFAULT FALSE,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    verified_at TIMESTAMP
);

-- Create indexes for OTP tables
CREATE INDEX IF NOT EXISTS idx_email_verifications_email 
ON email_verifications(email, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_phone_verifications_phone 
ON phone_verifications(phone_number, created_at DESC);

-- ============================================
-- STEP 7: Create wallet_transactions table
-- ============================================
CREATE TABLE IF NOT EXISTS wallet_transactions (
    id SERIAL PRIMARY KEY,
    wallet_id INTEGER REFERENCES wallets(id) ON DELETE CASCADE,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    transaction_type VARCHAR(20) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    base_amount DECIMAL(10, 2),
    gst_amount DECIMAL(10, 2),
    gst_percentage DECIMAL(5, 2) DEFAULT 18.00,
    deepvue_transaction_id VARCHAR(255),
    response_time INTEGER,
    balance_before DECIMAL(10, 2) NOT NULL,
    balance_after DECIMAL(10, 2) NOT NULL,
    description TEXT,
    reference_type VARCHAR(50),
    reference_id INTEGER,
    payment_method VARCHAR(50),
    payment_id VARCHAR(255),
    status VARCHAR(20) DEFAULT 'completed',
    metadata JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes on wallet_transactions
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_wallet_id ON wallet_transactions(wallet_id);
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_user_id ON wallet_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_created_at ON wallet_transactions(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_deepvue_id ON wallet_transactions(deepvue_transaction_id);

-- ============================================
-- STEP 8: Create verification_requests table
-- ============================================
CREATE TABLE IF NOT EXISTS verification_requests (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
    verification_type VARCHAR(50) NOT NULL,
    document_number VARCHAR(100) DEFAULT '',
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    cost DECIMAL(10, 2) DEFAULT 0,
    request_data JSONB,
    response_data JSONB,
    verification_data JSONB,
    error_message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    verified_at TIMESTAMP,
    expires_at TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_verification_requests_user_id ON verification_requests(user_id);
CREATE INDEX IF NOT EXISTS idx_verification_requests_status ON verification_requests(status);
CREATE INDEX IF NOT EXISTS idx_verification_requests_type ON verification_requests(verification_type);

-- ============================================
-- STEP 9: Create verification cache table
-- ============================================
CREATE TABLE IF NOT EXISTS verification_cache (
    id SERIAL PRIMARY KEY,
    verification_type VARCHAR(100) NOT NULL,
    verification_key VARCHAR(500) NOT NULL,
    verification_data JSONB NOT NULL,
    deepvue_transaction_id VARCHAR(255),
    first_verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_accessed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    access_count INTEGER DEFAULT 1,
    UNIQUE(verification_type, verification_key)
);

-- ============================================
-- STEP 10: Verify all tables were created
-- ============================================
DO $$
DECLARE
    table_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO table_count
    FROM information_schema.tables
    WHERE table_name IN (
        'users', 'wallets', 'transactions', 'verification_history',
        'email_verifications', 'phone_verifications', 'wallet_transactions',
        'verification_requests', 'verification_cache', 'pricing_plans'
    );
    
    RAISE NOTICE 'Tables created/verified: % out of 10', table_count;
END $$;

-- ============================================
-- STEP 11: Show final verification results
-- ============================================
SELECT 
    table_name,
    EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = t.table_name
    ) as exists
FROM (
    VALUES 
        ('users'),
        ('wallets'),
        ('transactions'),
        ('verification_history'),
        ('email_verifications'),
        ('phone_verifications'),
        ('wallet_transactions'),
        ('verification_requests'),
        ('verification_cache'),
        ('pricing_plans')
) AS t(table_name)
ORDER BY table_name;

-- ============================================
-- STEP 12: Show row counts
-- ============================================
SELECT 
    'users' as table_name, 
    COUNT(*) as row_count 
FROM users
UNION ALL
SELECT 'transactions', COUNT(*) FROM transactions
UNION ALL
SELECT 'verification_history', COUNT(*) FROM verification_history
UNION ALL
SELECT 'wallets', COUNT(*) FROM wallets
ORDER BY table_name;
