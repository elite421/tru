"use client"

import { Shield, Lock, Eye, Database, UserCheck, Bell, Trash2, FileText } from "lucide-react"

export default function PrivacyPolicyPage() {
  const sections = [
    {
      icon: <Database className="w-6 h-6" />,
      title: "Information We Collect",
      content: [
        {
          subtitle: "Personal Information",
          text: "When you use our verification services, we collect information such as name, email address, phone number, and business details. For API users, we collect API keys and usage data."
        },
        {
          subtitle: "Verification Data",
          text: "We process identity documents and credentials you submit for verification, including Aadhar, PAN, passport, driving license, and other government-issued documents."
        },
        {
          subtitle: "Technical Information",
          text: "We automatically collect IP addresses, browser types, device information, and usage patterns to improve our services and ensure security."
        }
      ]
    },
    {
      icon: <Lock className="w-6 h-6" />,
      title: "How We Use Your Information",
      content: [
        {
          subtitle: "Verification Services",
          text: "We use your data solely to provide verification services, validate identity documents, and deliver accurate results."
        },
        {
          subtitle: "Service Improvement",
          text: "Anonymous usage data helps us improve our platform, enhance accuracy, and develop new features."
        },
        {
          subtitle: "Communication",
          text: "We may send service updates, security alerts, and important notifications related to your account."
        },
        {
          subtitle: "Legal Compliance",
          text: "We process data to comply with legal obligations, prevent fraud, and maintain platform security."
        }
      ]
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: "Data Protection & Security",
      content: [
        {
          subtitle: "Encryption",
          text: "All data transmissions are protected with 256-bit SSL/TLS encryption. Sensitive data at rest is encrypted using AES-256 encryption."
        },
        {
          subtitle: "Access Controls",
          text: "We implement strict access controls and authentication measures. Only authorized personnel can access sensitive data, and all access is logged."
        },
        {
          subtitle: "Regular Audits",
          text: "We conduct regular security audits, penetration testing, and vulnerability assessments to maintain the highest security standards."
        },
        {
          subtitle: "Data Centers",
          text: "Our data is stored in ISO 27001 certified data centers in India with 24/7 monitoring and physical security measures."
        }
      ]
    },
    {
      icon: <Eye className="w-6 h-6" />,
      title: "Data Sharing & Disclosure",
      content: [
        {
          subtitle: "Third-Party Services",
          text: "We partner with authorized government databases and verification providers. We only share data necessary for verification purposes."
        },
        {
          subtitle: "No Selling",
          text: "We never sell your personal information to third parties for marketing purposes."
        },
        {
          subtitle: "Legal Requirements",
          text: "We may disclose information when required by law, court order, or to protect our legal rights and users' safety."
        }
      ]
    },
    {
      icon: <UserCheck className="w-6 h-6" />,
      title: "Your Rights",
      content: [
        {
          subtitle: "Access & Correction",
          text: "You have the right to access, correct, or update your personal information at any time through your account dashboard."
        },
        {
          subtitle: "Data Deletion",
          text: "You can request deletion of your personal data, subject to legal retention requirements."
        },
        {
          subtitle: "Data Portability",
          text: "You can request a copy of your data in a machine-readable format."
        },
        {
          subtitle: "Opt-Out",
          text: "You can opt-out of marketing communications while still receiving essential service notifications."
        }
      ]
    },
    {
      icon: <Trash2 className="w-6 h-6" />,
      title: "Data Retention",
      content: [
        {
          subtitle: "Verification Records",
          text: "Verification records are retained for 7 years to comply with legal and regulatory requirements."
        },
        {
          subtitle: "Account Data",
          text: "Account information is retained while your account is active and for 90 days after account closure."
        },
        {
          subtitle: "Audit Logs",
          text: "Security and audit logs are maintained for 1 year for security and compliance purposes."
        }
      ]
    },
    {
      icon: <Bell className="w-6 h-6" />,
      title: "Cookies & Tracking",
      content: [
        {
          subtitle: "Essential Cookies",
          text: "We use essential cookies required for platform functionality, authentication, and security."
        },
        {
          subtitle: "Analytics",
          text: "We use analytics tools to understand user behavior and improve our services. You can opt-out through browser settings."
        },
        {
          subtitle: "Your Control",
          text: "You can manage cookie preferences through your browser settings at any time."
        }
      ]
    },
    {
      icon: <FileText className="w-6 h-6" />,
      title: "Compliance",
      content: [
        {
          subtitle: "GDPR Compliance",
          text: "We comply with the General Data Protection Regulation (GDPR) for European users."
        },
        {
          subtitle: "Indian IT Act",
          text: "We adhere to the Information Technology Act, 2000 and associated data protection rules."
        },
        {
          subtitle: "ISO 27001",
          text: "Our information security management system is ISO 27001 certified."
        }
      ]
    }
  ]

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-8">
      <div className="max-w-5xl mx-auto">
        {/* Header */}
        <div className="mb-12 text-center">
          <div className="inline-block bg-indigo-100 dark:bg-indigo-900/30 rounded-full px-6 py-2 mb-6">
            <span className="text-indigo-600 dark:text-indigo-400 font-semibold">Last Updated: November 5, 2025</span>
          </div>
          <h1 className="text-5xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent mb-4">
            Privacy Policy
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Your privacy is important to us. This policy explains how we collect, use, protect, and handle your personal information.
          </p>
        </div>

        {/* Introduction */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 mb-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Our Commitment to Privacy</h2>
          <p className="text-gray-600 dark:text-gray-400 leading-relaxed mb-4">
            At TruVerify, we are committed to protecting your privacy and ensuring the security of your personal information. 
            This Privacy Policy describes how we collect, use, disclose, and safeguard your information when you use our 
            verification platform and services.
          </p>
          <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
            By using TruVerify's services, you agree to the collection and use of information in accordance with this policy. 
            If you do not agree with our policies and practices, please do not use our services.
          </p>
        </div>

        {/* Detailed Sections */}
        {sections.map((section, index) => (
          <div key={index} className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 mb-8">
            <div className="flex items-start gap-4 mb-6">
              <div className="bg-indigo-100 dark:bg-indigo-900/30 rounded-xl p-3 text-indigo-600 dark:text-indigo-400">
                {section.icon}
              </div>
              <h2 className="text-3xl font-bold text-gray-900 dark:text-white">
                {section.title}
              </h2>
            </div>
            
            <div className="space-y-6">
              {section.content.map((item, idx) => (
                <div key={idx}>
                  <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                    {item.subtitle}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                    {item.text}
                  </p>
                </div>
              ))}
            </div>
          </div>
        ))}

        {/* Contact Section */}
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl shadow-xl p-8 text-white">
          <h2 className="text-3xl font-bold mb-4">Questions About Privacy?</h2>
          <p className="text-xl text-white/90 mb-6">
            If you have any questions or concerns about our Privacy Policy or data practices, please contact our Data Protection Officer.
          </p>
          <div className="space-y-2">
            <p className="flex items-center gap-2">
              <span className="font-semibold">Email:</span> privacy@truverify.com
            </p>
            <p className="flex items-center gap-2">
              <span className="font-semibold">Phone:</span> +91 8279439828
            </p>
            <p className="flex items-center gap-2">
              <span className="font-semibold">Address:</span> Second Floor, Mind Mill Corporate Tower, Sector 16A, Noida, India
            </p>
          </div>
        </div>

        {/* Changes Notice */}
        <div className="mt-8 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-xl p-6">
          <h3 className="text-lg font-bold text-yellow-900 dark:text-yellow-200 mb-2">
            Changes to This Privacy Policy
          </h3>
          <p className="text-yellow-800 dark:text-yellow-300">
            We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new 
            Privacy Policy on this page and updating the "Last Updated" date. You are advised to review this Privacy 
            Policy periodically for any changes.
          </p>
        </div>
      </div>
    </div>
  )
}
