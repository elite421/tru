import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

// GET: Fetch default pricing plan rates
export async function GET(request: NextRequest) {
  try {
    // Get the default pricing plan
    const defaultPlanResult = await query(
      "SELECT id FROM pricing_plans WHERE is_default = true AND is_active = true LIMIT 1"
    );

    if (defaultPlanResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "No default pricing plan found" },
        { status: 404 }
      );
    }

    const defaultPlanId = defaultPlanResult.rows[0].id;

    // Fetch rates for the default plan
    const ratesResult = await query(
      "SELECT verification_type, price FROM pricing_plan_rates WHERE pricing_plan_id = $1 ORDER BY verification_type",
      [defaultPlanId]
    );

    const rates = ratesResult.rows.map(row => ({
      verificationType: row.verification_type,
      price: parseFloat(row.price)
    }));

    return NextResponse.json(
      { success: true, rates, planId: defaultPlanId },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Admin pricing fetch error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to fetch pricing rates" },
      { status: 500 }
    );
  }
}

// POST: Update default pricing plan rates
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { rates } = body;

    if (!rates || !Array.isArray(rates)) {
      return NextResponse.json(
        { success: false, error: "Rates array is required" },
        { status: 400 }
      );
    }

    // Get the default pricing plan
    const defaultPlanResult = await query(
      "SELECT id FROM pricing_plans WHERE is_default = true AND is_active = true LIMIT 1"
    );

    if (defaultPlanResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "No default pricing plan found" },
        { status: 404 }
      );
    }

    const defaultPlanId = defaultPlanResult.rows[0].id;

    // Update each rate
    for (const rate of rates) {
      const { verificationType, price } = rate;
      
      await query(
        `INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price)
         VALUES ($1, $2, $3)
         ON CONFLICT (pricing_plan_id, verification_type)
         DO UPDATE SET price = $3, updated_at = CURRENT_TIMESTAMP`,
        [defaultPlanId, verificationType, price]
      );
    }

    return NextResponse.json(
      { 
        success: true, 
        message: "Default pricing rates updated successfully",
        rates 
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Admin pricing update error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to update pricing rates" },
      { status: 500 }
    );
  }
}
