import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const period = searchParams.get("period") || "30"; // days

    // Get date range
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(period));

    // User Growth
    const userGrowth = await query(
      `SELECT 
        DATE(created_at) as date,
        COUNT(*) as count
       FROM users
       WHERE created_at >= $1
       GROUP BY DATE(created_at)
       ORDER BY date ASC`,
      [startDate]
    );

    // Revenue by Day
    const revenueByDay = await query(
      `SELECT 
        DATE(created_at) as date,
        SUM(amount) as revenue,
        COUNT(*) as transactions
       FROM wallet_transactions
       WHERE transaction_type = 'debit' 
       AND created_at >= $1
       GROUP BY DATE(created_at)
       ORDER BY date ASC`,
      [startDate]
    );

    // Verification Stats
    const verificationStats = await query(
      `SELECT 
        verification_type,
        COUNT(*) as count,
        SUM(cost) as revenue
       FROM verification_requests
       WHERE created_at >= $1
       GROUP BY verification_type
       ORDER BY count DESC
       LIMIT 10`,
      [startDate]
    );

    // Top Users by Spending
    const topUsers = await query(
      `SELECT 
        u.id,
        u.full_name,
        u.email,
        SUM(wt.amount) as total_spent,
        COUNT(wt.id) as transaction_count
       FROM users u
       JOIN wallets w ON u.id = w.user_id
       JOIN wallet_transactions wt ON w.id = wt.wallet_id
       WHERE wt.transaction_type = 'debit'
       AND wt.created_at >= $1
       GROUP BY u.id, u.full_name, u.email
       ORDER BY total_spent DESC
       LIMIT 10`,
      [startDate]
    );

    // Overall Stats
    const overallStats = await query(
      `SELECT 
        (SELECT COUNT(*) FROM users) as total_users,
        (SELECT COUNT(*) FROM users WHERE created_at >= $1) as new_users,
        (SELECT SUM(balance) FROM wallets) as total_wallet_balance,
        (SELECT COUNT(*) FROM verification_requests WHERE created_at >= $1) as total_verifications,
        (SELECT SUM(amount) FROM wallet_transactions WHERE transaction_type = 'debit' AND created_at >= $1) as total_revenue,
        (SELECT SUM(amount) FROM wallet_transactions WHERE transaction_type = 'credit' AND created_at >= $1) as total_credits,
        (SELECT AVG(amount) FROM wallet_transactions WHERE transaction_type = 'debit' AND created_at >= $1) as avg_transaction_value`,
      [startDate]
    );

    return NextResponse.json({
      success: true,
      period: parseInt(period),
      data: {
        userGrowth: userGrowth.rows,
        revenueByDay: revenueByDay.rows,
        verificationStats: verificationStats.rows,
        topUsers: topUsers.rows,
        overall: overallStats.rows[0]
      }
    });
  } catch (error: any) {
    console.error("Analytics error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to fetch analytics" },
      { status: 500 }
    );
  }
}
