import { NextRequest, NextResponse } from "next/server";
import fs from "fs";
import path from "path";

const LOGS_FILE = path.join(process.cwd(), "logs", "system.json");

// Ensure logs directory exists
function ensureLogsDirectory() {
  const logsDir = path.join(process.cwd(), "logs");
  if (!fs.existsSync(logsDir)) {
    fs.mkdirSync(logsDir, { recursive: true });
  }
  if (!fs.existsSync(LOGS_FILE)) {
    fs.writeFileSync(LOGS_FILE, JSON.stringify([], null, 2));
  }
}

export async function GET(request: NextRequest) {
  try {
    ensureLogsDirectory();
    
    const logsData = fs.readFileSync(LOGS_FILE, "utf-8");
    const logs = JSON.parse(logsData);

    // Sort by timestamp descending (newest first)
    const sortedLogs = logs.sort((a: any, b: any) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );

    return NextResponse.json({
      success: true,
      logs: sortedLogs.slice(0, 500), // Return last 500 logs
    });
  } catch (error: any) {
    console.error("Logs fetch error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to fetch logs", logs: [] },
      { status: 500 }
    );
  }
}

export async function POST(request: NextRequest) {
  try {
    ensureLogsDirectory();
    
    const body = await request.json();
    const { level, category, message, details, user_id, ip_address } = body;

    if (!level || !category || !message) {
      return NextResponse.json(
        { success: false, error: "Level, category, and message are required" },
        { status: 400 }
      );
    }

    // Read existing logs
    const logsData = fs.readFileSync(LOGS_FILE, "utf-8");
    const logs = JSON.parse(logsData);

    // Create new log entry
    const newLog = {
      id: `LOG-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date().toISOString(),
      level,
      category,
      message,
      details: details || null,
      user_id: user_id || null,
      ip_address: ip_address || null,
    };

    // Add to logs array
    logs.push(newLog);

    // Keep only last 10000 logs to prevent file from growing too large
    if (logs.length > 10000) {
      logs.splice(0, logs.length - 10000);
    }

    // Write back to file
    fs.writeFileSync(LOGS_FILE, JSON.stringify(logs, null, 2));

    return NextResponse.json({
      success: true,
      log: newLog,
    });
  } catch (error: any) {
    console.error("Log creation error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to create log" },
      { status: 500 }
    );
  }
}
