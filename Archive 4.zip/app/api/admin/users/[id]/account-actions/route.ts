import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";
import bcrypt from "bcryptjs";
import { logger } from "@/lib/logger";

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const userId = params.id;
    const body = await request.json();
    const { action, data } = body;

    // Get admin user info
    const adminUser = request.headers.get("x-admin-user");

    switch (action) {
      case "suspend":
        await query(
          "UPDATE users SET is_active = false, updated_at = CURRENT_TIMESTAMP WHERE id = $1",
          [userId]
        );
        
        await logger.warning(
          "admin_action",
          `User ${userId} suspended by admin`,
          { user_id: userId, admin: adminUser },
          userId
        );

        return NextResponse.json({
          success: true,
          message: "User suspended successfully"
        });

      case "activate":
        await query(
          "UPDATE users SET is_active = true, updated_at = CURRENT_TIMESTAMP WHERE id = $1",
          [userId]
        );
        
        await logger.success(
          "admin_action",
          `User ${userId} activated by admin`,
          { user_id: userId, admin: adminUser },
          userId
        );

        return NextResponse.json({
          success: true,
          message: "User activated successfully"
        });

      case "reset_password":
        const newPassword = data?.password || Math.random().toString(36).slice(-10);
        const hashedPassword = await bcrypt.hash(newPassword, 10);
        
        await query(
          "UPDATE users SET password_hash = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2",
          [hashedPassword, userId]
        );

        await logger.warning(
          "admin_action",
          `Password reset for user ${userId} by admin`,
          { user_id: userId, admin: adminUser },
          userId
        );

        return NextResponse.json({
          success: true,
          message: "Password reset successfully",
          newPassword: newPassword
        });

      case "verify_email":
        await query(
          "UPDATE users SET email_verified = true, updated_at = CURRENT_TIMESTAMP WHERE id = $1",
          [userId]
        );

        await logger.info(
          "admin_action",
          `Email verified for user ${userId} by admin`,
          { user_id: userId, admin: adminUser },
          userId
        );

        return NextResponse.json({
          success: true,
          message: "Email verified successfully"
        });

      case "verify_phone":
        await query(
          "UPDATE users SET phone_verified = true, updated_at = CURRENT_TIMESTAMP WHERE id = $1",
          [userId]
        );

        await logger.info(
          "admin_action",
          `Phone verified for user ${userId} by admin`,
          { user_id: userId, admin: adminUser },
          userId
        );

        return NextResponse.json({
          success: true,
          message: "Phone verified successfully"
        });

      default:
        return NextResponse.json(
          { success: false, error: "Invalid action" },
          { status: 400 }
        );
    }
  } catch (error: any) {
    console.error("Account action error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Action failed" },
      { status: 500 }
    );
  }
}
