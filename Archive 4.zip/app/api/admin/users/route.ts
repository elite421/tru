import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

export async function GET(request: NextRequest) {
  try {
    // Fetch users with their pricing plans and wallet information
    const usersResult = await query(
      `SELECT 
        u.id, 
        u.email, 
        u.phone, 
        u.full_name,
        u.company_name,
        u.created_at,
        u.updated_at,
        u.last_login,
        u.email_verified,
        u.phone_verified,
        u.pricing_plan_id,
        u.plan_expires_at,
        pp.name as plan_name,
        COALESCE(w.balance, 0) as wallet_balance,
        COALESCE(vr_stats.total_verifications, 0) as total_verifications,
        COALESCE(vr_stats.successful_verifications, 0) as successful_verifications,
        COALESCE(wt_stats.total_credits, 0) as total_credits,
        COALESCE(wt_stats.total_debits, 0) as total_debits
       FROM users u
       LEFT JOIN pricing_plans pp ON u.pricing_plan_id = pp.id
       LEFT JOIN wallets w ON u.id = w.user_id
       LEFT JOIN (
         SELECT user_id, 
                COUNT(*) as total_verifications,
                COUNT(CASE WHEN status = 'success' THEN 1 END) as successful_verifications
         FROM verification_requests
         GROUP BY user_id
       ) vr_stats ON u.id = vr_stats.user_id
       LEFT JOIN (
         SELECT wt.wallet_id,
                SUM(CASE WHEN wt.transaction_type = 'credit' THEN wt.amount ELSE 0 END) as total_credits,
                SUM(CASE WHEN wt.transaction_type = 'debit' THEN wt.amount ELSE 0 END) as total_debits
         FROM wallet_transactions wt
         GROUP BY wt.wallet_id
       ) wt_stats ON w.id = wt_stats.wallet_id
       ORDER BY u.created_at DESC`
    );

    const users = usersResult.rows.map((row) => ({
      id: row.id,
      email: row.email,
      phone: row.phone,
      full_name: row.full_name,
      company_name: row.company_name,
      created_at: row.created_at,
      updated_at: row.updated_at,
      last_login: row.last_login,
      email_verified: row.email_verified,
      phone_verified: row.phone_verified,
      pricing_plan_id: row.pricing_plan_id,
      plan_expires_at: row.plan_expires_at,
      plan_name: row.plan_name,
      wallet_balance: parseFloat(row.wallet_balance) || 0,
      total_verifications: parseInt(row.total_verifications) || 0,
      successful_verifications: parseInt(row.successful_verifications) || 0,
      total_credits: parseFloat(row.total_credits) || 0,
      total_debits: parseFloat(row.total_debits) || 0,
    }));

    return NextResponse.json(
      { success: true, users },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Admin users fetch error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to fetch users" },
      { status: 500 }
    );
  }
}
