import { NextRequest, NextResponse } from "next/server";
import { deepvueService } from "@/lib/deepvue";
import { query } from "@/db/db";
import { calculateGST, extractDeepVueTransactionId } from "@/lib/gstCalculation";
import { getUserVerificationPrice } from "@/lib/pricing";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, voterid, document1, document2, name } = body;

    if (!userId || !voterid) {
      return NextResponse.json(
        { success: false, error: "User ID and Voter ID are required" },
        { status: 400 }
      );
    }

    // Get user-specific or default pricing from database
    const basePrice = await getUserVerificationPrice(userId, "voter-id");
    if (basePrice === null) {
      return NextResponse.json(
        { success: false, error: "Pricing not available for this verification type" },
        { status: 500 }
      );
    }

    // Calculate GST (18%)
    const gstBreakdown = calculateGST(basePrice);

    // Check wallet balance
    const walletResult = await query(
      `SELECT * FROM wallets WHERE user_id = $1`,
      [userId]
    );

    if (walletResult.rows.length === 0 || parseFloat(walletResult.rows[0].balance) < gstBreakdown.totalAmount) {
      return NextResponse.json(
        { success: false, error: `Insufficient wallet balance. Required: ₹${gstBreakdown.totalAmount} (Base: ₹${gstBreakdown.baseAmount} + GST: ₹${gstBreakdown.gstAmount})` },
        { status: 400 }
      );
    }

    // If documents provided, use OCR extraction
    let deepvueResponse;
    if (document1 && name) {
      deepvueResponse = await deepvueService.extractVoterID(document1, document2 || "", name);
    } else {
      // Fallback to mock data if OCR not used
      deepvueResponse = {
        success: true,
        data: {
          epic_number: voterid,
          name: "Mock User",
          status: "verified"
        }
      };
    }

    // Extract DeepVue transaction ID
    const deepvueTransactionId = extractDeepVueTransactionId(deepvueResponse);

    const wallet = walletResult.rows[0];
    const currentBalance = parseFloat(wallet.balance);
    const newBalance = currentBalance - gstBreakdown.totalAmount;

    // Update wallet balance
    await query(
      `UPDATE wallets SET balance = $1 WHERE id = $2`,
      [newBalance, wallet.id]
    );

    // Record wallet transaction with GST breakdown
    await query(
      `INSERT INTO wallet_transactions 
       (wallet_id, user_id, transaction_type, amount, base_amount, gst_amount, gst_percentage, deepvue_transaction_id, balance_before, balance_after, description, reference_type, status) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)`,
      [
        wallet.id,
        userId,
        "debit",
        gstBreakdown.totalAmount,
        gstBreakdown.baseAmount,
        gstBreakdown.gstAmount,
        gstBreakdown.gstPercentage,
        deepvueTransactionId,
        currentBalance,
        newBalance,
        `Voter ID verification - Base: ₹${gstBreakdown.baseAmount}, GST (18%): ₹${gstBreakdown.gstAmount}`,
        "verification",
        "completed"
      ]
    );

    // Save verification record
    await query(
      `INSERT INTO verification_requests 
       (user_id, verification_type, document_number, status, cost, verification_data) 
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [
        userId,
        "voter-id",
        voterid,
        deepvueResponse.success ? "success" : "failed",
        gstBreakdown.totalAmount,
        JSON.stringify(deepvueResponse),
      ]
    );

    // Save to transactions table with GST breakdown
    await query(
      `INSERT INTO transactions 
       (user_id, verification_type, amount, base_amount, gst_amount, gst_percentage, deepvue_transaction_id, status, cache_hit, details) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
      [
        userId,
        "voter-id",
        gstBreakdown.totalAmount,
        gstBreakdown.baseAmount,
        gstBreakdown.gstAmount,
        gstBreakdown.gstPercentage,
        deepvueTransactionId,
        "success",
        false,
        JSON.stringify(deepvueResponse)
      ]
    );

    return NextResponse.json(
      {
        success: true,
        data: deepvueResponse,
        deepvueTransactionId,
        wallet: {
          baseAmount: gstBreakdown.baseAmount,
          gstAmount: gstBreakdown.gstAmount,
          gstPercentage: gstBreakdown.gstPercentage,
          totalAmount: gstBreakdown.totalAmount,
          amountDeducted: gstBreakdown.totalAmount,
          newBalance,
        },
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Voter ID verification error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Voter ID verification failed" },
      { status: 500 }
    );
  }
}
