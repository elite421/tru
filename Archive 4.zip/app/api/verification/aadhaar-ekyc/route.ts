import { NextRequest, NextResponse } from "next/server";
import { deepvueService } from "@/lib/deepvue";
import { query } from "@/db/db";
import { calculateGST, extractDeepVueTransactionId } from "@/lib/gstCalculation";
import { getUserVerificationPrice } from "@/lib/pricing";

// Two-step Aadhaar eKYC: Generate OTP -> Verify OTP (with wallet deduction)
export async function POST(request: NextRequest) {
  const startTime = Date.now();
  
  try {
    const body = await request.json();
    const { userId, step, aadhaarNumber, otp, referenceId, consent = "Y", purpose = "For KYC" } = body;

    if (!userId) {
      return NextResponse.json(
        { success: false, error: "User ID is required" },
        { status: 400 }
      );
    }

    // Step 1: Generate OTP (Free - no wallet deduction)
    if (step === "generate-otp") {
      if (!aadhaarNumber) {
        return NextResponse.json(
          { success: false, error: "Aadhaar number is required" },
          { status: 400 }
        );
      }

      // Validate Aadhaar format (12 digits)
      const aadhaarRegex = /^[0-9]{12}$/;
      if (!aadhaarRegex.test(aadhaarNumber)) {
        return NextResponse.json(
          { success: false, error: "Invalid Aadhaar format. Must be 12 digits" },
          { status: 400 }
        );
      }

      // Call Deepvue API to generate OTP
      const result = await deepvueService.generateAadhaarOTP(aadhaarNumber, consent, purpose);

      return NextResponse.json({
        success: true,
        data: result,
        message: "OTP sent to registered mobile number",
      });
    } 
    
    // Step 2: Verify OTP (Chargeable - deduct from wallet)
    else if (step === "verify-otp") {
      if (!otp || !referenceId) {
        return NextResponse.json(
          { success: false, error: "OTP and reference ID are required" },
          { status: 400 }
        );
      }

      // Get user-specific or default pricing from database
      const basePrice = await getUserVerificationPrice(userId, "aadhaar-ekyc");
      if (basePrice === null) {
        return NextResponse.json(
          { success: false, error: "Pricing not available for this verification type" },
          { status: 500 }
        );
      }

      const gstBreakdown = calculateGST(basePrice);
      const walletResult = await query("SELECT * FROM wallets WHERE user_id = $1", [userId]);

      if (walletResult.rows.length === 0 || parseFloat(walletResult.rows[0].balance) < gstBreakdown.totalAmount) {
        return NextResponse.json(
          { success: false, error: `Insufficient wallet balance. Required: ₹${gstBreakdown.totalAmount} (Base: ₹${gstBreakdown.baseAmount} + GST: ₹${gstBreakdown.gstAmount})` },
          { status: 400 }
        );
      }

      // Call Deepvue API to verify OTP and complete eKYC
      const deepvueResponse = await deepvueService.verifyAadhaarOTP(otp, referenceId, consent, purpose);
      const responseTime = Date.now() - startTime;
      const deepvueTransactionId = extractDeepVueTransactionId(deepvueResponse);

      const wallet = walletResult.rows[0];
      const currentBalance = parseFloat(wallet.balance);
      const newBalance = currentBalance - gstBreakdown.totalAmount;

      // Update wallet balance
      await query("UPDATE wallets SET balance = $1 WHERE id = $2", [newBalance, wallet.id]);
      
      // Log wallet transaction
      await query(
        `INSERT INTO wallet_transactions (wallet_id, user_id, transaction_type, amount, base_amount, gst_amount, gst_percentage, deepvue_transaction_id, response_time, balance_before, balance_after, description, reference_type, status) 
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)`,
        [wallet.id, userId, "debit", gstBreakdown.totalAmount, gstBreakdown.baseAmount, gstBreakdown.gstAmount, gstBreakdown.gstPercentage, deepvueTransactionId, responseTime, currentBalance, newBalance, "Aadhaar eKYC verification", "verification", "completed"]
      );
      
      // Log verification request
      await query(
        `INSERT INTO verification_requests (user_id, verification_type, document_number, status, cost, verification_data) 
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [userId, "aadhaar-ekyc", referenceId, deepvueResponse.success ? "success" : "failed", gstBreakdown.totalAmount, JSON.stringify(deepvueResponse)]
      );

      // Log transaction
      await query(
        `INSERT INTO transactions (user_id, verification_type, amount, base_amount, gst_amount, gst_percentage, deepvue_transaction_id, response_time, status, cache_hit, details) 
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
        [userId, "aadhaar-ekyc", gstBreakdown.totalAmount, gstBreakdown.baseAmount, gstBreakdown.gstAmount, gstBreakdown.gstPercentage, deepvueTransactionId, responseTime, "success", false, JSON.stringify(deepvueResponse)]
      );

      return NextResponse.json({
        success: true,
        data: deepvueResponse,
        deepvueTransactionId,
        responseTime,
        message: "Aadhaar eKYC completed successfully",
        wallet: { 
          baseAmount: gstBreakdown.baseAmount, 
          gstAmount: gstBreakdown.gstAmount, 
          gstPercentage: gstBreakdown.gstPercentage, 
          totalAmount: gstBreakdown.totalAmount, 
          amountDeducted: gstBreakdown.totalAmount, 
          newBalance 
        },
      });
    } 
    
    else {
      return NextResponse.json(
        { success: false, error: "Invalid step. Use 'generate-otp' or 'verify-otp'" },
        { status: 400 }
      );
    }
  } catch (error: any) {
    const responseTime = Date.now() - startTime;
    console.error("Aadhaar eKYC error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to process Aadhaar eKYC", responseTime },
      { status: 500 }
    );
  }
}
