"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { 
  CreditCard,
  Search,
  Download,
  RefreshCw,
  TrendingUp,
  TrendingDown,
  DollarSign,
  CheckCircle,
  XCircle,
  Clock,
  Eye,
  ArrowUpCircle,
  ArrowDownCircle,
  Receipt,
  Info
} from "lucide-react"
import { Button } from "@/component/ui/button"

type Transaction = {
  id: number
  user_id: string
  user_email: string
  user_name: string
  transaction_type: "credit" | "debit"
  amount: number
  base_amount?: number
  gst_amount?: number
  gst_percentage?: number
  deepvue_transaction_id?: string
  response_time?: number
  balance_before: number
  balance_after: number
  description: string
  reference_type: string
  status: string
  created_at: string
}

export default function AdminTransactionsPage() {
  const router = useRouter()
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [filterType, setFilterType] = useState<string>("all")
  const [stats, setStats] = useState({
    totalTransactions: 0,
    totalCredits: 0,
    totalDebits: 0,
    totalBaseAmount: 0,
    totalGSTAmount: 0,
    avgResponseTime: 0,
    avgTransactionAmount: 0
  })
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null)

  useEffect(() => {
    checkAuth()
    fetchTransactions()
  }, [])

  const checkAuth = () => {
    const adminUser = sessionStorage.getItem("admin_user")
    if (!adminUser) {
      router.push("/admin/login")
    }
  }

  const fetchTransactions = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/admin/transactions")
      
      if (response.ok) {
        const data = await response.json()
        setTransactions(data.transactions || [])
        setStats(data.stats || {
          totalTransactions: 0,
          totalCredits: 0,
          totalDebits: 0,
          totalBaseAmount: 0,
          totalGSTAmount: 0,
          avgResponseTime: 0,
          avgTransactionAmount: 0
        })
      }
    } catch (error) {
      console.error("Error fetching transactions:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleExport = () => {
    const csv = [
      ["ID", "DeepVue ID", "User", "Type", "Base Amount", "GST Amount", "Total Amount", "Response Time", "Balance Before", "Balance After", "Description", "Status", "Date"],
      ...filteredTransactions.map(t => [
        t.id,
        t.deepvue_transaction_id || "N/A",
        t.user_email,
        t.transaction_type,
        t.base_amount || "N/A",
        t.gst_amount || "N/A",
        t.amount,
        t.response_time || "N/A",
        t.balance_before,
        t.balance_after,
        t.description,
        t.status,
        new Date(t.created_at).toLocaleString()
      ])
    ].map(row => row.join(",")).join("\n")

    const blob = new Blob([csv], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `transactions-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
  }

  const filteredTransactions = transactions.filter(transaction => {
    const matchesSearch = 
      transaction.user_email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.user_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.deepvue_transaction_id?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      transaction.id?.toString().includes(searchTerm)
    
    const matchesType = filterType === "all" || transaction.transaction_type === filterType
    
    return matchesSearch && matchesType
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        <div className="p-4 md:p-8">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h1 className="text-4xl font-bold text-white mb-2">
                  Transaction Monitor
                </h1>
                <p className="text-gray-400">
                  View all wallet transactions with GST breakdown
                </p>
              </div>
              <div className="flex gap-3">
                <Button
                  onClick={handleExport}
                  className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg flex items-center gap-2"
                >
                  <Download className="w-4 h-4" />
                  Export
                </Button>
                <Button
                  onClick={fetchTransactions}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2"
                >
                  <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                  Refresh
                </Button>
              </div>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <div className="bg-white/5 border border-white/10 rounded-xl p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Total Transactions</p>
                  <p className="text-2xl font-bold text-white">{stats.totalTransactions}</p>
                </div>
                <CreditCard className="w-8 h-8 text-blue-400" />
              </div>
            </div>
            
            <div className="bg-white/5 border border-white/10 rounded-xl p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Total Credits</p>
                  <p className="text-2xl font-bold text-green-400">₹{stats.totalCredits.toLocaleString()}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-green-400" />
              </div>
            </div>
            
            <div className="bg-white/5 border border-white/10 rounded-xl p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Total Debits</p>
                  <p className="text-2xl font-bold text-red-400">₹{stats.totalDebits.toLocaleString()}</p>
                  {stats.totalGSTAmount > 0 && (
                    <p className="text-xs text-gray-500 mt-1">
                      GST: ₹{stats.totalGSTAmount.toFixed(2)}
                    </p>
                  )}
                </div>
                <TrendingDown className="w-8 h-8 text-red-400" />
              </div>
            </div>
            
            <div className="bg-white/5 border border-white/10 rounded-xl p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Avg Response Time</p>
                  <p className="text-2xl font-bold text-white">{stats.avgResponseTime.toFixed(2)} ms</p>
                </div>
                <Clock className="w-8 h-8 text-purple-400" />
              </div>
            </div>
            
            <div className="bg-white/5 border border-white/10 rounded-xl p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-400">Avg Transaction</p>
                  <p className="text-2xl font-bold text-white">₹{stats.avgTransactionAmount.toFixed(2)}</p>
                </div>
                <DollarSign className="w-8 h-8 text-purple-400" />
              </div>
            </div>
          </div>

          {/* Filters */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-4 mb-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search by user, transaction ID, or DeepVue ID..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-400"
                />
              </div>
              
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
              >
                <option value="all">All Types</option>
                <option value="credit">Credit</option>
                <option value="debit">Debit</option>
              </select>
            </div>
          </div>

          {/* Transactions Table */}
          <div className="bg-white/5 border border-white/10 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-white/10">
                  <tr>
                    <th className="p-4 text-left text-sm font-semibold text-gray-300">Transaction ID</th>
                    <th className="p-4 text-left text-sm font-semibold text-gray-300">User</th>
                    <th className="p-4 text-left text-sm font-semibold text-gray-300">Type</th>
                    <th className="p-4 text-left text-sm font-semibold text-gray-300">Amount</th>
                    <th className="p-4 text-left text-sm font-semibold text-gray-300">Response Time</th>
                    <th className="p-4 text-left text-sm font-semibold text-gray-300">Balance Change</th>
                    <th className="p-4 text-left text-sm font-semibold text-gray-300">Description</th>
                    <th className="p-4 text-left text-sm font-semibold text-gray-300">Date</th>
                    <th className="p-4 text-left text-sm font-semibold text-gray-300">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan={9} className="p-8 text-center">
                        <RefreshCw className="w-8 h-8 animate-spin text-white mx-auto mb-2" />
                        <p className="text-gray-400">Loading transactions...</p>
                      </td>
                    </tr>
                  ) : filteredTransactions.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="p-8 text-center text-gray-400">
                        No transactions found
                      </td>
                    </tr>
                  ) : (
                    filteredTransactions.map((transaction) => (
                      <tr key={transaction.id} className="border-t border-white/10 hover:bg-white/5 transition-colors">
                        <td className="p-4">
                          <div>
                            <p className="font-mono text-white">#{transaction.id}</p>
                            {transaction.deepvue_transaction_id && (
                              <p className="text-xs text-orange-400 font-mono mt-1">
                                DV: {transaction.deepvue_transaction_id.substring(0, 12)}...
                              </p>
                            )}
                          </div>
                        </td>
                        <td className="p-4">
                          <div>
                            <p className="font-semibold text-white">{transaction.user_name || 'Unknown'}</p>
                            <p className="text-sm text-gray-400">{transaction.user_email}</p>
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            {transaction.transaction_type === 'credit' ? (
                              <ArrowUpCircle className="w-5 h-5 text-green-400" />
                            ) : (
                              <ArrowDownCircle className="w-5 h-5 text-red-400" />
                            )}
                            <span className={`capitalize ${
                              transaction.transaction_type === 'credit' ? 'text-green-400' : 'text-red-400'
                            }`}>
                              {transaction.transaction_type}
                            </span>
                          </div>
                        </td>
                        <td className="p-4">
                          <div>
                            <span className={`font-semibold ${
                              transaction.transaction_type === 'credit' ? 'text-green-400' : 'text-red-400'
                            }`}>
                              {transaction.transaction_type === 'credit' ? '+' : '-'}₹{transaction.amount}
                            </span>
                            {transaction.base_amount && transaction.gst_amount && (
                              <div className="text-xs text-gray-500 mt-1">
                                <p>Base: ₹{transaction.base_amount}</p>
                                <p>GST: ₹{transaction.gst_amount}</p>
                              </div>
                            )}
                          </div>
                        </td>
                        <td className="p-4">
                          <p className="text-sm text-white">{transaction.response_time || "N/A"} ms</p>
                        </td>
                        <td className="p-4">
                          <div className="text-sm">
                            <p className="text-gray-400">₹{transaction.balance_before} → ₹{transaction.balance_after}</p>
                          </div>
                        </td>
                        <td className="p-4">
                          <p className="text-sm text-white">{transaction.description}</p>
                          <p className="text-xs text-gray-500 capitalize">{transaction.reference_type}</p>
                        </td>
                        <td className="p-4">
                          <p className="text-sm text-white">
                            {new Date(transaction.created_at).toLocaleDateString()}
                          </p>
                          <p className="text-xs text-gray-400">
                            {new Date(transaction.created_at).toLocaleTimeString()}
                          </p>
                        </td>
                        <td className="p-4">
                          <button
                            onClick={() => setSelectedTransaction(transaction)}
                            className="p-2 bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 rounded-lg transition-colors"
                          >
                            <Eye className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Transaction Detail Modal */}
      {selectedTransaction && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-800 rounded-2xl shadow-2xl max-w-2xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-white flex items-center gap-2">
                <Receipt className="w-6 h-6" />
                Transaction Details
              </h3>
              <button
                onClick={() => setSelectedTransaction(null)}
                className="text-gray-400 hover:text-gray-200"
              >
                <XCircle className="w-6 h-6" />
              </button>
            </div>
            
            <div className="space-y-4">
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-sm text-gray-400 mb-1">Internal Transaction ID</p>
                <p className="text-white font-mono text-lg">#{selectedTransaction.id}</p>
              </div>

              {selectedTransaction.deepvue_transaction_id && (
                <div className="bg-orange-500/10 border border-orange-500/30 rounded-lg p-4">
                  <p className="text-sm text-gray-400 mb-1">DeepVue Transaction ID</p>
                  <p className="text-orange-400 font-mono text-sm break-all">
                    {selectedTransaction.deepvue_transaction_id}
                  </p>
                </div>
              )}
              
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-sm text-gray-400 mb-1">User</p>
                <p className="text-white">{selectedTransaction.user_name}</p>
                <p className="text-sm text-gray-400">{selectedTransaction.user_email}</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/5 rounded-lg p-4">
                  <p className="text-sm text-gray-400 mb-1">Type</p>
                  <p className={`font-semibold capitalize ${
                    selectedTransaction.transaction_type === 'credit' ? 'text-green-400' : 'text-red-400'
                  }`}>
                    {selectedTransaction.transaction_type}
                  </p>
                </div>
                
                <div className="bg-white/5 rounded-lg p-4">
                  <p className="text-sm text-gray-400 mb-1">Status</p>
                  <p className="text-white font-bold capitalize">{selectedTransaction.status}</p>
                </div>
              </div>

              {/* GST Breakdown */}
              {selectedTransaction.base_amount && selectedTransaction.gst_amount ? (
                <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
                  <h4 className="text-sm font-semibold text-gray-300 mb-3 flex items-center gap-2">
                    <Info className="w-4 h-4" />
                    Amount Breakdown (with GST)
                  </h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-400">Base Amount:</span>
                      <span className="text-white font-semibold">₹{selectedTransaction.base_amount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">GST ({selectedTransaction.gst_percentage || 18}%):</span>
                      <span className="text-white font-semibold">₹{selectedTransaction.gst_amount}</span>
                    </div>
                    <div className="border-t border-blue-500/30 pt-2 mt-2">
                      <div className="flex justify-between">
                        <span className="text-white font-bold">Total Amount:</span>
                        <span className="text-white font-bold text-lg">₹{selectedTransaction.amount}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-white/5 rounded-lg p-4">
                  <p className="text-sm text-gray-400 mb-1">Amount</p>
                  <p className="text-white font-bold text-xl">₹{selectedTransaction.amount}</p>
                </div>
              )}
              
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-sm text-gray-400 mb-1">Response Time</p>
                <p className="text-white font-bold text-lg">{selectedTransaction.response_time || "N/A"} ms</p>
              </div>
              
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-sm text-gray-400 mb-1">Description</p>
                <p className="text-white">{selectedTransaction.description}</p>
              </div>
              
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-sm text-gray-400 mb-2">Balance Changes</p>
                <div className="flex items-center gap-2">
                  <span className="text-white">₹{selectedTransaction.balance_before}</span>
                  <span className="text-gray-400">→</span>
                  <span className="text-white font-bold">₹{selectedTransaction.balance_after}</span>
                </div>
              </div>
              
              <div className="bg-white/5 rounded-lg p-4">
                <p className="text-sm text-gray-400 mb-1">Date & Time</p>
                <p className="text-white">
                  {new Date(selectedTransaction.created_at).toLocaleString()}
                </p>
              </div>
            </div>
            
            <div className="mt-6">
              <Button
                onClick={() => setSelectedTransaction(null)}
                className="w-full bg-gray-600 hover:bg-gray-700 text-white py-2 rounded-lg"
              >
                Close
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
