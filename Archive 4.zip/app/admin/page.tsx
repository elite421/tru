"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { 
  Users, 
  CreditCard, 
  Shield, 
  Activity,
  DollarSign,
  TrendingUp,
  Key,
  CheckCircle,
  XCircle,
  RefreshCw,
  ArrowRight,
  Calendar
} from "lucide-react"
import { Button } from "@/component/ui/button"

type Stats = {
  totalUsers: number
  totalRevenue: number
  totalTransactions: number
  totalVerifications: number
  successfulVerifications: number
  failedVerifications: number
  activeApiKeys: number
}

type RecentActivity = {
  id: number
  user_email: string
  verification_type: string
  status: string
  cost: number
  created_at: string
}

export default function AdminDashboard() {
  const router = useRouter()
  const [stats, setStats] = useState<Stats>({
    totalUsers: 0,
    totalRevenue: 0,
    totalTransactions: 0,
    totalVerifications: 0,
    successfulVerifications: 0,
    failedVerifications: 0,
    activeApiKeys: 0
  })
  const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    checkAuth()
    fetchDashboardData()
  }, [])

  const checkAuth = () => {
    const adminUser = sessionStorage.getItem("admin_user")
    if (!adminUser) {
      router.push("/admin/login")
    }
  }

  const fetchDashboardData = async () => {
    try {
      setLoading(true)
      
      // Fetch real data from API endpoints
      const [usersRes, transactionsRes, verificationsRes] = await Promise.all([
        fetch("/api/admin/users"),
        fetch("/api/admin/transactions"),
        fetch("/api/admin/verifications")
      ])

      const usersData = await usersRes.json()
      const transactionsData = await transactionsRes.json()
      const verificationsData = await verificationsRes.json()

      // Calculate statistics from real data
      setStats({
        totalUsers: usersData.users?.length || 0,
        totalRevenue: transactionsData.stats?.totalDebits || 0,
        totalTransactions: transactionsData.stats?.totalTransactions || 0,
        totalVerifications: verificationsData.stats?.totalVerifications || 0,
        successfulVerifications: verificationsData.stats?.successful || 0,
        failedVerifications: verificationsData.stats?.failed || 0,
        activeApiKeys: 0 // Will be updated when API keys endpoint is ready
      })

      // Get recent verifications for activity
      if (verificationsData.verifications) {
        setRecentActivity(verificationsData.verifications.slice(0, 10))
      }

    } catch (error) {
      console.error("Error fetching dashboard data:", error)
    } finally {
      setLoading(false)
    }
  }

  const successRate = stats.totalVerifications > 0 
    ? ((stats.successfulVerifications / stats.totalVerifications) * 100).toFixed(1)
    : 0

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">
                Admin Dashboard
              </h1>
              <p className="text-gray-400">
                Monitor and manage your verification platform
              </p>
            </div>
            <Button
              onClick={fetchDashboardData}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {/* Total Users */}
          <div className="bg-gradient-to-br from-blue-500/10 to-blue-600/10 border border-blue-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-blue-600 rounded-lg">
                <Users className="w-6 h-6 text-white" />
              </div>
            </div>
            <h3 className="text-gray-400 text-sm font-medium mb-1">Total Users</h3>
            <p className="text-3xl font-bold text-white">{stats.totalUsers}</p>
          </div>

          {/* Total Revenue */}
          <div className="bg-gradient-to-br from-green-500/10 to-green-600/10 border border-green-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-green-600 rounded-lg">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
            </div>
            <h3 className="text-gray-400 text-sm font-medium mb-1">Total Revenue</h3>
            <p className="text-3xl font-bold text-white">₹{stats.totalRevenue.toLocaleString()}</p>
          </div>

          {/* Total Verifications */}
          <div className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border border-purple-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-purple-600 rounded-lg">
                <Shield className="w-6 h-6 text-white" />
              </div>
            </div>
            <h3 className="text-gray-400 text-sm font-medium mb-1">Verifications</h3>
            <p className="text-3xl font-bold text-white">{stats.totalVerifications}</p>
            <p className="text-sm text-green-400 mt-2">{successRate}% success rate</p>
          </div>

          {/* Total Transactions */}
          <div className="bg-gradient-to-br from-orange-500/10 to-orange-600/10 border border-orange-500/20 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="p-3 bg-orange-600 rounded-lg">
                <Activity className="w-6 h-6 text-white" />
              </div>
            </div>
            <h3 className="text-gray-400 text-sm font-medium mb-1">Transactions</h3>
            <p className="text-3xl font-bold text-white">{stats.totalTransactions}</p>
          </div>
        </div>

        {/* Two Column Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Recent Activity - Takes 2 columns */}
          <div className="lg:col-span-2 bg-white/5 border border-white/10 rounded-xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-white">Recent Verifications</h2>
              <Button
                onClick={() => router.push("/admin/transactions")}
                className="text-blue-400 hover:text-blue-300 flex items-center gap-2"
              >
                View All
                <ArrowRight className="w-4 h-4" />
              </Button>
            </div>

            {loading ? (
              <div className="flex items-center justify-center py-12">
                <RefreshCw className="w-8 h-8 animate-spin text-gray-400" />
              </div>
            ) : recentActivity.length === 0 ? (
              <div className="text-center py-12 text-gray-400">
                No recent activity
              </div>
            ) : (
              <div className="space-y-3">
                {recentActivity.map((activity) => (
                  <div 
                    key={activity.id} 
                    className="bg-white/5 border border-white/10 rounded-lg p-4 hover:bg-white/10 transition-colors"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          {activity.status === 'success' ? (
                            <CheckCircle className="w-5 h-5 text-green-400" />
                          ) : (
                            <XCircle className="w-5 h-5 text-red-400" />
                          )}
                          <span className="font-semibold text-white capitalize">
                            {activity.verification_type.replace(/_/g, ' ')}
                          </span>
                        </div>
                        <p className="text-sm text-gray-400">{activity.user_email}</p>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-white">₹{activity.cost}</p>
                        <p className="text-xs text-gray-400">
                          {new Date(activity.created_at).toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Quick Actions - Takes 1 column */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-6">
            <h2 className="text-xl font-bold text-white mb-6">Quick Actions</h2>
            
            <div className="space-y-3">
              <button
                onClick={() => router.push("/admin/users")}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white rounded-lg p-4 flex items-center gap-3 transition-colors"
              >
                <Users className="w-5 h-5" />
                <span className="font-semibold">Manage Users</span>
              </button>

              <button
                onClick={() => router.push("/admin/transactions")}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white rounded-lg p-4 flex items-center gap-3 transition-colors"
              >
                <CreditCard className="w-5 h-5" />
                <span className="font-semibold">View Transactions</span>
              </button>

              <button
                onClick={() => router.push("/admin/api-keys")}
                className="w-full bg-green-600 hover:bg-green-700 text-white rounded-lg p-4 flex items-center gap-3 transition-colors"
              >
                <Key className="w-5 h-5" />
                <span className="font-semibold">API Keys</span>
              </button>

              <button
                onClick={() => router.push("/admin-pricing")}
                className="w-full bg-orange-600 hover:bg-orange-700 text-white rounded-lg p-4 flex items-center gap-3 transition-colors"
              >
                <DollarSign className="w-5 h-5" />
                <span className="font-semibold">Pricing Plans</span>
              </button>
            </div>

            {/* System Status */}
            <div className="mt-6 pt-6 border-t border-white/10">
              <h3 className="text-sm font-semibold text-gray-400 mb-3">System Status</h3>
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">API Status</span>
                  <span className="flex items-center gap-2 text-green-400 text-sm">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                    Online
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Database</span>
                  <span className="flex items-center gap-2 text-green-400 text-sm">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                    Connected
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-400">Cache</span>
                  <span className="flex items-center gap-2 text-green-400 text-sm">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                    Active
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
