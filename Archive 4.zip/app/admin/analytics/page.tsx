"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { 
  TrendingUp, 
  Users, 
  DollarSign, 
  Activity,
  Calendar,
  RefreshCw,
  ArrowUp,
  ArrowDown
} from "lucide-react"
import { Button } from "@/component/ui/button"

type AnalyticsData = {
  userGrowth: Array<{ date: string; count: number }>
  revenueByDay: Array<{ date: string; revenue: number; transactions: number }>
  verificationStats: Array<{ verification_type: string; count: number; revenue: number }>
  topUsers: Array<{ id: number; full_name: string; email: string; total_spent: number; transaction_count: number }>
  overall: {
    total_users: number
    new_users: number
    total_wallet_balance: number
    total_verifications: number
    total_revenue: number
    total_credits: number
    avg_transaction_value: number
  }
}

export default function AdminAnalyticsPage() {
  const router = useRouter()
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null)
  const [loading, setLoading] = useState(true)
  const [period, setPeriod] = useState(30)

  useEffect(() => {
    checkAuth()
    fetchAnalytics()
  }, [period])

  const checkAuth = () => {
    const adminUser = sessionStorage.getItem("admin_user")
    if (!adminUser) {
      router.push("/admin/login")
    }
  }

  const fetchAnalytics = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/admin/analytics?period=${period}`)
      if (response.ok) {
        const result = await response.json()
        setAnalytics(result.data)
      }
    } catch (error) {
      console.error("Error fetching analytics:", error)
    } finally {
      setLoading(false)
    }
  }

  if (loading || !analytics) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center">
        <RefreshCw className="w-8 h-8 animate-spin text-white" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">Analytics Dashboard</h1>
              <p className="text-gray-400">Business insights and performance metrics</p>
            </div>
            <div className="flex gap-3">
              <select
                value={period}
                onChange={(e) => setPeriod(Number(e.target.value))}
                className="px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
              >
                <option value={7}>Last 7 Days</option>
                <option value={30}>Last 30 Days</option>
                <option value={90}>Last 90 Days</option>
                <option value={365}>Last Year</option>
              </select>
              <Button
                onClick={fetchAnalytics}
                className="bg-blue-600 hover:bg-blue-700 text-white"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
            </div>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-gradient-to-br from-blue-500/20 to-blue-600/20 border border-blue-500/30 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <Users className="w-8 h-8 text-blue-400" />
              <span className="flex items-center gap-1 text-green-400 text-sm">
                <ArrowUp className="w-4 h-4" />
                {analytics.overall.new_users}
              </span>
            </div>
            <p className="text-gray-400 text-sm mb-1">Total Users</p>
            <p className="text-3xl font-bold text-white">{analytics.overall.total_users}</p>
            <p className="text-xs text-gray-500 mt-2">{analytics.overall.new_users} new in {period} days</p>
          </div>

          <div className="bg-gradient-to-br from-green-500/20 to-green-600/20 border border-green-500/30 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <DollarSign className="w-8 h-8 text-green-400" />
              <span className="text-green-400 text-sm">Revenue</span>
            </div>
            <p className="text-gray-400 text-sm mb-1">Total Revenue</p>
            <p className="text-3xl font-bold text-white">₹{Number(analytics.overall.total_revenue || 0).toFixed(2)}</p>
            <p className="text-xs text-gray-500 mt-2">Avg: ₹{Number(analytics.overall.avg_transaction_value || 0).toFixed(2)}/txn</p>
          </div>

          <div className="bg-gradient-to-br from-purple-500/20 to-purple-600/20 border border-purple-500/30 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <Activity className="w-8 h-8 text-purple-400" />
              <span className="text-purple-400 text-sm">Activity</span>
            </div>
            <p className="text-gray-400 text-sm mb-1">Verifications</p>
            <p className="text-3xl font-bold text-white">{analytics.overall.total_verifications}</p>
            <p className="text-xs text-gray-500 mt-2">in last {period} days</p>
          </div>

          <div className="bg-gradient-to-br from-orange-500/20 to-orange-600/20 border border-orange-500/30 rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <TrendingUp className="w-8 h-8 text-orange-400" />
              <span className="text-orange-400 text-sm">Balance</span>
            </div>
            <p className="text-gray-400 text-sm mb-1">Total Wallet Balance</p>
            <p className="text-3xl font-bold text-white">₹{Number(analytics.overall.total_wallet_balance || 0).toFixed(2)}</p>
            <p className="text-xs text-gray-500 mt-2">Across all users</p>
          </div>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
          {/* User Growth */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-6">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-400" />
              User Growth
            </h3>
            <div className="space-y-2">
              {analytics.userGrowth.slice(-10).map((item, index) => (
                <div key={index} className="flex items-center gap-3">
                  <span className="text-xs text-gray-400 w-24">
                    {new Date(item.date).toLocaleDateString()}
                  </span>
                  <div className="flex-1 bg-white/10 rounded-full h-6 overflow-hidden">
                    <div 
                      className="bg-blue-500 h-full rounded-full flex items-center justify-end pr-2"
                      style={{ width: `${Math.min((item.count / Math.max(...analytics.userGrowth.map(u => u.count))) * 100, 100)}%` }}
                    >
                      <span className="text-xs text-white font-semibold">{item.count}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Revenue by Day */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-6">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-green-400" />
              Daily Revenue
            </h3>
            <div className="space-y-2">
              {analytics.revenueByDay.slice(-10).map((item, index) => (
                <div key={index} className="flex items-center gap-3">
                  <span className="text-xs text-gray-400 w-24">
                    {new Date(item.date).toLocaleDateString()}
                  </span>
                  <div className="flex-1 bg-white/10 rounded-full h-6 overflow-hidden">
                    <div 
                      className="bg-green-500 h-full rounded-full flex items-center justify-end pr-2"
                      style={{ width: `${Math.min((Number(item.revenue) / Math.max(...analytics.revenueByDay.map(r => Number(r.revenue)))) * 100, 100)}%` }}
                    >
                      <span className="text-xs text-white font-semibold">₹{Number(item.revenue).toFixed(0)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Top Verifications & Users */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Top Verification Types */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-6">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <Activity className="w-5 h-5 text-purple-400" />
              Top Verifications
            </h3>
            <div className="space-y-3">
              {analytics.verificationStats.map((item, index) => (
                <div key={index} className="bg-white/5 rounded-lg p-3">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-white font-semibold capitalize">
                      {item.verification_type.replace(/-/g, ' ')}
                    </span>
                    <span className="text-green-400 font-bold">₹{Number(item.revenue).toFixed(0)}</span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span>{item.count} verifications</span>
                    <span>Avg: ₹{(Number(item.revenue) / item.count).toFixed(2)}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Top Users */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-6">
            <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-orange-400" />
              Top Spending Users
            </h3>
            <div className="space-y-3">
              {analytics.topUsers.map((user, index) => (
                <div key={index} className="bg-white/5 rounded-lg p-3">
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className="text-lg font-bold text-gray-400">#{index + 1}</span>
                      <div>
                        <p className="text-white font-semibold">{user.full_name || 'Unnamed'}</p>
                        <p className="text-xs text-gray-400">{user.email}</p>
                      </div>
                    </div>
                    <span className="text-green-400 font-bold">₹{Number(user.total_spent).toFixed(2)}</span>
                  </div>
                  <p className="text-xs text-gray-400">{user.transaction_count} transactions</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
