"use client"

import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import Navbar from "@/component/Navbaar";
import { ToastProvider } from "@/component/ToastProvider";
import Footer from "@/component/footer";
import { AlertProvider } from "@/component/AlertProvider";
import { UserProvider } from "@/context/UserContext";
import { usePathname } from "next/navigation";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const pathname = usePathname();
  const isAdminRoute = pathname?.startsWith('/admin');

  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased ${isAdminRoute ? '' : 'flex'}`}
      >
        <UserProvider>
          <AlertProvider>
            <ToastProvider>
              {!isAdminRoute && <Navbar />}
              <div className={`flex flex-col min-h-screen ${isAdminRoute ? 'w-full' : 'flex-1'}`}>
                <main className="flex-1">
                  {children}
                </main>
                {!isAdminRoute && <Footer />}
              </div>
            </ToastProvider>
          </AlertProvider>
        </UserProvider>
      </body>
    </html>
  );
}
