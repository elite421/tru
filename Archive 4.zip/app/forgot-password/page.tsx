"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Mail, ArrowLeft, CheckCircle } from "lucide-react"
import { Button } from "@/component/ui/button"
import { useAlert } from "@/component/AlertProvider"
import Link from "next/link"

export default function ForgotPasswordPage() {
  const router = useRouter()
  const { success, error } = useAlert()
  const [loading, setLoading] = useState(false)
  const [email, setEmail] = useState("")
  const [emailError, setEmailError] = useState("")
  const [resetSent, setResetSent] = useState(false)

  const validateEmail = () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!email.trim()) {
      setEmailError("Email is required")
      return false
    } else if (!emailRegex.test(email)) {
      setEmailError("Invalid email format")
      return false
    }
    setEmailError("")
    return true
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!validateEmail()) {
      error("Please enter a valid email address")
      return
    }

    setLoading(true)
    try {
      const response = await fetch("/api/auth/forgot-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email })
      })

      const data = await response.json()

      if (response.ok) {
        setResetSent(true)
        success("Password reset instructions sent to your email!")
      } else {
        error(data.error || "Failed to send reset instructions")
      }
    } catch (err) {
      console.error("Forgot password error:", err)
      error("An error occurred. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  if (resetSent) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-blue-900 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-white/10 backdrop-blur-lg border border-white/20 rounded-2xl p-8 shadow-2xl text-center">
            <div className="flex items-center justify-center mb-6">
              <div className="p-4 bg-green-500/20 rounded-full">
                <CheckCircle className="w-12 h-12 text-green-400" />
              </div>
            </div>

            <h2 className="text-2xl font-bold text-white mb-4">
              Check Your Email
            </h2>

            <p className="text-gray-300 mb-6">
              We've sent password reset instructions to <span className="font-semibold text-white">{email}</span>
            </p>

            <p className="text-sm text-gray-400 mb-6">
              If you don't receive an email within a few minutes, please check your spam folder or try again.
            </p>

            <Button
              onClick={() => router.push("/login")}
              className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white py-2.5 rounded-lg font-semibold"
            >
              Back to Login
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-900 via-purple-900 to-blue-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Back to Login */}
        <Link
          href="/login"
          className="flex items-center gap-2 text-gray-300 hover:text-white mb-4 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Login
        </Link>

        {/* Logo/Header */}
        <div className="text-center mb-6">
          <h1 className="text-4xl font-extrabold bg-gradient-to-r from-yellow-300 via-pink-400 to-purple-500 bg-clip-text text-transparent mb-1">
            TruVerify
          </h1>
          <p className="text-gray-300 text-sm">Verification Platform</p>
        </div>

        {/* Forgot Password Form */}
        <div className="bg-white/10 backdrop-blur-lg border border-white/20 rounded-2xl p-6 shadow-2xl">
          <div className="flex items-center justify-center mb-4">
            <div className="p-2 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-full">
              <Mail className="w-6 h-6 text-white" />
            </div>
          </div>

          <h2 className="text-xl font-bold text-white text-center mb-2">
            Forgot Password?
          </h2>

          <p className="text-gray-300 text-sm text-center mb-5">
            Enter your email address and we'll send you instructions to reset your password.
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Email */}
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value)
                    if (emailError) setEmailError("")
                  }}
                  className={`w-full pl-10 pr-4 py-3 bg-white/10 border ${
                    emailError ? "border-red-500" : "border-white/20"
                  } rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-400 transition-colors`}
                  placeholder="john@example.com"
                />
              </div>
              {emailError && (
                <p className="text-red-400 text-xs mt-1">{emailError}</p>
              )}
            </div>

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white py-2.5 rounded-lg font-semibold transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Mail className="w-5 h-5" />
                  Send Reset Instructions
                </>
              )}
            </Button>
          </form>

          {/* Additional Help */}
          <div className="mt-6 text-center">
            <p className="text-gray-400 text-xs">
              Remember your password?{" "}
              <Link href="/login" className="text-blue-400 hover:text-blue-300 font-semibold">
                Sign In
              </Link>
            </p>
          </div>
        </div>

        {/* Footer */}
        <p className="text-center text-gray-400 text-sm mt-6">
          TruVerify Verification Platform © 2024
        </p>
      </div>
    </div>
  )
}
