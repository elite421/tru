"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { 
  ArrowLeft, 
  TrendingUp, 
  CheckCircle, 
  XCircle,
  Database,
  Zap,
  Calendar,
  Filter,
  Download,
  Receipt,
  Info
} from "lucide-react"
import { Button } from "@/component/ui/button"

type Transaction = {
  id: string
  user_id: string
  verification_type: string
  amount: number
  base_amount?: number
  gst_amount?: number
  gst_percentage?: number
  deepvue_transaction_id?: string
  status: string
  cache_hit: boolean
  details: any
  response_time?: number
  created_at: string
}

export default function TransactionsPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [filterStatus, setFilterStatus] = useState("all")
  const [filterCacheHit, setFilterCacheHit] = useState("all")
  const [selectedTransaction, setSelectedTransaction] = useState<Transaction | null>(null)

  // Check authentication
  useEffect(() => {
    const userData = sessionStorage.getItem("user")
    if (!userData) {
      router.push("/login")
      return
    }
    
    try {
      const parsedUser = JSON.parse(userData)
      setUser(parsedUser)
    } catch (e) {
      router.push("/login")
    }
  }, [router])

  useEffect(() => {
    if (user) {
      fetchTransactions()
    }
  }, [user])

  const fetchTransactions = async () => {
    if (!user) return
    
    try {
      setLoading(true)
      // Use actual logged-in user's ID
      const userId = user.id
      const response = await fetch(`/api/transactions?userId=${userId}`)
      const data = await response.json()
      
      if (data.success) {
        setTransactions(data.transactions || [])
      }
    } catch (error) {
      console.error("Failed to fetch transactions:", error)
    } finally {
      setLoading(false)
    }
  }

  const filteredTransactions = transactions.filter(t => {
    if (filterStatus !== "all" && t.status !== filterStatus) return false
    if (filterCacheHit === "cached" && !t.cache_hit) return false
    if (filterCacheHit === "api" && t.cache_hit) return false
    return true
  })

  const totalAmount = filteredTransactions.reduce((sum, t) => sum + parseFloat(t.amount.toString()), 0)
  const totalBaseAmount = filteredTransactions.reduce((sum, t) => sum + parseFloat((t.base_amount || t.amount).toString()), 0)
  const totalGSTAmount = filteredTransactions.reduce((sum, t) => sum + parseFloat((t.gst_amount || 0).toString()), 0)
  const successCount = filteredTransactions.filter(t => t.status === "success").length
  const cacheHitCount = filteredTransactions.filter(t => t.cache_hit).length
  const apiCallCount = filteredTransactions.filter(t => !t.cache_hit && t.status === "success").length

  const exportToCSV = () => {
    const csvContent = [
      ["Date", "Type", "Base Amount", "GST Amount", "Total Amount", "Status", "Source", "DeepVue Transaction ID"],
      ...filteredTransactions.map(t => [
        new Date(t.created_at).toLocaleString(),
        t.verification_type,
        `₹${t.base_amount || t.amount}`,
        `₹${t.gst_amount || 0}`,
        `₹${t.amount}`,
        t.status,
        t.cache_hit ? "Cache" : "API",
        t.deepvue_transaction_id || "N/A"
      ])
    ].map(row => row.join(",")).join("\n")

    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = window.URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `transactions-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
  }

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => router.push("/")}
            className="flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white mb-4"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Dashboard
          </button>
          
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
                Transactions
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                All verification transactions with GST breakdown
              </p>
            </div>
            <Button
              onClick={exportToCSV}
              className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:opacity-90"
            >
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <TrendingUp className="w-8 h-8 text-green-600" />
              <div className="text-right">
                <span className="text-2xl font-bold text-gray-900 dark:text-white">
                  ₹{totalAmount.toFixed(2)}
                </span>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  Base: ₹{totalBaseAmount.toFixed(2)} + GST: ₹{totalGSTAmount.toFixed(2)}
                </p>
              </div>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">Total Amount</p>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <CheckCircle className="w-8 h-8 text-blue-600" />
              <span className="text-2xl font-bold text-gray-900 dark:text-white">
                {successCount}
              </span>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">Successful</p>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Database className="w-8 h-8 text-purple-600" />
              <span className="text-2xl font-bold text-gray-900 dark:text-white">
                {cacheHitCount}
              </span>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">From Cache</p>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6">
            <div className="flex items-center justify-between mb-2">
              <Zap className="w-8 h-8 text-orange-600" />
              <span className="text-2xl font-bold text-gray-900 dark:text-white">
                {apiCallCount}
              </span>
            </div>
            <p className="text-sm text-gray-600 dark:text-gray-400">API Calls</p>
          </div>
        </div>

        {/* Filters */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6 mb-6">
          <div className="flex flex-wrap gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                Status
              </label>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-4 py-2 border-2 border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-white outline-none"
              >
                <option value="all">All Status</option>
                <option value="success">Success</option>
                <option value="failed">Failed</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                Data Source
              </label>
              <select
                value={filterCacheHit}
                onChange={(e) => setFilterCacheHit(e.target.value)}
                className="px-4 py-2 border-2 border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-white outline-none"
              >
                <option value="all">All Sources</option>
                <option value="cached">From Cache</option>
                <option value="api">From API</option>
              </select>
            </div>
          </div>
        </div>

        {/* Transactions List */}
        {loading ? (
          <div className="text-center py-20">
            <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-indigo-600 mx-auto"></div>
            <p className="mt-4 text-gray-600 dark:text-gray-400">Loading transactions...</p>
          </div>
        ) : filteredTransactions.length === 0 ? (
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-12 text-center">
            <Calendar className="w-16 h-16 mx-auto mb-4 text-gray-400" />
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
              No Transactions Found
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              Start verifying to see transactions here
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {filteredTransactions.map((transaction) => (
              <div
                key={transaction.id}
                className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 cursor-pointer"
                onClick={() => setSelectedTransaction(transaction)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${
                      transaction.status === "success" 
                        ? "bg-green-100 dark:bg-green-900/30" 
                        : "bg-red-100 dark:bg-red-900/30"
                    }`}>
                      {transaction.status === "success" ? (
                        <CheckCircle className="w-6 h-6 text-green-600" />
                      ) : (
                        <XCircle className="w-6 h-6 text-red-600" />
                      )}
                    </div>
                    
                    <div>
                      <div className="flex items-center gap-3 mb-1">
                        <h3 className="text-lg font-bold text-gray-900 dark:text-white">
                          {transaction.verification_type.replace(/-/g, " ").toUpperCase()}
                        </h3>
                        {transaction.cache_hit && (
                          <span className="bg-purple-100 dark:bg-purple-900/30 text-purple-800 dark:text-purple-400 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                            <Database className="w-3 h-3" />
                            CACHED
                          </span>
                        )}
                        {!transaction.cache_hit && transaction.status === "success" && (
                          <span className="bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-400 px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                            <Zap className="w-3 h-3" />
                            API CALL
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {new Date(transaction.created_at).toLocaleString()}
                      </p>
                    </div>
                  </div>

                  <div className="text-right">
                    <p className="text-2xl font-bold text-indigo-600 dark:text-indigo-400">
                      ₹{transaction.amount}
                    </p>
                    {transaction.base_amount && transaction.gst_amount ? (
                      <div className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        <p>Base: ₹{transaction.base_amount}</p>
                        <p>GST ({transaction.gst_percentage || 18}%): ₹{transaction.gst_amount}</p>
                        {transaction.response_time && (
                          <p className="text-green-600 dark:text-green-400">⚡ {transaction.response_time}ms</p>
                        )}
                      </div>
                    ) : null}
                    <span className={`text-xs font-semibold ${
                      transaction.status === "success" 
                        ? "text-green-600 dark:text-green-400" 
                        : "text-red-600 dark:text-red-400"
                    }`}>
                      {transaction.status.toUpperCase()}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Transaction Detail Modal */}
      {selectedTransaction && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4" onClick={() => setSelectedTransaction(null)}>
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-2xl w-full p-6" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <Receipt className="w-6 h-6" />
                Transaction Details
              </h3>
              <button
                onClick={() => setSelectedTransaction(null)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
              >
                <XCircle className="w-6 h-6" />
              </button>
            </div>
            
            <div className="space-y-4">
              <div className="bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-900/20 dark:to-purple-900/20 rounded-lg p-4 border border-indigo-200 dark:border-indigo-800">
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">Transaction ID</p>
                <p className="text-lg font-mono font-bold text-gray-900 dark:text-white">#{selectedTransaction.id}</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4">
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Verification Type</p>
                  <p className="text-gray-900 dark:text-white font-semibold">
                    {selectedTransaction.verification_type.replace(/-/g, " ").toUpperCase()}
                  </p>
                </div>
                
                <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4">
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Status</p>
                  <p className={`font-semibold capitalize ${
                    selectedTransaction.status === 'success' ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'
                  }`}>
                    {selectedTransaction.status}
                  </p>
                </div>
              </div>

              {/* GST Breakdown */}
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-4 border border-blue-200 dark:border-blue-800">
                <h4 className="text-sm font-semibold text-gray-700 dark:text-gray-300 mb-3 flex items-center gap-2">
                  <Info className="w-4 h-4" />
                  Amount Breakdown
                </h4>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">Base Amount:</span>
                    <span className="font-semibold text-gray-900 dark:text-white">
                      ₹{selectedTransaction.base_amount || selectedTransaction.amount}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600 dark:text-gray-400">
                      GST ({selectedTransaction.gst_percentage || 18}%):
                    </span>
                    <span className="font-semibold text-gray-900 dark:text-white">
                      ₹{selectedTransaction.gst_amount || 0}
                    </span>
                  </div>
                  <div className="border-t border-blue-300 dark:border-blue-700 pt-2 mt-2">
                    <div className="flex justify-between">
                      <span className="font-bold text-gray-900 dark:text-white">Total Amount:</span>
                      <span className="font-bold text-indigo-600 dark:text-indigo-400 text-lg">
                        ₹{selectedTransaction.amount}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4">
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Date & Time</p>
                <p className="text-gray-900 dark:text-white font-semibold">
                  {new Date(selectedTransaction.created_at).toLocaleString()}
                </p>
              </div>

              <div className="bg-gray-50 dark:bg-gray-700/50 rounded-lg p-4">
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Data Source</p>
                <p className="text-gray-900 dark:text-white font-semibold flex items-center gap-2">
                  {selectedTransaction.cache_hit ? (
                    <>
                      <Database className="w-4 h-4 text-purple-600" />
                      Cached Data
                    </>
                  ) : (
                    <>
                      <Zap className="w-4 h-4 text-orange-600" />
                      Fresh API Call
                    </>
                  )}
                </p>
              </div>

              {selectedTransaction.response_time && (
                <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-4 border border-green-200 dark:border-green-800">
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Response Time</p>
                  <p className="text-gray-900 dark:text-white font-semibold flex items-center gap-2">
                    <Zap className="w-4 h-4 text-green-600" />
                    {selectedTransaction.response_time}ms
                  </p>
                </div>
              )}
            </div>
            
            <div className="mt-6">
              <Button
                onClick={() => setSelectedTransaction(null)}
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-3 rounded-lg hover:opacity-90"
              >
                Close
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
