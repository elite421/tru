"use client"

import { X, CheckCircle, AlertCircle, Info, AlertTriangle } from "lucide-react"
import { useEffect } from "react"

export type AlertType = "success" | "error" | "warning" | "info"

interface AlertProps {
  type: AlertType
  title?: string
  message: string
  onClose: () => void
  duration?: number
  showIcon?: boolean
}

export default function Alert({
  type,
  title,
  message,
  onClose,
  duration = 5000,
  showIcon = true
}: AlertProps) {
  useEffect(() => {
    if (duration > 0) {
      const timer = setTimeout(onClose, duration)
      return () => clearTimeout(timer)
    }
  }, [duration, onClose])

  const styles = {
    success: {
      container: "bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800",
      icon: <CheckCircle className="w-5 h-5 text-green-600 dark:text-green-400" />,
      title: "text-green-800 dark:text-green-200",
      message: "text-green-700 dark:text-green-300",
      button: "text-green-600 hover:text-green-800 dark:text-green-400 dark:hover:text-green-200"
    },
    error: {
      container: "bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800",
      icon: <AlertCircle className="w-5 h-5 text-red-600 dark:text-red-400" />,
      title: "text-red-800 dark:text-red-200",
      message: "text-red-700 dark:text-red-300",
      button: "text-red-600 hover:text-red-800 dark:text-red-400 dark:hover:text-red-200"
    },
    warning: {
      container: "bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800",
      icon: <AlertTriangle className="w-5 h-5 text-yellow-600 dark:text-yellow-400" />,
      title: "text-yellow-800 dark:text-yellow-200",
      message: "text-yellow-700 dark:text-yellow-300",
      button: "text-yellow-600 hover:text-yellow-800 dark:text-yellow-400 dark:hover:text-yellow-200"
    },
    info: {
      container: "bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800",
      icon: <Info className="w-5 h-5 text-blue-600 dark:text-blue-400" />,
      title: "text-blue-800 dark:text-blue-200",
      message: "text-blue-700 dark:text-blue-300",
      button: "text-blue-600 hover:text-blue-800 dark:text-blue-400 dark:hover:text-blue-200"
    }
  }

  const currentStyle = styles[type]

  return (
    <div
      className={`flex items-start gap-3 p-4 rounded-xl border-2 shadow-lg ${currentStyle.container} animate-slide-in-right`}
      role="alert"
    >
      {showIcon && (
        <div className="flex-shrink-0 mt-0.5">
          {currentStyle.icon}
        </div>
      )}
      
      <div className="flex-1 min-w-0">
        {title && (
          <h3 className={`font-semibold text-sm mb-1 ${currentStyle.title}`}>
            {title}
          </h3>
        )}
        <p className={`text-sm ${currentStyle.message}`}>
          {message}
        </p>
      </div>

      <button
        onClick={onClose}
        className={`flex-shrink-0 p-1 rounded-lg transition-colors ${currentStyle.button}`}
        aria-label="Close alert"
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  )
}
