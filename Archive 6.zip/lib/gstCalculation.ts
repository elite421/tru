// GST Calculation Utility
// GST Rate: 18%

export const GST_RATE = 18.00;

export interface GSTBreakdown {
  baseAmount: number;
  gstAmount: number;
  totalAmount: number;
  gstPercentage: number;
}

/**
 * Calculate GST breakdown for a given base amount
 * @param baseAmount - Base amount before GST
 * @returns GSTBreakdown object with base, GST, and total amounts
 */
export function calculateGST(baseAmount: number): GSTBreakdown {
  const gstAmount = parseFloat((baseAmount * (GST_RATE / 100)).toFixed(2));
  const totalAmount = parseFloat((baseAmount + gstAmount).toFixed(2));

  return {
    baseAmount: parseFloat(baseAmount.toFixed(2)),
    gstAmount,
    totalAmount,
    gstPercentage: GST_RATE
  };
}

/**
 * Calculate base amount from total amount (reverse GST calculation)
 * @param totalAmount - Total amount including GST
 * @returns GSTBreakdown object with base, GST, and total amounts
 */
export function calculateBaseFromTotal(totalAmount: number): GSTBreakdown {
  const baseAmount = parseFloat((totalAmount / (1 + GST_RATE / 100)).toFixed(2));
  const gstAmount = parseFloat((totalAmount - baseAmount).toFixed(2));

  return {
    baseAmount,
    gstAmount,
    totalAmount: parseFloat(totalAmount.toFixed(2)),
    gstPercentage: GST_RATE
  };
}

/**
 * Format amount as Indian Rupees
 * @param amount - Amount to format
 * @returns Formatted string with INR symbol
 */
export function formatINR(amount: number): string {
  return `₹${amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

/**
 * Extract DeepVue transaction ID from API response
 * @param response - DeepVue API response
 * @returns Transaction ID or null
 */
export function extractDeepVueTransactionId(response: any): string | null {
  return response?.transaction_id || 
         response?.decentro_transaction_id || 
         response?.reference_id || 
         null;
}
