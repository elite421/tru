import { NextRequest, NextResponse } from "next/server";
import { deepvueService } from "@/lib/deepvue";
import { query } from "@/db/db";
import { getCachedOrFetch } from "@/lib/verificationCache";
import { calculateGST, extractDeepVueTransactionId } from "@/lib/gstCalculation";
import { getUserVerificationPrice } from "@/lib/pricing";
import { logger } from "@/lib/logger";

export async function POST(request: NextRequest) {
  const startTime = Date.now();
  
  try {
    const body = await request.json();
    const { userId, pan } = body;

    if (!userId || !pan) {
      return NextResponse.json(
        { success: false, error: "User ID and PAN are required" },
        { status: 400 }
      );
    }

    // Validate PAN format
    const panRegex = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;
    if (!panRegex.test(pan.toUpperCase())) {
      return NextResponse.json(
        { success: false, error: "Invalid PAN format. Format: ABCDE1234F" },
        { status: 400 }
      );
    }

    // Get user-specific or default pricing from database
    const basePrice = await getUserVerificationPrice(userId, "pan");
    if (basePrice === null) {
      return NextResponse.json(
        { success: false, error: "Pricing not available for this verification type" },
        { status: 500 }
      );
    }

    const gstBreakdown = calculateGST(basePrice);
    const walletResult = await query("SELECT * FROM wallets WHERE user_id = $1", [userId]);

    if (walletResult.rows.length === 0 || parseFloat(walletResult.rows[0].balance) < gstBreakdown.totalAmount) {
      await logger.warning(
        "verification",
        `PAN verification failed: Insufficient balance for user ${userId}`,
        { user_id: userId, required: gstBreakdown.totalAmount, available: parseFloat(walletResult.rows[0].balance) },
        userId
      );
      return NextResponse.json(
        { success: false, error: `Insufficient wallet balance. Required: ₹${gstBreakdown.totalAmount} (Base: ₹${gstBreakdown.baseAmount} + GST: ₹${gstBreakdown.gstAmount})` },
        { status: 400 }
      );
    }

    const { data: deepvueResponse, cacheHit } = await getCachedOrFetch("pan", pan.toUpperCase(), () => deepvueService.verifyPAN(pan));
    const responseTime = Date.now() - startTime;
    const deepvueTransactionId = extractDeepVueTransactionId(deepvueResponse);

    const wallet = walletResult.rows[0];
    const currentBalance = parseFloat(wallet.balance);
    const newBalance = currentBalance - gstBreakdown.totalAmount;

    await query("UPDATE wallets SET balance = $1 WHERE id = $2", [newBalance, wallet.id]);
    
    await query(
      `INSERT INTO wallet_transactions (wallet_id, user_id, transaction_type, amount, base_amount, gst_amount, gst_percentage, deepvue_transaction_id, response_time, balance_before, balance_after, description, reference_type, status) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)`,
      [wallet.id, userId, "debit", gstBreakdown.totalAmount, gstBreakdown.baseAmount, gstBreakdown.gstAmount, gstBreakdown.gstPercentage, deepvueTransactionId, responseTime, currentBalance, newBalance, `PAN verification${cacheHit ? ' (cached)' : ''}`, "verification", "completed"]
    );
    
    // Log verification
    await logger.success(
      "verification",
      `PAN verification completed for user ${userId}${cacheHit ? ' (from cache)' : ''}`,
      { user_id: userId, pan_number: pan.substring(0, 3) + '***' + pan.substring(7), amount_charged: gstBreakdown.totalAmount, cache_hit: cacheHit },
      userId
    );
    
    await query(
      `INSERT INTO verification_requests (user_id, verification_type, document_number, status, cost, verification_data) 
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [userId, "pan", pan.toUpperCase(), deepvueResponse.success ? "success" : "failed", gstBreakdown.totalAmount, JSON.stringify(deepvueResponse)]
    );

    await query(
      `INSERT INTO transactions (user_id, verification_type, amount, base_amount, gst_amount, gst_percentage, deepvue_transaction_id, response_time, status, cache_hit, details) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)`,
      [userId, "pan", gstBreakdown.totalAmount, gstBreakdown.baseAmount, gstBreakdown.gstAmount, gstBreakdown.gstPercentage, deepvueTransactionId, responseTime, "success", cacheHit, JSON.stringify(deepvueResponse)]
    );

    return NextResponse.json({
      success: true,
      data: deepvueResponse,
      cacheHit,
      deepvueTransactionId,
      responseTime,
      wallet: { baseAmount: gstBreakdown.baseAmount, gstAmount: gstBreakdown.gstAmount, gstPercentage: gstBreakdown.gstPercentage, totalAmount: gstBreakdown.totalAmount, amountDeducted: gstBreakdown.totalAmount, newBalance },
    });
  } catch (error: any) {
    const responseTime = Date.now() - startTime;
    console.error("PAN verification error:", error);
    await logger.error(
      "verification",
      `PAN verification system error: ${error.message}`,
      { error: error.message, stack: error.stack }
    );
    return NextResponse.json(
      { success: false, error: error.message || "Verification failed", responseTime },
      { status: 500 }
    );
  }
}
