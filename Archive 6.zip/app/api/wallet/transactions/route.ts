import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");

    if (!userId) {
      return NextResponse.json(
        { success: false, error: "User ID is required" },
        { status: 400 }
      );
    }

    // Fetch wallet by user_id
    const walletResult = await query(
      "SELECT id FROM wallets WHERE user_id = $1",
      [userId]
    );

    if (walletResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "Wallet not found" },
        { status: 404 }
      );
    }

    const walletId = walletResult.rows[0].id;

    // Fetch only credit transactions (wallet recharges)
    const transactionsResult = await query(
      `SELECT 
        id,
        transaction_type as type,
        amount,
        balance_before as "balanceBefore",
        balance_after as "balanceAfter",
        description,
        reference_type as "referenceType",
        status,
        response_time,
        created_at as "createdAt"
       FROM wallet_transactions
       WHERE wallet_id = $1 AND transaction_type = 'credit'
       ORDER BY created_at DESC
       LIMIT 100`,
      [walletId]
    );

    return NextResponse.json(
      {
        success: true,
        transactions: transactionsResult.rows,
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Wallet transactions fetch error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to fetch transactions" },
      { status: 500 }
    );
  }
}
