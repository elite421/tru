import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";
import { logger } from "@/lib/logger";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, amount, paymentMethod } = body;

    if (!userId || !amount) {
      return NextResponse.json(
        { success: false, error: "User ID and amount are required" },
        { status: 400 }
      );
    }

    if (amount <= 0) {
      return NextResponse.json(
        { success: false, error: "Amount must be greater than 0" },
        { status: 400 }
      );
    }

    // Get or create wallet
    let walletResult = await query(
      `SELECT * FROM wallets WHERE user_id = $1`,
      [userId]
    );

    let walletId;
    let currentBalance = 0;

    if (walletResult.rows.length === 0) {
      const createWallet = await query(
        `INSERT INTO wallets (user_id, balance) VALUES ($1, 0) RETURNING *`,
        [userId]
      );
      walletId = createWallet.rows[0].id;
    } else {
      walletId = walletResult.rows[0].id;
      currentBalance = parseFloat(walletResult.rows[0].balance);
    }

    // Update wallet balance
    const newBalance = currentBalance + parseFloat(amount);
    await query(
      `UPDATE wallets SET balance = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2`,
      [newBalance, walletId]
    );

    // Create transaction record
    await query(
      `INSERT INTO wallet_transactions 
       (wallet_id, user_id, transaction_type, amount, balance_before, balance_after, description, reference_type, payment_method, status) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)`,
      [
        walletId,
        userId,
        "credit",
        amount,
        currentBalance,
        newBalance,
        `Wallet recharge via ${paymentMethod || 'manual'}`,
        "recharge",
        paymentMethod || "manual",
        "completed"
      ]
    );

    // Log wallet recharge
    await logger.success(
      "wallet",
      `Wallet recharged: ₹${amount} added to user ${userId}`,
      { user_id: userId, amount, payment_method: paymentMethod || 'manual', old_balance: currentBalance, new_balance: newBalance },
      userId.toString()
    );

    return NextResponse.json(
      { 
        success: true, 
        message: "Wallet recharged successfully",
        newBalance 
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Wallet recharge error:", error);
    await logger.error(
      "wallet",
      `Wallet recharge failed: ${error.message}`,
      { error: error.message, stack: error.stack }
    );
    return NextResponse.json(
      { success: false, error: error.message || "Failed to recharge wallet" },
      { status: 500 }
    );
  }
}
