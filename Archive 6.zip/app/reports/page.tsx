"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/component/ui/button"
import { formatDateTime } from "@/lib/dateUtils"
import { 
  Download, 
  FileText, 
  Calendar, 
  Clock, 
  Filter, 
  CheckCircle,
  XCircle,
  RefreshCw,
  Mail,
  Save
} from "lucide-react"

type Report = {
  id: number
  verificationType: string
  status: string
  timestamp: string
  amount: number
  details: any
}

type ScheduledReport = {
  id: number
  frequency: string
  time: string
  email: string
  active: boolean
}

export default function ReportsPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [reports, setReports] = useState<Report[]>([])
  const [loading, setLoading] = useState(true)
  const [filterType, setFilterType] = useState<string>("all")
  const [filterStatus, setFilterStatus] = useState<string>("all")
  const [dateFrom, setDateFrom] = useState<string>("")
  const [dateTo, setDateTo] = useState<string>("")
  
  // Scheduled reports state
  const [showScheduleModal, setShowScheduleModal] = useState(false)
  const [scheduleFrequency, setScheduleFrequency] = useState<string>("daily")
  const [scheduleTime, setScheduleTime] = useState<string>("09:00")
  const [scheduleEmail, setScheduleEmail] = useState<string>("")
  const [scheduledReports, setScheduledReports] = useState<ScheduledReport[]>([])

  // Check authentication
  useEffect(() => {
    const userData = sessionStorage.getItem("user")
    if (!userData) {
      router.push("/login")
      return
    }
    
    try {
      const parsedUser = JSON.parse(userData)
      setUser(parsedUser)
    } catch (e) {
      router.push("/login")
    }
  }, [router])

  useEffect(() => {
    if (user) {
      fetchReports()
      fetchScheduledReports()
    }
  }, [user])

  const fetchReports = async () => {
    if (!user) return
    
    setLoading(true)
    try {
      // Use actual logged-in user's ID
      const userId = user.id
      console.log('[Reports] Fetching verification history for userId:', userId)
      
      const response = await fetch(`/api/verification/history?userId=${userId}&limit=50&offset=0`)
      
      if (response.ok) {
        const data = await response.json()
        console.log('[Reports] Verification history loaded:', data)
        
        if (data.success && data.history) {
          setReports(data.history.map((v: any) => ({
            id: v.id,
            verificationType: v.verification_type || v.verificationType,
            status: v.status,
            timestamp: v.created_at || v.createdAt,
            amount: v.amount_charged || v.cost || v.amount || 0,
            details: v.details || v.verificationData || {}
          })))
        }
      } else {
        console.error('[Reports] Failed to fetch verification history:', response.status)
        // Show empty state
        setReports([])
      }
    } catch (error) {
      console.error('[Reports] Error fetching reports:', error)
      // Fallback to empty data
      setReports([])
    } finally {
      setLoading(false)
    }
  }

  const fetchReportsOld = async () => {
    setLoading(true)
    try {
      // Mock data - DEPRECATED
      const mockReports: Report[] = [
        {
          id: 1,
          verificationType: "PAN",
          status: "success",
          timestamp: new Date().toISOString(),
          amount: 5,
          details: { pan: "ABCDE1234F", name: "John Doe" }
        },
        {
          id: 2,
          verificationType: "Aadhar",
          status: "success",
          timestamp: new Date(Date.now() - 86400000).toISOString(),
          amount: 5,
          details: { aadhar: "1234 5678 9012", name: "Jane Smith" }
        },
        {
          id: 3,
          verificationType: "Email",
          status: "failed",
          timestamp: new Date(Date.now() - 172800000).toISOString(),
          amount: 2,
          details: { email: "test@example.com" }
        }
      ]
      setReports(mockReports)
    } catch (error) {
      console.error("Error fetching reports:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchScheduledReports = async () => {
    // Mock data - replace with actual API call
    const mockScheduled: ScheduledReport[] = [
      {
        id: 1,
        frequency: "daily",
        time: "09:00",
        email: "admin@truverify.com",
        active: true
      }
    ]
    setScheduledReports(mockScheduled)
  }

  const handleDownloadReport = (reportId: number, format: string) => {
    const report = reports.find(r => r.id === reportId)
    if (!report) return

    const dataStr = format === "json" 
      ? JSON.stringify(report, null, 2)
      : `Report ID: ${report.id}\nType: ${report.verificationType}\nStatus: ${report.status}\nDate: ${formatDateTime(report.timestamp)}\nAmount: ₹${report.amount}\n\nDetails:\n${JSON.stringify(report.details, null, 2)}`

    const blob = new Blob([dataStr], { type: format === "json" ? "application/json" : "text/plain" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = `report-${reportId}.${format === "json" ? "json" : "txt"}`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }

  const handleDownloadAllReports = () => {
    const allReportsData = filteredReports.map(report => ({
      id: report.id,
      type: report.verificationType,
      status: report.status,
      timestamp: report.timestamp,
      amount: report.amount,
      details: report.details
    }))

    const dataStr = JSON.stringify(allReportsData, null, 2)
    const blob = new Blob([dataStr], { type: "application/json" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.href = url
    link.download = `all-reports-${new Date().toISOString().split('T')[0]}.json`
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    URL.revokeObjectURL(url)
  }

  const handleScheduleReport = async () => {
    if (!scheduleEmail) {
      alert("Please enter an email address")
      return
    }

    const newSchedule: ScheduledReport = {
      id: scheduledReports.length + 1,
      frequency: scheduleFrequency,
      time: scheduleTime,
      email: scheduleEmail,
      active: true
    }

    setScheduledReports([...scheduledReports, newSchedule])
    setShowScheduleModal(false)
    setScheduleEmail("")
    alert("Scheduled report created successfully!")
  }

  const toggleScheduleStatus = (id: number) => {
    setScheduledReports(scheduledReports.map(schedule => 
      schedule.id === id ? { ...schedule, active: !schedule.active } : schedule
    ))
  }

  const deleteSchedule = (id: number) => {
    setScheduledReports(scheduledReports.filter(schedule => schedule.id !== id))
  }

  const filteredReports = reports.filter(report => {
    const typeMatch = filterType === "all" || report.verificationType.toLowerCase() === filterType.toLowerCase()
    const statusMatch = filterStatus === "all" || report.status === filterStatus
    const dateMatch = (!dateFrom || new Date(report.timestamp) >= new Date(dateFrom)) &&
                     (!dateTo || new Date(report.timestamp) <= new Date(dateTo))
    return typeMatch && statusMatch && dateMatch
  })

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 dark:from-gray-900 dark:to-gray-800 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
            Reports & Analytics
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Download verification reports and manage scheduled reports
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 border border-gray-100 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Total Reports</p>
                <p className="text-3xl font-bold text-gray-900 dark:text-white">{reports.length}</p>
              </div>
              <FileText className="w-10 h-10 text-indigo-600" />
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 border border-gray-100 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Successful</p>
                <p className="text-3xl font-bold text-green-600">{reports.filter(r => r.status === "success").length}</p>
              </div>
              <CheckCircle className="w-10 h-10 text-green-600" />
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 border border-gray-100 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Failed</p>
                <p className="text-3xl font-bold text-red-600">{reports.filter(r => r.status === "failed").length}</p>
              </div>
              <XCircle className="w-10 h-10 text-red-600" />
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 border border-gray-100 dark:border-gray-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Scheduled</p>
                <p className="text-3xl font-bold text-blue-600">{scheduledReports.filter(s => s.active).length}</p>
              </div>
              <Calendar className="w-10 h-10 text-blue-600" />
            </div>
          </div>
        </div>

        {/* Filters and Actions */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6 mb-6 border border-gray-100 dark:border-gray-700">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div className="flex flex-col md:flex-row gap-4 flex-1">
              <div>
                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                  Verification Type
                </label>
                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value)}
                  className="px-4 py-2 border-2 border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-white outline-none"
                >
                  <option value="all">All Types</option>
                  <optgroup label="Communication">
                    <option value="email">Email</option>
                    <option value="phone">Phone</option>
                  </optgroup>
                  <optgroup label="Identity">
                    <option value="aadhar">Aadhar</option>
                    <option value="pan">PAN</option>
                    <option value="driving-license">Driving License</option>
                  </optgroup>
                  <optgroup label="Financial">
                    <option value="bank-account">Bank Account</option>
                    <option value="ifsc">IFSC</option>
                    <option value="upi">UPI</option>
                    <option value="upi-advanced">UPI Advanced</option>
                  </optgroup>
                  <optgroup label="Business & Tax">
                    <option value="gst">GST</option>
                    <option value="gst-advanced">GST Advanced</option>
                    <option value="gstin-by-pan">GSTIN by PAN</option>
                    <option value="track-gstr">Track GSTR</option>
                    <option value="cin">CIN</option>
                    <option value="din">DIN</option>
                    <option value="tan">TAN</option>
                    <option value="tds-compliance">TDS Compliance</option>
                  </optgroup>
                  <optgroup label="Government">
                    <option value="rc">Vehicle RC</option>
                  </optgroup>
                  <optgroup label="EPFO">
                    <option value="aadhaar-to-uan">Aadhaar to UAN</option>
                    <option value="pan-to-uan">PAN to UAN</option>
                    <option value="uan-employment">UAN to Employment</option>
                  </optgroup>
                  <optgroup label="Mobile Intelligence">
                    <option value="mobile-to-name">Mobile to Name</option>
                    <option value="mobile-to-pan">Mobile to PAN</option>
                    <option value="mobile-to-dl">Mobile to DL</option>
                    <option value="mobile-digital-age">Mobile Digital Age</option>
                    <option value="mobile-network">Mobile Network</option>
                    <option value="mobile-to-upi">Mobile to UPI</option>
                  </optgroup>
                  <optgroup label="Document OCR">
                    <option value="ocr-aadhaar">Aadhaar OCR</option>
                    <option value="ocr-pan">PAN OCR</option>
                    <option value="ocr-voter-id">Voter ID OCR</option>
                    <option value="ocr-dl">DL OCR</option>
                    <option value="ocr-cheque">Cheque OCR</option>
                    <option value="ocr-gstin">GSTIN OCR</option>
                  </optgroup>
                  <optgroup label="Advanced">
                    <option value="face-match">Face Match</option>
                    <option value="liveness-check">Liveness Check</option>
                    <option value="credit-report">Credit Report</option>
                    <option value="udyam">Udyam</option>
                    <option value="udyog">Udyog</option>
                  </optgroup>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                  Status
                </label>
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e.target.value)}
                  className="px-4 py-2 border-2 border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-white outline-none"
                >
                  <option value="all">All Status</option>
                  <option value="success">Success</option>
                  <option value="failed">Failed</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                  From Date
                </label>
                <input
                  type="date"
                  value={dateFrom}
                  onChange={(e) => setDateFrom(e.target.value)}
                  className="px-4 py-2 border-2 border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                  To Date
                </label>
                <input
                  type="date"
                  value={dateTo}
                  onChange={(e) => setDateTo(e.target.value)}
                  className="px-4 py-2 border-2 border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-white outline-none"
                />
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                onClick={handleDownloadAllReports}
                className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:shadow-lg px-6 py-3 rounded-xl font-semibold flex items-center gap-2"
              >
                <Download className="w-5 h-5" />
                Download All
              </Button>
              <Button
                onClick={() => setShowScheduleModal(true)}
                className="bg-blue-600 text-white hover:bg-blue-700 px-6 py-3 rounded-xl font-semibold flex items-center gap-2"
              >
                <Calendar className="w-5 h-5" />
                Schedule Report
              </Button>
            </div>
          </div>
        </div>

        {/* Scheduled Reports */}
        {scheduledReports.length > 0 && (
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6 mb-6 border border-gray-100 dark:border-gray-700">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">Scheduled Reports</h2>
            <div className="space-y-3">
              {scheduledReports.map((schedule) => (
                <div key={schedule.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-xl">
                  <div className="flex items-center gap-4">
                    <Clock className="w-6 h-6 text-indigo-600" />
                    <div>
                      <p className="font-semibold text-gray-900 dark:text-white">
                        {schedule.frequency.charAt(0).toUpperCase() + schedule.frequency.slice(1)} Report at {schedule.time}
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Send to: {schedule.email}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => toggleScheduleStatus(schedule.id)}
                      className={`px-4 py-2 rounded-lg font-semibold ${
                        schedule.active
                          ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400"
                          : "bg-gray-200 text-gray-600 dark:bg-gray-600 dark:text-gray-400"
                      }`}
                    >
                      {schedule.active ? "Active" : "Inactive"}
                    </button>
                    <button
                      onClick={() => deleteSchedule(schedule.id)}
                      className="px-4 py-2 bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400 rounded-lg font-semibold hover:bg-red-200"
                    >
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Reports List */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6 border border-gray-100 dark:border-gray-700">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Verification Reports</h2>
          
          {loading ? (
            <div className="text-center py-12">
              <RefreshCw className="w-12 h-12 animate-spin text-indigo-600 mx-auto mb-4" />
              <p className="text-gray-600 dark:text-gray-400">Loading reports...</p>
            </div>
          ) : filteredReports.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 dark:text-gray-400">No reports found</p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredReports.map((report) => (
                <div key={report.id} className="flex flex-col md:flex-row md:items-center md:justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-600 transition-all gap-4">
                  <div className="flex items-center gap-4 flex-1">
                    {report.status === "success" ? (
                      <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0" />
                    ) : (
                      <XCircle className="w-6 h-6 text-red-600 flex-shrink-0" />
                    )}
                    <div className="flex-1">
                      <p className="font-semibold text-gray-900 dark:text-white">
                        {report.verificationType} Verification
                      </p>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {formatDateTime(report.timestamp)} • ₹{report.amount}
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={() => handleDownloadReport(report.id, "json")}
                      className="bg-indigo-600 text-white hover:bg-indigo-700 px-4 py-2 rounded-lg text-sm font-semibold"
                    >
                      JSON
                    </Button>
                    <Button
                      onClick={() => handleDownloadReport(report.id, "txt")}
                      className="bg-gray-600 text-white hover:bg-gray-700 px-4 py-2 rounded-lg text-sm font-semibold"
                    >
                      TXT
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Schedule Modal */}
      {showScheduleModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full p-8">
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Schedule Report</h3>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                  Frequency
                </label>
                <select
                  value={scheduleFrequency}
                  onChange={(e) => setScheduleFrequency(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-white outline-none"
                >
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="monthly">Monthly</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                  Time
                </label>
                <input
                  type="time"
                  value={scheduleTime}
                  onChange={(e) => setScheduleTime(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                  Email Address
                </label>
                <input
                  type="email"
                  placeholder="admin@truverify.com"
                  value={scheduleEmail}
                  onChange={(e) => setScheduleEmail(e.target.value)}
                  className="w-full px-4 py-3 border-2 border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-white outline-none"
                />
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <Button
                onClick={() => setShowScheduleModal(false)}
                className="flex-1 bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-white hover:bg-gray-300 dark:hover:bg-gray-600 py-3 rounded-xl font-semibold"
              >
                Cancel
              </Button>
              <Button
                onClick={handleScheduleReport}
                className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:shadow-lg py-3 rounded-xl font-semibold flex items-center justify-center gap-2"
              >
                <Save className="w-5 h-5" />
                Save Schedule
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
