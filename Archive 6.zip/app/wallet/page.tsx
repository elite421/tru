"use client"

import { useEffect, useState, useCallback } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/component/ui/button"
import { Wallet, Plus, ArrowUpRight, ArrowDownRight, RefreshCw, CreditCard } from "lucide-react"

type Transaction = {
  id: number
  type: string
  amount: number
  balanceBefore: number
  balanceAfter: number
  description: string
  referenceType: string
  status: string
  createdAt: string
}

export default function WalletPage() {
  const router = useRouter()
  const [user, setUser] = useState<any>(null)
  const [balance, setBalance] = useState<number>(0)
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)
  const [rechargeAmount, setRechargeAmount] = useState<string>("")
  const [rechargeLoading, setRechargeLoading] = useState(false)
  const [showRechargeModal, setShowRechargeModal] = useState(false)

  // Check authentication
  useEffect(() => {
    const userData = sessionStorage.getItem("user")
    if (!userData) {
      router.push("/login")
      return
    }
    
    try {
      const parsedUser = JSON.parse(userData)
      setUser(parsedUser)
    } catch (e) {
      router.push("/login")
    }
  }, [router])

  const fetchWalletData = useCallback(async () => {
    if (!user) return
    
    try {
      // Use actual logged-in user's ID
      const userId = user.id

      // Fetch balance with userId
      const balanceRes = await fetch(`/api/wallet/balance?userId=${userId}`)
      const balanceData = await balanceRes.json()
      if (balanceData.success) {
        setBalance(balanceData.balance)
      }

      // Fetch transactions with userId
      const transactionsRes = await fetch(`/api/wallet/transactions?userId=${userId}`)
      const transactionsData = await transactionsRes.json()
      if (transactionsData.success) {
        // Ensure all amounts are numbers
        const processedTransactions = (transactionsData.transactions || []).map((tx: Transaction) => ({
          ...tx,
          amount: Number(tx.amount) || 0,
          balanceBefore: Number(tx.balanceBefore) || 0,
          balanceAfter: Number(tx.balanceAfter) || 0
        }))
        setTransactions(processedTransactions)
      }
    } catch (error) {
      console.error("Error fetching wallet data:", error)
    } finally {
      setLoading(false)
    }
  }, [user])

  useEffect(() => {
    fetchWalletData()
  }, [fetchWalletData])

  const handleRecharge = async () => {
    const amount = parseFloat(rechargeAmount)
    
    if (!amount || amount <= 0) {
      alert("Please enter a valid amount")
      return
    }

    if (amount < 10) {
      alert("Minimum recharge amount is ₹10")
      return
    }

    setRechargeLoading(true)

    try {
      const response = await fetch("/api/wallet/recharge", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.id,
          amount,
          paymentMethod: "demo"
        })
      })

      const data = await response.json()

      if (data.success) {
        setBalance(data.newBalance)
        setRechargeAmount("")
        setShowRechargeModal(false)
        fetchWalletData() // Refresh transactions
        alert(`Successfully added ₹${amount} to your wallet!`)
      } else {
        alert(`Recharge failed: ${data.error}`)
      }
    } catch (error) {
      console.error("Recharge error:", error)
      alert("Failed to recharge wallet")
    } finally {
      setRechargeLoading(false)
    }
  }

  const quickAmounts = [100, 500, 1000, 2000, 5000, 10000]

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
            My Wallet
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Manage your wallet balance and view transaction history
          </p>
        </div>

        {/* Balance Card */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="md:col-span-2 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl shadow-2xl p-8 text-white">
            <div className="flex items-center justify-between">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Wallet className="w-6 h-6" />
                  <p className="text-white/80 text-sm font-medium">Available Balance</p>
                </div>
                <h2 className="text-5xl font-bold mb-4">
                  {loading ? "..." : `₹${balance.toFixed(2)}`}
                </h2>
                <p className="text-white/70 text-sm">
                  {transactions.length} transactions in history
                </p>
              </div>
              <button
                onClick={() => fetchWalletData()}
                className="bg-white/20 hover:bg-white/30 rounded-full p-3 transition-all"
                title="Refresh"
              >
                <RefreshCw className="w-6 h-6" />
              </button>
            </div>

            <div className="mt-6 pt-6 border-t border-white/20">
              <Button
                onClick={() => setShowRechargeModal(true)}
                className="w-full bg-black dark:bg-gray-800 text-indigo-600 dark:text-indigo-400 hover:bg-gray-100 dark:hover:bg-gray-700 font-bold py-4 text-lg rounded-xl flex items-center justify-center gap-2 shadow-lg border-2 border-white/10"
              >
                <Plus className="w-5 h-5" />
                Add Money
              </Button>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="space-y-4">
            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
              <div className="flex items-center gap-3 mb-3">
                <div className="bg-green-100 dark:bg-green-900/30 rounded-full p-2">
                  <ArrowUpRight className="w-5 h-5 text-green-600 dark:text-green-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Credits</p>
                  <p className="text-xl font-bold text-gray-900 dark:text-white">
                    {transactions.filter(t => t.type === "credit").length}
                  </p>
                </div>
              </div>
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6">
              <div className="flex items-center gap-3 mb-3">
                <div className="bg-red-100 dark:bg-red-900/30 rounded-full p-2">
                  <ArrowDownRight className="w-5 h-5 text-red-600 dark:text-red-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">Debits</p>
                  <p className="text-xl font-bold text-gray-900 dark:text-white">
                    {transactions.filter(t => t.type === "debit").length}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Transactions */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8">
          <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
            Transaction History
          </h3>

          {loading ? (
            <div className="text-center py-12">
              <RefreshCw className="w-12 h-12 animate-spin text-indigo-600 mx-auto mb-4" />
              <p className="text-gray-600 dark:text-gray-400">Loading transactions...</p>
            </div>
          ) : transactions.length === 0 ? (
            <div className="text-center py-12">
              <Wallet className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 dark:text-gray-400">No transactions yet</p>
            </div>
          ) : (
            <div className="space-y-3">
              {transactions.map((transaction) => (
                <div
                  key={transaction.id}
                  className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700/50 rounded-xl hover:bg-gray-100 dark:hover:bg-gray-700 transition-all"
                >
                  <div className="flex items-center gap-4">
                    <div className={`rounded-full p-2 ${
                      transaction.type === "credit"
                        ? "bg-green-100 dark:bg-green-900/30"
                        : "bg-red-100 dark:bg-red-900/30"
                    }`}>
                      {transaction.type === "credit" ? (
                        <ArrowUpRight className="w-5 h-5 text-green-600 dark:text-green-400" />
                      ) : (
                        <ArrowDownRight className="w-5 h-5 text-red-600 dark:text-red-400" />
                      )}
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900 dark:text-white">
                        {transaction.description}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {new Date(transaction.createdAt).toLocaleString()} • {transaction.referenceType}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-lg font-bold ${
                      transaction.type === "credit"
                        ? "text-green-600 dark:text-green-400"
                        : "text-red-600 dark:text-red-400"
                    }`}>
                      {transaction.type === "credit" ? "+" : "-"}₹{transaction.amount.toFixed(2)}
                    </p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Balance: ₹{transaction.balanceAfter.toFixed(2)}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Recharge Modal */}
      {showRechargeModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white">Add Money</h3>
              <button
                onClick={() => setShowRechargeModal(false)}
                className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            {/* Quick Amount Buttons */}
            <div className="mb-6">
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">Quick Select</p>
              <div className="grid grid-cols-3 gap-2">
                {quickAmounts.map((amount) => (
                  <button
                    key={amount}
                    onClick={() => setRechargeAmount(amount.toString())}
                    className="py-3 px-4 bg-gray-100 dark:bg-gray-700 hover:bg-indigo-100 dark:hover:bg-indigo-900/30 rounded-xl font-semibold text-gray-900 dark:text-white transition-all"
                  >
                    ₹{amount}
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Amount */}
            <div className="mb-6">
              <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                Or Enter Custom Amount
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500 font-semibold">
                  ₹
                </span>
                <input
                  type="number"
                  value={rechargeAmount}
                  onChange={(e) => setRechargeAmount(e.target.value)}
                  placeholder="100"
                  min="10"
                  className="w-full pl-8 pr-4 py-4 border-2 border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white text-lg font-semibold outline-none"
                />
              </div>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                Minimum amount: ₹10
              </p>
            </div>

            {/* Payment Method Info */}
            <div className="mb-6 p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl">
              <div className="flex items-start gap-2">
                <CreditCard className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-blue-900 dark:text-blue-300">Demo Mode</p>
                  <p className="text-xs text-blue-700 dark:text-blue-400">
                    Payment gateway integration will be added in production
                  </p>
                </div>
              </div>
            </div>

            {/* Buttons */}
            <div className="flex gap-3">
              <Button
                onClick={() => setShowRechargeModal(false)}
                className="flex-1 bg-gray-200 dark:bg-gray-700 text-gray-900 dark:text-white hover:bg-gray-300 dark:hover:bg-gray-600 py-3"
              >
                Cancel
              </Button>
              <Button
                onClick={handleRecharge}
                disabled={rechargeLoading}
                className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:opacity-90 py-3 disabled:opacity-50"
              >
                {rechargeLoading ? "Processing..." : "Add Money"}
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
