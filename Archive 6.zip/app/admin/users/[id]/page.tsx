"use client"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { 
  ArrowLeft,
  Mail,
  Phone,
  Calendar,
  Shield,
  CreditCard,
  Activity,
  Save,
  RefreshCw,
  CheckCircle,
  XCircle
} from "lucide-react"
import { Button } from "@/component/ui/button"

type User = {
  id: number
  email: string
  phone: string
  full_name: string
  company_name: string
  created_at: string
  last_login: string | null
  pricing_plan_id: number | null
  plan_expires_at: string | null
  plan_name: string | null
  email_verified: boolean
  phone_verified: boolean
}

type PricingPlan = {
  id: number
  name: string
  description: string
  rates: Array<{ verification_type: string; price: number }>
  user_count: number
}

type Transaction = {
  id: number
  transaction_type: string
  amount: number
  description: string
  created_at: string
}

type Verification = {
  id: number
  verification_type: string
  status: string
  amount_charged: number
  created_at: string
}

export default function UserDetailsPage() {
  const router = useRouter()
  const params = useParams()
  const userId = params.id as string

  const [user, setUser] = useState<User | null>(null)
  const [plans, setPlans] = useState<PricingPlan[]>([])
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [verifications, setVerifications] = useState<Verification[]>([])
  const [loading, setLoading] = useState(true)
  const [assigning, setAssigning] = useState(false)
  
  const [selectedPlanId, setSelectedPlanId] = useState<number | null>(null)
  const [planExpiry, setPlanExpiry] = useState("")
  
  // Wallet management state
  const [showWalletModal, setShowWalletModal] = useState(false)
  const [walletAction, setWalletAction] = useState<'add' | 'deduct'>('add')
  const [walletAmount, setWalletAmount] = useState('')
  const [walletReason, setWalletReason] = useState('')
  const [walletBalance, setWalletBalance] = useState(0)

  useEffect(() => {
    checkAuth()
    fetchUserDetails()
    fetchPlans()
    fetchUserActivity()
    fetchWalletBalance()
  }, [userId])

  const checkAuth = () => {
    const adminUser = sessionStorage.getItem("admin_user")
    if (!adminUser) {
      router.push("/admin/login")
    }
  }

  const fetchUserDetails = async () => {
    try {
      setLoading(true)
      const response = await fetch(`/api/user/${userId}`)
      
      if (response.ok) {
        const data = await response.json()
        if (data.success && data.user) {
          setUser(data.user)
          setSelectedPlanId(data.user.pricing_plan_id)
          if (data.user.plan_expires_at) {
            setPlanExpiry(new Date(data.user.plan_expires_at).toISOString().split('T')[0])
          }
        }
      }
    } catch (error) {
      console.error("Error fetching user:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchPlans = async () => {
    try {
      const response = await fetch("/api/admin/plans")
      if (response.ok) {
        const data = await response.json()
        setPlans(data.plans || [])
      }
    } catch (error) {
      console.error("Error fetching plans:", error)
    }
  }

  const fetchUserActivity = async () => {
    try {
      const [transResponse, verifyResponse] = await Promise.all([
        fetch(`/api/wallet/transactions?userId=${userId}`),
        fetch(`/api/verification/history?userId=${userId}&limit=50&offset=0`)
      ])

      if (transResponse.ok) {
        const transData = await transResponse.json()
        setTransactions(transData.transactions || [])
      }

      if (verifyResponse.ok) {
        const verifyData = await verifyResponse.json()
        setVerifications(verifyData.history || [])
      }
    } catch (error) {
      console.error("Error fetching activity:", error)
    }
  }

  const handleAssignPlan = async () => {
    if (!selectedPlanId) {
      alert("Please select a plan")
      return
    }

    setAssigning(true)
    try {
      const response = await fetch(`/api/admin/users/${userId}/assign-plan`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          planId: selectedPlanId,
          expiresAt: planExpiry || null
        })
      })

      const data = await response.json()

      if (response.ok) {
        alert(data.message || "Plan assigned successfully!")
        fetchUserDetails()
      } else {
        alert(data.error || "Failed to assign plan")
      }
    } catch (error) {
      console.error("Error assigning plan:", error)
      alert("Failed to assign plan")
    } finally {
      setAssigning(false)
    }
  }

  const handleRemovePlan = async () => {
    if (!confirm("Remove plan from this user?")) return

    setAssigning(true)
    try {
      const response = await fetch(`/api/admin/users/${userId}/assign-plan`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          planId: null,
          expiresAt: null
        })
      })

      if (response.ok) {
        alert("Plan removed successfully!")
        setSelectedPlanId(null)
        setPlanExpiry("")
        fetchUserDetails()
      }
    } catch (error) {
      console.error("Error removing plan:", error)
      alert("Failed to remove plan")
    } finally {
      setAssigning(false)
    }
  }

  const fetchWalletBalance = async () => {
    try {
      const response = await fetch(`/api/wallet/balance?userId=${userId}`)
      if (response.ok) {
        const data = await response.json()
        if (data.success) {
          setWalletBalance(data.balance)
        }
      }
    } catch (error) {
      console.error("Error fetching wallet balance:", error)
    }
  }

  const handleWalletUpdate = async () => {
    const amount = parseFloat(walletAmount)
    if (!amount || amount <= 0) {
      alert("Please enter a valid amount")
      return
    }

    if (!walletReason.trim()) {
      alert("Please provide a reason for this transaction")
      return
    }

    try {
      const response = await fetch("/api/admin/wallet-management", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: parseInt(userId),
          action: walletAction,
          amount: amount,
          reason: walletReason
        })
      })

      const data = await response.json()

      if (data.success) {
        alert(data.message)
        setWalletBalance(data.newBalance)
        setShowWalletModal(false)
        setWalletAmount('')
        setWalletReason('')
      } else {
        alert(data.error || "Failed to update wallet")
      }
    } catch (error) {
      console.error("Error updating wallet:", error)
      alert("Failed to update wallet")
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <RefreshCw className="w-8 h-8 animate-spin text-white" />
      </div>
    )
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <p className="text-white text-xl">User not found</p>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-950">
        <div className="p-4 md:p-8">
          {/* Header */}
          <div className="mb-8">
            <button
              onClick={() => router.push("/admin/users")}
              className="flex items-center gap-2 text-gray-400 hover:text-white mb-4 transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              Back to Users
            </button>
            
            <div className="flex items-center gap-4">
              <div className="w-20 h-20 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                <span className="text-white text-3xl font-bold">
                  {user.full_name?.charAt(0).toUpperCase() || 'U'}
                </span>
              </div>
              <div>
                <h1 className="text-4xl font-bold text-white mb-2">
                  {user.full_name || 'Unnamed User'}
                </h1>
                <p className="text-gray-400">User ID: {user.id}</p>
              </div>
            </div>
          </div>

          {/* User Info Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            <div className="bg-white/5 border border-white/10 rounded-xl p-4">
              <div className="flex items-center gap-3 mb-2">
                <Mail className="w-5 h-5 text-blue-400" />
                <p className="text-sm text-gray-400">Email</p>
              </div>
              <p className="text-white break-all">{user.email}</p>
              {user.email_verified && (
                <p className="text-xs text-green-400 mt-1">✓ Verified</p>
              )}
            </div>

            <div className="bg-white/5 border border-white/10 rounded-xl p-4">
              <div className="flex items-center gap-3 mb-2">
                <Phone className="w-5 h-5 text-green-400" />
                <p className="text-sm text-gray-400">Phone</p>
              </div>
              <p className="text-white">{user.phone || 'Not provided'}</p>
              {user.phone_verified && (
                <p className="text-xs text-green-400 mt-1">✓ Verified</p>
              )}
            </div>

            <div className="bg-white/5 border border-white/10 rounded-xl p-4">
              <div className="flex items-center gap-3 mb-2">
                <Shield className="w-5 h-5 text-orange-400" />
                <p className="text-sm text-gray-400">Company</p>
              </div>
              <p className="text-white">{user.company_name || 'Not provided'}</p>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-xl p-4">
              <div className="flex items-center gap-3 mb-2">
                <Calendar className="w-5 h-5 text-purple-400" />
                <p className="text-sm text-gray-400">Date Joined</p>
              </div>
              <p className="text-white">{new Date(user.created_at).toLocaleDateString()}</p>
              <p className="text-xs text-gray-400 mt-1">{new Date(user.created_at).toLocaleTimeString()}</p>
            </div>

            <div className="bg-white/5 border border-white/10 rounded-xl p-4">
              <div className="flex items-center gap-3 mb-2">
                <Activity className="w-5 h-5 text-cyan-400" />
                <p className="text-sm text-gray-400">Last Login</p>
              </div>
              <p className="text-white">
                {user.last_login ? new Date(user.last_login).toLocaleDateString() : 'Never'}
              </p>
              {user.last_login && (
                <p className="text-xs text-gray-400 mt-1">{new Date(user.last_login).toLocaleTimeString()}</p>
              )}
            </div>

            <div className="bg-white/5 border border-white/10 rounded-xl p-4">
              <div className="flex items-center gap-3 mb-2">
                <CreditCard className="w-5 h-5 text-yellow-400" />
                <p className="text-sm text-gray-400">Current Plan</p>
              </div>
              <p className="text-white">{user.plan_name || 'Default Plan'}</p>
              {user.plan_expires_at && (
                <p className="text-xs text-gray-400 mt-1">
                  Expires: {new Date(user.plan_expires_at).toLocaleDateString()}
                </p>
              )}
            </div>
          </div>

          {/* Plan Assignment Section */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-6 mb-6">
            <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
              <Shield className="w-6 h-6 text-yellow-400" />
              Pricing Plan Assignment
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">
                  Select Plan
                </label>
                <select
                  value={selectedPlanId || ''}
                  onChange={(e) => setSelectedPlanId(e.target.value ? parseInt(e.target.value) : null)}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
                >
                  <option value="">No Plan (Default Pricing)</option>
                  {plans.map(plan => (
                    <option key={plan.id} value={plan.id}>
                      {plan.name} - {plan.user_count} users
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">
                  Plan Expiry (Optional)
                </label>
                <input
                  type="date"
                  value={planExpiry}
                  onChange={(e) => setPlanExpiry(e.target.value)}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
                />
              </div>
            </div>

            {/* Current Plan Info */}
            {user.plan_name && (
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4 mb-4">
                <p className="text-sm text-gray-300">Current Plan:</p>
                <p className="text-xl font-bold text-white">{user.plan_name}</p>
                {user.plan_expires_at && (
                  <p className="text-sm text-gray-400 mt-1">
                    Expires: {new Date(user.plan_expires_at).toLocaleDateString()}
                    {new Date(user.plan_expires_at) > new Date() ? (
                      <span className="text-green-400 ml-2">✓ Active</span>
                    ) : (
                      <span className="text-red-400 ml-2">✗ Expired</span>
                    )}
                  </p>
                )}
              </div>
            )}

            <div className="flex gap-3">
              <Button
                onClick={handleAssignPlan}
                disabled={assigning}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {assigning ? (
                  <RefreshCw className="w-4 h-4 animate-spin" />
                ) : (
                  <Save className="w-4 h-4" />
                )}
                {user.plan_name ? 'Update Plan' : 'Assign Plan'}
              </Button>

              {user.plan_name && (
                <Button
                  onClick={handleRemovePlan}
                  disabled={assigning}
                  className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg disabled:opacity-50"
                >
                  Remove Plan
                </Button>
              )}
            </div>
          </div>

          {/* Wallet Management Section */}
          <div className="bg-white/5 border border-white/10 rounded-xl p-6 mb-6">
            <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
              <CreditCard className="w-6 h-6 text-green-400" />
              Wallet Management
            </h2>

            <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4 mb-4">
              <p className="text-sm text-gray-300">Current Balance:</p>
              <p className="text-3xl font-bold text-green-400">₹{walletBalance.toFixed(2)}</p>
            </div>

            <div className="flex gap-3">
              <button
                onClick={() => {
                  setWalletAction('add')
                  setShowWalletModal(true)
                }}
                className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-lg font-semibold transition-colors"
              >
                Add Money
              </button>
              <button
                onClick={() => {
                  setWalletAction('deduct')
                  setShowWalletModal(true)
                }}
                className="flex-1 bg-red-600 hover:bg-red-700 text-white py-2 px-4 rounded-lg font-semibold transition-colors"
              >
                Deduct Money
              </button>
            </div>
          </div>

          {/* Activity Tabs */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Recent Transactions */}
            <div className="bg-white/5 border border-white/10 rounded-xl p-6">
              <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-green-400" />
                Recent Transactions
              </h3>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {transactions.length === 0 ? (
                  <p className="text-gray-400 text-center py-4">No transactions yet</p>
                ) : (
                  transactions.slice(0, 10).map(transaction => (
                    <div key={transaction.id} className="bg-white/5 rounded-lg p-3 border border-white/10">
                      <div className="flex items-center justify-between mb-1">
                        <span className={`font-semibold ${
                          transaction.transaction_type === 'credit' ? 'text-green-400' : 'text-red-400'
                        }`}>
                          {transaction.transaction_type === 'credit' ? '+' : '-'}₹{transaction.amount}
                        </span>
                        <span className="text-xs text-gray-400">
                          {new Date(transaction.created_at).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-sm text-gray-300">{transaction.description}</p>
                    </div>
                  ))
                )}
              </div>
            </div>

            {/* Recent Verifications */}
            <div className="bg-white/5 border border-white/10 rounded-xl p-6">
              <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
                <Activity className="w-5 h-5 text-purple-400" />
                Recent Verifications
              </h3>
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {verifications.length === 0 ? (
                  <p className="text-gray-400 text-center py-4">No verifications yet</p>
                ) : (
                  verifications.slice(0, 10).map(verification => (
                    <div key={verification.id} className="bg-white/5 rounded-lg p-3 border border-white/10">
                      <div className="flex items-center justify-between mb-1">
                        <span className="font-semibold text-white capitalize">
                          {verification.verification_type.replace(/-/g, ' ')}
                        </span>
                        <span className={`text-xs px-2 py-1 rounded ${
                          verification.status === 'success' 
                            ? 'bg-green-500/20 text-green-400' 
                            : 'bg-red-500/20 text-red-400'
                        }`}>
                          {verification.status}
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-400">
                          Cost: ₹{verification.amount_charged}
                        </span>
                        <span className="text-xs text-gray-400">
                          {new Date(verification.created_at).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>

      {/* Wallet Update Modal */}
      {showWalletModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-800 rounded-2xl shadow-2xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-white">
                {walletAction === 'add' ? 'Add Money' : 'Deduct Money'}
              </h3>
              <button
                onClick={() => {
                  setShowWalletModal(false)
                  setWalletAmount('')
                  setWalletReason('')
                }}
                className="text-gray-400 hover:text-white"
              >
                <XCircle className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">
                  Amount (₹)
                </label>
                <input
                  type="number"
                  value={walletAmount}
                  onChange={(e) => setWalletAmount(e.target.value)}
                  placeholder="Enter amount"
                  min="0"
                  step="0.01"
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-300 mb-2">
                  Reason
                </label>
                <textarea
                  value={walletReason}
                  onChange={(e) => setWalletReason(e.target.value)}
                  placeholder="Enter reason for this transaction"
                  rows={3}
                  className="w-full px-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400 resize-none"
                />
              </div>

              <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-lg p-3">
                <p className="text-sm text-yellow-300">
                  This will {walletAction} ₹{walletAmount || '0'} {walletAction === 'add' ? 'to' : 'from'} the user's wallet.
                </p>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <button
                onClick={() => {
                  setShowWalletModal(false)
                  setWalletAmount('')
                  setWalletReason('')
                }}
                className="flex-1 bg-gray-600 hover:bg-gray-700 text-white py-2 rounded-lg font-semibold transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleWalletUpdate}
                className={`flex-1 ${
                  walletAction === 'add' 
                    ? 'bg-green-600 hover:bg-green-700' 
                    : 'bg-red-600 hover:bg-red-700'
                } text-white py-2 rounded-lg font-semibold transition-colors`}
              >
                Confirm {walletAction === 'add' ? 'Add' : 'Deduct'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
