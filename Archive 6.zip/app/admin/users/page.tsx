"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { 
  Users as UsersIcon, 
  Search,
  CheckCircle,
  XCircle,
  DollarSign,
  Calendar,
  Download,
  RefreshCw,
  Mail,
  Phone,
  CreditCard,
  Shield
} from "lucide-react"
import { Button } from "@/component/ui/button"

type User = {
  id: number
  email: string
  phone: string
  full_name: string
  company_name: string
  created_at: string
  updated_at: string
  last_login: string
  email_verified: boolean
  phone_verified: boolean
  pricing_plan_id: number
  plan_expires_at: string
  plan_name: string
  wallet_balance: number
  total_verifications: number
  successful_verifications: number
  total_credits: number
  total_debits: number
}

interface PricingPlan {
  id: number
  name: string
  description: string
  is_active: boolean
}

export default function AdminUsersPage() {
  const router = useRouter()
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [availablePlans, setAvailablePlans] = useState<PricingPlan[]>([])
  const [selectedPlanId, setSelectedPlanId] = useState<number | null>(null)
  const [planExpiryDate, setPlanExpiryDate] = useState<string>("")
  const [assigningPlan, setAssigningPlan] = useState(false)

  useEffect(() => {
    checkAuth()
    fetchUsers()
    fetchPlans()
  }, [])

  const checkAuth = () => {
    const adminUser = sessionStorage.getItem("admin_user")
    if (!adminUser) {
      router.push("/admin/login")
    }
  }

  const fetchUsers = async () => {
    try {
      setLoading(true)
      const response = await fetch("/api/admin/users")
      
      if (response.ok) {
        const data = await response.json()
        setUsers(data.users || [])
      }
    } catch (error) {
      console.error("Error fetching users:", error)
    } finally {
      setLoading(false)
    }
  }

  const fetchPlans = async () => {
    try {
      const response = await fetch("/api/admin/plans")
      if (response.ok) {
        const data = await response.json()
        setAvailablePlans(data.plans || [])
      }
    } catch (error) {
      console.error("Error fetching plans:", error)
    }
  }

  const handleAssignPlan = async () => {
    if (!selectedUser || !selectedPlanId) {
      alert("Please select a plan")
      return
    }

    setAssigningPlan(true)
    try {
      const response = await fetch(`/api/admin/users/${selectedUser.id}/assign-plan`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          planId: selectedPlanId,
          expiresAt: planExpiryDate || null
        })
      })

      const data = await response.json()

      if (response.ok) {
        alert(data.message || "Plan assigned successfully!")
        setSelectedUser(null)
        setSelectedPlanId(null)
        setPlanExpiryDate("")
        fetchUsers()
      } else {
        alert(data.error || "Failed to assign plan")
      }
    } catch (error) {
      alert("Failed to assign plan")
    } finally {
      setAssigningPlan(false)
    }
  }

  const handleRemovePlan = async () => {
    if (!selectedUser) return
    
    if (!confirm("Remove pricing plan from this user?")) return

    try {
      const response = await fetch(`/api/admin/users/${selectedUser.id}/assign-plan`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          planId: null,
          expiresAt: null
        })
      })

      const data = await response.json()

      if (response.ok) {
        alert("Plan removed successfully!")
        setSelectedUser(null)
        fetchUsers()
      } else {
        alert(data.error || "Failed to remove plan")
      }
    } catch (error) {
      alert("Failed to remove plan")
    }
  }

  const handleExport = () => {
    const csv = [
      ["ID", "Name", "Email", "Phone", "Company", "Plan", "Wallet Balance", "Verifications", "Joined Date", "Last Login"],
      ...filteredUsers.map(u => [
        u.id,
        u.full_name,
        u.email,
        u.phone,
        u.company_name || 'N/A',
        u.plan_name || 'No Plan',
        u.wallet_balance.toFixed(2),
        u.total_verifications,
        new Date(u.created_at).toLocaleDateString(),
        u.last_login ? new Date(u.last_login).toLocaleDateString() : 'Never'
      ])
    ].map(row => row.join(",")).join("\n")

    const blob = new Blob([csv], { type: "text/csv" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `users-${new Date().toISOString().split('T')[0]}.csv`
    a.click()
  }

  const filteredUsers = users.filter(user => {
    const matchesSearch = 
      user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.phone?.includes(searchTerm)
    
    return matchesSearch
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-4xl font-bold text-white mb-2">
                User Management
              </h1>
              <p className="text-gray-400">
                Manage and monitor all registered users
              </p>
            </div>
            <div className="flex gap-3">
              <Button
                onClick={handleExport}
                className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-lg flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                Export
              </Button>
              <Button
                onClick={fetchUsers}
                className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2"
              >
                <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                Refresh
              </Button>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Total Users</p>
                <p className="text-2xl font-bold text-white">{users.length}</p>
              </div>
              <UsersIcon className="w-8 h-8 text-blue-400" />
            </div>
          </div>
          
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">With Plans</p>
                <p className="text-2xl font-bold text-green-400">
                  {users.filter(u => u.pricing_plan_id).length}
                </p>
              </div>
              <Shield className="w-8 h-8 text-green-400" />
            </div>
          </div>
          
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">New This Month</p>
                <p className="text-2xl font-bold text-purple-400">
                  {users.filter(u => {
                    const created = new Date(u.created_at)
                    const now = new Date()
                    return created.getMonth() === now.getMonth() && created.getFullYear() === now.getFullYear()
                  }).length}
                </p>
              </div>
              <Calendar className="w-8 h-8 text-purple-400" />
            </div>
          </div>
          
          <div className="bg-white/5 border border-white/10 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-400">Search Results</p>
                <p className="text-2xl font-bold text-white">{filteredUsers.length}</p>
              </div>
              <Search className="w-8 h-8 text-orange-400" />
            </div>
          </div>
        </div>

        {/* Search Bar */}
        <div className="bg-white/5 border border-white/10 rounded-xl p-4 mb-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search by name, email, or phone..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-4 py-2 bg-white/10 border border-white/20 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-400"
            />
          </div>
        </div>

        {/* Users Table */}
        <div className="bg-white/5 border border-white/10 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-white/10">
                <tr>
                  <th className="p-4 text-left text-sm font-semibold text-gray-300">User</th>
                  <th className="p-4 text-left text-sm font-semibold text-gray-300">Contact</th>
                  <th className="p-4 text-left text-sm font-semibold text-gray-300">Wallet</th>
                  <th className="p-4 text-left text-sm font-semibold text-gray-300">Plan</th>
                  <th className="p-4 text-left text-sm font-semibold text-gray-300">DOJ / Last Login</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr>
                    <td colSpan={5} className="p-8 text-center">
                      <RefreshCw className="w-8 h-8 animate-spin text-white mx-auto mb-2" />
                      <p className="text-gray-400">Loading users...</p>
                    </td>
                  </tr>
                ) : filteredUsers.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="p-8 text-center text-gray-400">
                      No users found
                    </td>
                  </tr>
                ) : (
                  filteredUsers.map((user) => (
                    <tr 
                      key={user.id} 
                      className="border-t border-white/10 hover:bg-white/5 transition-colors cursor-pointer"
                      onClick={() => setSelectedUser(user)}
                    >
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                            <span className="text-white text-2xl font-bold">
                              {user.full_name?.charAt(0).toUpperCase() || 'U'}
                            </span>
                          </div>
                          <div>
                            <p className="font-semibold text-white">{user.full_name || 'Unnamed User'}</p>
                            <p className="text-sm text-gray-400">ID: {user.id}</p>
                          </div>
                        </div>
                      </td>
                      <td className="p-4">
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 text-sm text-gray-300">
                            <Mail className="w-4 h-4 text-gray-400" />
                            {user.email}
                            {user.email_verified && <CheckCircle className="w-3 h-3 text-green-400" />}
                          </div>
                          {user.phone && (
                            <div className="flex items-center gap-2 text-sm text-gray-300">
                              <Phone className="w-4 h-4 text-gray-400" />
                              {user.phone}
                              {user.phone_verified && <CheckCircle className="w-3 h-3 text-green-400" />}
                            </div>
                          )}
                          {user.company_name && (
                            <p className="text-xs text-gray-400 italic">{user.company_name}</p>
                          )}
                        </div>
                      </td>
                      <td className="p-4">
                        <div className="space-y-1">
                          <p className="text-lg font-bold text-green-400">₹{user.wallet_balance.toFixed(2)}</p>
                          <p className="text-xs text-gray-400">{user.total_verifications} verifications</p>
                        </div>
                      </td>
                      <td className="p-4">
                        {user.plan_name ? (
                          <div>
                            <span className="px-3 py-1 bg-green-500/20 text-green-400 rounded-full text-sm font-semibold">
                              {user.plan_name}
                            </span>
                            {user.plan_expires_at && (
                              <p className="text-xs text-gray-400 mt-1">
                                Exp: {new Date(user.plan_expires_at).toLocaleDateString()}
                              </p>
                            )}
                          </div>
                        ) : (
                          <span className="px-3 py-1 bg-gray-500/20 text-gray-400 rounded-full text-sm">
                            Default
                          </span>
                        )}
                      </td>
                      <td className="p-4">
                        <div className="space-y-1">
                          <div>
                            <p className="text-xs text-gray-400">Joined:</p>
                            <p className="text-sm text-white font-medium">
                              {new Date(user.created_at).toLocaleDateString()}
                            </p>
                          </div>
                          {user.last_login && (
                            <div>
                              <p className="text-xs text-gray-400">Last Login:</p>
                              <p className="text-xs text-green-400">
                                {new Date(user.last_login).toLocaleDateString()}
                              </p>
                            </div>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* User Detail Modal */}
      {selectedUser && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-gray-800 rounded-2xl shadow-2xl max-w-2xl w-full p-6">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-500 rounded-full flex items-center justify-center">
                <span className="text-white text-2xl font-bold">
                  {selectedUser.full_name?.charAt(0).toUpperCase() || 'U'}
                </span>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-white">{selectedUser.full_name || 'Unnamed User'}</h3>
                <p className="text-gray-400">User ID: {selectedUser.id}</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div className="bg-white/5 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Mail className="w-5 h-5 text-blue-400" />
                  <p className="text-sm text-gray-400">Email</p>
                </div>
                <p className="text-white">{selectedUser.email}</p>
              </div>
              
              <div className="bg-white/5 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Phone className="w-5 h-5 text-green-400" />
                  <p className="text-sm text-gray-400">Phone</p>
                </div>
                <p className="text-white">{selectedUser.phone || 'Not provided'}</p>
              </div>
              
              <div className="bg-white/5 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="w-5 h-5 text-purple-400" />
                  <p className="text-sm text-gray-400">Pricing Plan</p>
                </div>
                <p className="text-white">{selectedUser.plan_name || 'No Plan'}</p>
              </div>
              
              <div className="bg-white/5 rounded-lg p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Calendar className="w-5 h-5 text-orange-400" />
                  <p className="text-sm text-gray-400">Date of Joining (DOJ)</p>
                </div>
                <p className="text-white font-semibold">{new Date(selectedUser.created_at).toLocaleDateString()}</p>
                <p className="text-xs text-gray-400 mt-1">{new Date(selectedUser.created_at).toLocaleTimeString()}</p>
              </div>
            </div>

            {/* Additional Information Section */}
            <div className="bg-blue-900/20 border border-blue-500/30 rounded-xl p-4 mb-6">
              <h4 className="text-lg font-semibold text-white mb-3">Account Information</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {selectedUser.company_name && (
                  <div>
                    <p className="text-xs text-gray-400">Company Name</p>
                    <p className="text-white font-medium">{selectedUser.company_name}</p>
                  </div>
                )}
                <div>
                  <p className="text-xs text-gray-400">Email Status</p>
                  <p className={`font-medium ${selectedUser.email_verified ? 'text-green-400' : 'text-yellow-400'}`}>
                    {selectedUser.email_verified ? '✓ Verified' : '○ Not Verified'}
                  </p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Phone Status</p>
                  <p className={`font-medium ${selectedUser.phone_verified ? 'text-green-400' : 'text-yellow-400'}`}>
                    {selectedUser.phone_verified ? '✓ Verified' : '○ Not Verified'}
                  </p>
                </div>
                {selectedUser.last_login && (
                  <div>
                    <p className="text-xs text-gray-400">Last Login</p>
                    <p className="text-white text-sm">{new Date(selectedUser.last_login).toLocaleString()}</p>
                  </div>
                )}
              </div>
            </div>

            {/* Wallet & Activity Section */}
            <div className="bg-green-900/20 border border-green-500/30 rounded-xl p-4 mb-6">
              <h4 className="text-lg font-semibold text-white mb-3">Wallet & Activity</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div>
                  <p className="text-xs text-gray-400">Wallet Balance</p>
                  <p className="text-xl font-bold text-green-400">₹{selectedUser.wallet_balance.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Total Credits</p>
                  <p className="text-white font-semibold">₹{selectedUser.total_credits.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Total Debits</p>
                  <p className="text-white font-semibold">₹{selectedUser.total_debits.toFixed(2)}</p>
                </div>
                <div>
                  <p className="text-xs text-gray-400">Verifications</p>
                  <p className="text-white font-semibold">{selectedUser.total_verifications}</p>
                  <p className="text-xs text-green-400">{selectedUser.successful_verifications} successful</p>
                </div>
              </div>
            </div>

            {selectedUser.plan_expires_at && (
              <div className="bg-white/5 rounded-lg p-4 mb-6">
                <div className="flex items-center gap-2 mb-2">
                  <Calendar className="w-5 h-5 text-yellow-400" />
                  <p className="text-sm text-gray-400">Plan Expiry</p>
                </div>
                <p className="text-white">{new Date(selectedUser.plan_expires_at).toLocaleString()}</p>
                <p className="text-sm mt-1">
                  {new Date(selectedUser.plan_expires_at) > new Date() ? (
                    <span className="text-green-400">✓ Active</span>
                  ) : (
                    <span className="text-red-400">✗ Expired</span>
                  )}
                </p>
              </div>
            )}
            
            <div className="flex gap-3">
              <Button
                onClick={() => setSelectedUser(null)}
                className="flex-1 bg-gray-600 hover:bg-gray-700 text-white py-2 rounded-lg"
              >
                Close
              </Button>
              <Button
                onClick={() => router.push(`/admin/users/${selectedUser.id}`)}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-lg"
              >
                View Details
              </Button>
            </div>

            {/* Plan Assignment Section */}
            <div className="mt-6 pt-6 border-t border-white/10">
              <h4 className="text-lg font-semibold text-white mb-4">Assign Pricing Plan</h4>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Select Plan
                  </label>
                  <select
                    value={selectedPlanId || ""}
                    onChange={(e) => setSelectedPlanId(e.target.value ? Number(e.target.value) : null)}
                    className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
                  >
                    <option value="">No Plan (Use Default Pricing)</option>
                    {availablePlans.filter(p => p.is_active).map((plan) => (
                      <option key={plan.id} value={plan.id}>
                        {plan.name}
                      </option>
                    ))}
                  </select>
                  {selectedUser.pricing_plan_id && (
                    <p className="text-xs text-gray-400 mt-1">
                      Current: {selectedUser.plan_name}
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Expiry Date (Optional)
                  </label>
                  <input
                    type="datetime-local"
                    value={planExpiryDate}
                    onChange={(e) => setPlanExpiryDate(e.target.value)}
                    className="w-full px-3 py-2 bg-white/10 border border-white/20 rounded-lg text-white focus:outline-none focus:border-blue-400"
                  />
                  <p className="text-xs text-gray-400 mt-1">
                    Leave empty for no expiration
                  </p>
                </div>

                <div className="flex gap-3">
                  {selectedUser.pricing_plan_id && (
                    <Button
                      onClick={handleRemovePlan}
                      className="flex-1 bg-red-600 hover:bg-red-700 text-white py-2 rounded-lg"
                    >
                      Remove Plan
                    </Button>
                  )}
                  <Button
                    onClick={handleAssignPlan}
                    disabled={assigningPlan || !selectedPlanId}
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white py-2 rounded-lg disabled:opacity-50"
                  >
                    {assigningPlan ? "Assigning..." : "Assign Plan"}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
