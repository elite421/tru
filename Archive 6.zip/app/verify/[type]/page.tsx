"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import { Button } from "@/component/ui/button"
import { ArrowLeft, Upload, FileText, Users, CheckCircle, XCircle, Download } from "lucide-react"
import { useToast } from "@/component/ToastProvider"

type VerificationMethod = "manual" | "bulk-file"

type VerificationConfig = {
  title: string
  description: string
  price: number
  fields: {
    name: string
    label: string
    type: string
    placeholder: string
    required: boolean
  }[]
  fileFormats?: string[]
}

const verificationConfigs: Record<string, VerificationConfig> = {
  email: {
    title: "Email Verification",
    description: "Verify email addresses instantly for B2B verification purposes.",
    price: 2, // From DEFAULT_RATES
    fields: [
      { name: "email", label: "Email Address", type: "email", placeholder: "Enter email address", required: true }
    ],
    fileFormats: [".csv", ".xlsx", ".txt"]
  },
  phone: {
    title: "Phone Verification",
    description: "Verify Indian mobile numbers instantly without OTP.",
    price: 3, // From DEFAULT_RATES
    fields: [
      { name: "phone", label: "Phone Number", type: "tel", placeholder: "Enter 10-digit phone number", required: true }
    ],
    fileFormats: [".csv", ".xlsx", ".txt"]
  },
  aadhar: {
    title: "Aadhar Verification",
    description: "Verify Aadhar card details quickly and securely.",
    price: 8, // From DEFAULT_RATES (updated from 5)
    fields: [
      { name: "aadhar", label: "Aadhar Number", type: "text", placeholder: "Enter 12-digit Aadhar number", required: true }
    ],
    fileFormats: [".csv", ".xlsx", ".pdf"]
  },
  "aadhaar-ekyc": {
    title: "Aadhaar eKYC",
    description: "Verify Aadhaar with OTP-based eKYC (2-step process). Note: Full 2-step UI coming soon.",
    price: 8,
    fields: [
      { name: "aadhaarNumber", label: "Aadhaar Number", type: "text", placeholder: "Enter 12-digit Aadhaar", required: true },
      { name: "step", label: "Step", type: "hidden", placeholder: "generate-otp", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  pan: {
    title: "PAN Verification",
    description: "Verify PAN card details instantly.",
    price: 5, // From DEFAULT_RATES
    fields: [
      { name: "pan", label: "PAN Number", type: "text", placeholder: "Enter PAN (e.g., ABCDE1234F)", required: true }
    ],
    fileFormats: [".csv", ".xlsx", ".pdf"]
  },
  "pan-plus": {
    title: "PAN Verification - Plus",
    description: "Enhanced PAN verification with additional details including name, category, and status.",
    price: 7,
    fields: [
      { name: "panNumber", label: "PAN Number", type: "text", placeholder: "Enter PAN (e.g., ABCDE1234F)", required: true }
    ],
    fileFormats: [".csv", ".xlsx", ".pdf"]
  },
  "driving-license": {
    title: "Driving License Verification",
    description: "Verify driving license with complete details.",
    price: 8,
    fields: [
      { name: "licenseNumber", label: "License Number", type: "text", placeholder: "Enter license number", required: true },
      { name: "dob", label: "Date of Birth", type: "date", placeholder: "", required: true }
    ],
    fileFormats: [".csv", ".xlsx", ".pdf"]
  },
  gst: {
    title: "GST Verification",
    description: "Verify GST registration and business details.",
    price: 7, // From DEFAULT_RATES
    fields: [
      { name: "gstin", label: "GST Number", type: "text", placeholder: "Enter 15-digit GSTIN", required: true }
    ],
    fileFormats: [".csv", ".xlsx", ".pdf"]
  },
  "gst-advanced": {
    title: "GST Advanced",
    description: "Advanced GST verification with detailed business info.",
    price: 10,
    fields: [
      { name: "gstinNumber", label: "GST Number", type: "text", placeholder: "Enter 15-digit GSTIN", required: true }
    ],
    fileFormats: [".csv", ".xlsx", ".pdf"]
  },
  "gstin-by-pan": {
    title: "GSTIN by PAN",
    description: "Find all GSTINs linked to a PAN number.",
    price: 6,
    fields: [
      { name: "panNumber", label: "PAN Number", type: "text", placeholder: "Enter PAN (e.g., ABCDE1234F)", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  "track-gstr": {
    title: "Track GSTR",
    description: "Track GST return filing status.",
    price: 8,
    fields: [
      { name: "gstinNumber", label: "GSTIN", type: "text", placeholder: "Enter 15-digit GSTIN", required: true },
      { name: "financialYear", label: "Financial Year", type: "text", placeholder: "e.g., 2023-24", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  "bank-account": {
    title: "Bank Account Verification",
    description: "Verify bank account details and IFSC code.",
    price: 6,
    fields: [
      { name: "accountNumber", label: "Account Number", type: "text", placeholder: "Enter account number", required: true },
      { name: "ifsc", label: "IFSC Code", type: "text", placeholder: "Enter IFSC code", required: true },
      { name: "accountHolderName", label: "Account Holder Name", type: "text", placeholder: "Enter account holder name", required: false }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  ifsc: {
    title: "IFSC Code Verification",
    description: "Verify bank branch details using IFSC code.",
    price: 2,
    fields: [
      { name: "ifsc", label: "IFSC Code", type: "text", placeholder: "Enter 11-character IFSC (e.g., SBIN0001234)", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  upi: {
    title: "UPI Verification",
    description: "Verify UPI ID (VPA) or get UPI IDs linked to a mobile number.",
    price: 4,
    fields: [
      { name: "vpa", label: "UPI ID / VPA", type: "text", placeholder: "Enter UPI ID (e.g., user@paytm)", required: false },
      { name: "mobileNumber", label: "Mobile Number (Optional)", type: "tel", placeholder: "Enter mobile to get linked UPIs", required: false }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  "upi-advanced": {
    title: "UPI Advanced",
    description: "Advanced UPI verification with detailed information.",
    price: 6,
    fields: [
      { name: "vpa", label: "UPI ID / VPA", type: "text", placeholder: "Enter UPI ID (e.g., user@paytm)", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  rc: {
    title: "Vehicle RC Verification",
    description: "Verify vehicle registration certificate details.",
    price: 7,
    fields: [
      { name: "rcNumber", label: "RC Number", type: "text", placeholder: "Enter vehicle registration number", required: true }
    ],
    fileFormats: [".csv", ".xlsx", ".pdf"]
  },
  cin: {
    title: "CIN Verification",
    description: "Verify Corporate Identification Number (MCA).",
    price: 8,
    fields: [
      { name: "cinNumber", label: "CIN Number", type: "text", placeholder: "Enter CIN", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  din: {
    title: "DIN Verification",
    description: "Verify Director Identification Number (MCA).",
    price: 8,
    fields: [
      { name: "dinNumber", label: "DIN Number", type: "text", placeholder: "Enter DIN", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  tan: {
    title: "TAN Verification",
    description: "Verify Tax Deduction Account Number.",
    price: 5,
    fields: [
      { name: "tanNumber", label: "TAN Number", type: "text", placeholder: "Enter TAN", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  "tds-compliance": {
    title: "TDS Compliance",
    description: "Check TDS compliance status (Section 206AB).",
    price: 7,
    fields: [
      { name: "panNumber", label: "PAN Number", type: "text", placeholder: "Enter PAN", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  "aadhaar-to-uan": {
    title: "Aadhaar to UAN",
    description: "Get UAN from Aadhaar number (EPFO Service).",
    price: 7,
    fields: [
      { name: "aadhaarNumber", label: "Aadhaar Number", type: "text", placeholder: "Enter 12-digit Aadhaar", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  "pan-to-uan": {
    title: "PAN to UAN",
    description: "Get UAN from PAN number (EPFO Service).",
    price: 7,
    fields: [
      { name: "panNumber", label: "PAN Number", type: "text", placeholder: "Enter PAN", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  "uan-employment": {
    title: "UAN to Employment History",
    description: "Get employment history from UAN (EPFO).",
    price: 9,
    fields: [
      { name: "uanNumber", label: "UAN Number", type: "text", placeholder: "Enter 12-digit UAN", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  "mobile-to-name": {
    title: "Mobile to Name",
    description: "Get name associated with a mobile number.",
    price: 6,
    fields: [
      { name: "mobileNumber", label: "Mobile Number", type: "tel", placeholder: "Enter 10-digit mobile", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  "mobile-to-pan": {
    title: "Mobile to PAN",
    description: "Get PAN linked to a mobile number.",
    price: 8,
    fields: [
      { name: "mobileNumber", label: "Mobile Number", type: "tel", placeholder: "Enter 10-digit mobile", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  "mobile-to-dl": {
    title: "Mobile to DL",
    description: "Get driving license details from mobile number.",
    price: 8,
    fields: [
      { name: "mobileNumber", label: "Mobile Number", type: "tel", placeholder: "Enter 10-digit mobile", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  "mobile-digital-age": {
    title: "Mobile to Digital Age",
    description: "Get digital age of a mobile number.",
    price: 6,
    fields: [
      { name: "mobileNumber", label: "Mobile Number", type: "tel", placeholder: "Enter 10-digit mobile", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  "mobile-network": {
    title: "Mobile Network Details",
    description: "Get network operator and circle details.",
    price: 4,
    fields: [
      { name: "mobileNumber", label: "Mobile Number", type: "tel", placeholder: "Enter 10-digit mobile", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  "mobile-to-uan": {
    title: "Mobile to UAN",
    description: "Get UAN from mobile number.",
    price: 7,
    fields: [
      { name: "mobileNumber", label: "Mobile Number", type: "tel", placeholder: "Enter 10-digit mobile", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  "mobile-to-upi": {
    title: "Mobile to Multiple UPI",
    description: "Get all UPI IDs linked to a mobile number.",
    price: 6,
    fields: [
      { name: "mobileNumber", label: "Mobile Number", type: "tel", placeholder: "Enter 10-digit mobile", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  "ocr-aadhaar": {
    title: "Aadhaar OCR",
    description: "Extract data from Aadhaar card images.",
    price: 10,
    fields: [
      { name: "frontImage", label: "Front Image URL", type: "text", placeholder: "Enter front image URL", required: true },
      { name: "backImage", label: "Back Image URL", type: "text", placeholder: "Enter back image URL", required: false }
    ],
    fileFormats: [".jpg", ".jpeg", ".png", ".pdf"]
  },
  "ocr-pan": {
    title: "PAN OCR",
    description: "Extract data from PAN card images.",
    price: 8,
    fields: [
      { name: "imageUrl", label: "PAN Image URL", type: "text", placeholder: "Enter image URL", required: true }
    ],
    fileFormats: [".jpg", ".jpeg", ".png", ".pdf"]
  },
  "ocr-voter-id": {
    title: "Voter ID OCR",
    description: "Extract data from Voter ID card images.",
    price: 10,
    fields: [
      { name: "frontImage", label: "Front Image URL", type: "text", placeholder: "Enter front image URL", required: true },
      { name: "backImage", label: "Back Image URL", type: "text", placeholder: "Enter back image URL", required: false }
    ],
    fileFormats: [".jpg", ".jpeg", ".png", ".pdf"]
  },
  "ocr-dl": {
    title: "Driving License OCR",
    description: "Extract data from DL card images.",
    price: 10,
    fields: [
      { name: "frontImage", label: "Front Image URL", type: "text", placeholder: "Enter front image URL", required: true },
      { name: "backImage", label: "Back Image URL", type: "text", placeholder: "Enter back image URL", required: false }
    ],
    fileFormats: [".jpg", ".jpeg", ".png", ".pdf"]
  },
  "ocr-cheque": {
    title: "Bank Cheque OCR",
    description: "Extract data from cheque images.",
    price: 8,
    fields: [
      { name: "imageUrl", label: "Cheque Image URL", type: "text", placeholder: "Enter image URL", required: true }
    ],
    fileFormats: [".jpg", ".jpeg", ".png", ".pdf"]
  },
  "ocr-gstin": {
    title: "GSTIN Certificate OCR",
    description: "Extract data from GST certificate.",
    price: 10,
    fields: [
      { name: "imageUrl", label: "Certificate Image URL", type: "text", placeholder: "Enter image URL", required: true }
    ],
    fileFormats: [".jpg", ".jpeg", ".png", ".pdf"]
  },
  "face-match": {
    title: "Face Match",
    description: "Compare two face images for matching.",
    price: 15,
    fields: [
      { name: "image1Url", label: "First Image URL", type: "text", placeholder: "Enter first image URL", required: true },
      { name: "image2Url", label: "Second Image URL", type: "text", placeholder: "Enter second image URL", required: true }
    ],
    fileFormats: [".jpg", ".jpeg", ".png"]
  },
  "liveness-check": {
    title: "Liveness Check",
    description: "Check if image is of a live person.",
    price: 12,
    fields: [
      { name: "imageUrl", label: "Image URL", type: "text", placeholder: "Enter image URL", required: true }
    ],
    fileFormats: [".jpg", ".jpeg", ".png"]
  },
  "credit-report": {
    title: "Credit Report",
    description: "Get comprehensive credit report and score.",
    price: 50,
    fields: [
      { name: "panNumber", label: "PAN Number", type: "text", placeholder: "Enter PAN", required: true },
      { name: "mobileNumber", label: "Mobile Number", type: "tel", placeholder: "Enter 10-digit mobile", required: true },
      { name: "consent", label: "Consent", type: "text", placeholder: "Y for Yes", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  "udyam": {
    title: "Udyam Details",
    description: "Get Udyam Aadhaar (MSME) details.",
    price: 10,
    fields: [
      { name: "udyamNumber", label: "Udyam Number", type: "text", placeholder: "Enter Udyam registration number", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  },
  "udyog": {
    title: "Udyog Details",
    description: "Get Udyog Aadhaar (MSME) details.",
    price: 10,
    fields: [
      { name: "udyogNumber", label: "Udyog Number", type: "text", placeholder: "Enter Udyog Aadhaar number", required: true }
    ],
    fileFormats: [".csv", ".xlsx"]
  }
}

export default function VerifyPage() {
  const { showToast } = useToast();
  const params = useParams()
  const router = useRouter()
  const type = params.type as string
  
  const [method, setMethod] = useState<VerificationMethod>("manual")
  const [formData, setFormData] = useState<Record<string, string>>({})
  const [file, setFile] = useState<File | null>(null)
  const [loading, setLoading] = useState(false)
  const [verificationResult, setVerificationResult] = useState<any>(null)
  const [error, setError] = useState<string | null>(null)
  const [walletBalance, setWalletBalance] = useState<number>(0)
  const [viewMode, setViewMode] = useState<"normal" | "json">("normal")
  const [userPrice, setUserPrice] = useState<number | null>(null)
  const [priceLoading, setPriceLoading] = useState(true)
  const [cacheHit, setCacheHit] = useState(false)
  const [walletInfo, setWalletInfo] = useState<{amountDeducted: number, newBalance: number} | null>(null)
  const [user, setUser] = useState<any>(null)
  const [showLowBalanceWarning, setShowLowBalanceWarning] = useState(false)

  const config = verificationConfigs[type]

  // Check authentication
  useEffect(() => {
    const userData = sessionStorage.getItem("user")
    if (!userData) {
      router.push("/login")
      return
    }
    
    try {
      const parsedUser = JSON.parse(userData)
      setUser(parsedUser)
    } catch (e) {
      router.push("/login")
    }
  }, [router])

  useEffect(() => {
    if (!config || !user) {
      if (!config) router.push("/")
      return
    }
    fetchWalletBalance()
    fetchUserPrice()
  }, [config, user])

  // Check for low balance and show warning
  useEffect(() => {
    const costToVerify = userPrice !== null ? userPrice : config?.price || 0
    if (walletBalance > 0 && walletBalance < costToVerify * 2) {
      setShowLowBalanceWarning(true)
    } else {
      setShowLowBalanceWarning(false)
    }
  }, [walletBalance, userPrice, config])

  const fetchUserPrice = async () => {
    setPriceLoading(true)
    try {
      const res = await fetch(`/api/pricing-plans?userId=${user.id}`, {
        cache: "no-store" // Prevent caching to always get fresh prices
      })
      const data = await res.json()
      if (data.success && data.rates) {
        // Try exact match first, then try normalized versions
        let rate = data.rates.find((r: any) => r.verification_type === type)
        
        // If not found, try common aliases
        if (!rate) {
          const aliases: Record<string, string> = {
            'aadhar': 'aadhaar',
            'aadhaar': 'aadhar'
          }
          const aliasType = aliases[type]
          if (aliasType) {
            rate = data.rates.find((r: any) => r.verification_type === aliasType)
          }
        }
        
        if (rate) {
          setUserPrice(parseFloat(rate.price))
        } else {
          // If still no rate found, set userPrice to config.price to avoid showing 0
          console.warn(`No pricing found for type: ${type}, using default from config`)
          setUserPrice(config.price)
        }
      }
    } catch (error) {
      console.error("Error fetching user price:", error)
      // Fallback to config price on error
      setUserPrice(config.price)
    } finally {
      setPriceLoading(false)
    }
  }

  const fetchWalletBalance = async () => {
    try {
      const res = await fetch(`/api/wallet/balance?userId=${user.id}`)
      const data = await res.json()
      if (data.success) {
        setWalletBalance(data.balance)
      }
    } catch (error) {
      console.error("Error fetching wallet balance:", error)
    }
  }

  const handleInputChange = (name: string, value: string) => {
    setFormData(prev => ({ ...prev, [name]: value }))
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0])
    }
  }

  const handleVerification = async () => {
    const missingFields = config.fields.filter(f => f.required && !formData[f.name])
    if (missingFields.length > 0) {
      setError(`Please fill in: ${missingFields.map(f => f.label).join(", ")}`)
      showToast(`Please fill in: ${missingFields.map(f => f.label).join(", ")}`, 'warning')
      return
    }

    // Check wallet balance before verification
    const costToVerify = userPrice !== null ? userPrice : config.price
    if (walletBalance < costToVerify) {
      setError(`Insufficient wallet balance. You need ₹${costToVerify} but have ₹${walletBalance.toFixed(2)}. Please recharge your wallet.`)
      showToast('Insufficient wallet balance. Please recharge your wallet.', 'error')
      setTimeout(() => router.push('/wallet'), 2000)
      return
    }

    setLoading(true)
    setError(null)
    setVerificationResult(null)

    try {
      // Determine the correct API endpoint based on the verification type
      let endpoint = `/api/verification/${type}`
      
      // Mobile Intelligence endpoints
      const mobileIntelligenceTypes = ['mobile-to-name', 'mobile-to-pan', 'mobile-to-dl', 'mobile-digital-age', 'mobile-network', 'mobile-to-upi', 'mobile-to-uan']
      if (mobileIntelligenceTypes.includes(type)) {
        endpoint = `/api/mobile-intelligence/${type}`
      }
      
      // EPFO endpoints
      const epfoTypes = ['aadhaar-to-uan', 'pan-to-uan', 'uan-employment']
      if (epfoTypes.includes(type)) {
        endpoint = `/api/epfo/${type}`
      }
      
      // OCR endpoints
      const ocrTypes = ['ocr-aadhaar', 'ocr-pan', 'ocr-voter-id', 'ocr-driving-license', 'ocr-bank-cheque', 'ocr-gstin']
      if (ocrTypes.includes(type)) {
        endpoint = `/api/ocr/${type}`
      }
      
      // Prepare request body
      let requestBody: Record<string, any> = { ...formData, userId: user.id }
      
      // For aadhaar-ekyc, add step parameter for OTP generation
      if (type === 'aadhaar-ekyc') {
        requestBody.step = 'generate-otp'
        requestBody.consent = 'Y'
        requestBody.purpose = 'For KYC'
      }
      
      // Direct API call to Next.js API route
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestBody)
      })
      
      const data = await response.json()
      
      if (data.success) {
        setVerificationResult(data.data)
        setCacheHit(data.cacheHit || false)
        setWalletInfo({
          amountDeducted: data.wallet?.amountDeducted || 0,
          newBalance: data.wallet?.newBalance || walletBalance
        })
        setWalletBalance(data.wallet?.newBalance || walletBalance)
        showToast("Verification completed successfully!", "success")
        
        // Auto-scroll to results
        setTimeout(() => {
          const resultElement = document.getElementById('verification-result')
          if (resultElement) {
            resultElement.scrollIntoView({ behavior: 'smooth', block: 'start' })
          }
        }, 100)
      } else {
        const errorMsg = data.error || "Verification failed. Please check your input and try again."
        setError(errorMsg)
        showToast(errorMsg, "error")
      }
    } catch (err: any) {
      const errorMessage = err.message || 'Verification failed'
      setError(errorMessage)
      showToast(errorMessage, 'error')
      
      // Check if it's an insufficient balance error
      if (err.message?.includes('Insufficient') || err.message?.includes('balance')) {
        setTimeout(() => router.push('/wallet'), 3000)
      }
    } finally {
      setLoading(false)
    }
  }

  const handleFileUpload = async () => {
    if (!file) {
      setError("Please select a file to upload")
      showToast('Please select a file to upload', 'warning')
      return
    }

    showToast('Bulk verification feature coming soon!', 'info')
  }

  const downloadSampleFile = () => {
    // Generate sample CSV based on verification type
    const headers = config.fields
      .filter(f => f.type !== 'hidden')
      .map(f => f.name)
      .join(',')
    
    // Generate sample data rows based on verification type
    let sampleRows: string[] = []
    
    switch(type) {
      case 'email':
        sampleRows = ['john.doe@example.com', 'jane.smith@company.com', 'test@email.com']
        break
      case 'phone':
        sampleRows = ['9876543210', '8765432109', '7654321098']
        break
      case 'aadhar':
      case 'aadhaar-ekyc':
        sampleRows = ['123456789012', '234567890123', '345678901234']
        break
      case 'pan':
      case 'pan-plus':
        sampleRows = ['ABCDE1234F', 'XYZAB5678C', 'PQRST9012G']
        break
      case 'driving-license':
        sampleRows = [
          'DL1234567890123,1990-01-01',
          'DL9876543210987,1985-05-15',
          'DL5555555555555,1992-12-25'
        ]
        break
      case 'gst':
      case 'gst-advanced':
      case 'gstin-by-pan':
      case 'track-gstr':
        if (type === 'track-gstr') {
          sampleRows = [
            '22AAAAA0000A1Z5,2023-24',
            '27BBBBB1111B1Z5,2023-24',
            '29CCCCC2222C1Z5,2022-23'
          ]
        } else if (type === 'gstin-by-pan') {
          sampleRows = ['ABCDE1234F', 'XYZAB5678C', 'PQRST9012G']
        } else {
          sampleRows = ['22AAAAA0000A1Z5', '27BBBBB1111B1Z5', '29CCCCC2222C1Z5']
        }
        break
      case 'bank-account':
        sampleRows = [
          '1234567890,SBIN0001234,John Doe',
          '9876543210,HDFC0002345,Jane Smith',
          '5555555555,ICIC0003456,Test User'
        ]
        break
      case 'ifsc':
        sampleRows = ['SBIN0001234', 'HDFC0002345', 'ICIC0003456']
        break
      case 'upi':
      case 'upi-advanced':
        sampleRows = ['user@paytm', 'john@oksbi', 'jane@okicici']
        break
      case 'rc':
        sampleRows = ['MH01AB1234', 'DL02CD5678', 'KA03EF9012']
        break
      case 'cin':
        sampleRows = ['U12345AB1234PLC567890', 'L23456CD2345PLC678901', 'U34567EF3456PLC789012']
        break
      case 'din':
        sampleRows = ['12345678', '23456789', '34567890']
        break
      case 'tan':
        sampleRows = ['ABCD12345E', 'WXYZ67890F', 'PQRS34567G']
        break
      case 'mobile-to-name':
      case 'mobile-to-pan':
      case 'mobile-to-dl':
      case 'mobile-digital-age':
      case 'mobile-network':
      case 'mobile-to-uan':
      case 'mobile-to-upi':
        sampleRows = ['9876543210', '8765432109', '7654321098']
        break
      case 'aadhaar-to-uan':
      case 'pan-to-uan':
        if (type === 'aadhaar-to-uan') {
          sampleRows = ['123456789012', '234567890123', '345678901234']
        } else {
          sampleRows = ['ABCDE1234F', 'XYZAB5678C', 'PQRST9012G']
        }
        break
      case 'uan-employment':
        sampleRows = ['123456789012', '234567890123', '345678901234']
        break
      case 'tds-compliance':
        sampleRows = ['ABCDE1234F', 'XYZAB5678C', 'PQRST9012G']
        break
      case 'udyam':
        sampleRows = ['UDYAM-XX-00-1234567', 'UDYAM-YY-00-2345678', 'UDYAM-ZZ-00-3456789']
        break
      case 'udyog':
        sampleRows = ['XX00X0000000', 'YY00Y1111111', 'ZZ00Z2222222']
        break
      default:
        // Generic sample for other types
        sampleRows = config.fields
          .filter(f => f.type !== 'hidden')
          .map(() => 'sample_value')
        sampleRows = [sampleRows.join(','), sampleRows.join(','), sampleRows.join(',')]
    }
    
    // Create CSV content
    const csvContent = [headers, ...sampleRows].join('\n')
    
    // Create and download file
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' })
    const link = document.createElement('a')
    const url = URL.createObjectURL(blob)
    
    link.setAttribute('href', url)
    link.setAttribute('download', `${type}_sample.csv`)
    link.style.visibility = 'hidden'
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
    
    showToast('Sample file downloaded successfully!', 'success')
  }

  if (!config) {
    return null
  }

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={() => router.push("/")}
            className="flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white mb-4"
          >
            <ArrowLeft className="w-5 h-5" />
            Back to Dashboard
          </button>
          
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-2">
                {config.title}
              </h1>
              <p className="text-gray-600 dark:text-gray-400">{config.description}</p>
            </div>
            <div className="flex gap-4">
              {/* Wallet Balance Card */}
              <div className="bg-gradient-to-br from-green-100 to-emerald-100 dark:from-green-900/30 dark:to-emerald-900/30 rounded-xl p-4 border-2 border-green-200 dark:border-green-800">
                <p className="text-xs font-semibold text-green-700 dark:text-green-400 uppercase mb-1">Wallet Balance</p>
                <p className="text-2xl font-bold text-green-900 dark:text-green-300">
                  ₹{walletBalance.toFixed(2)}
                </p>
                <a 
                  href="/wallet" 
                  className="text-xs text-green-700 dark:text-green-400 hover:underline mt-1 inline-block"
                >
                  Recharge →
                </a>
              </div>
              
              {/* Price Card */}
              <div className="bg-indigo-100 dark:bg-indigo-900/30 rounded-xl p-4">
                <p className="text-xs font-semibold text-indigo-700 dark:text-indigo-400 uppercase mb-1">Price</p>
                <p className="text-2xl font-bold text-indigo-900 dark:text-indigo-300">
                  {priceLoading ? (
                    <span className="animate-pulse">Loading...</span>
                  ) : (
                    `₹${userPrice !== null ? userPrice.toFixed(2) : config.price}`
                  )}
                </p>
                {!priceLoading && userPrice !== null && userPrice !== config.price && (
                  <p className="text-xs text-green-600 dark:text-green-400 mt-1">Custom rate</p>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Low Balance Warning */}
        {showLowBalanceWarning && (
          <div className="bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/20 dark:to-orange-900/20 border-2 border-yellow-300 dark:border-yellow-700 rounded-xl p-4 mb-6 animate-fade-in">
            <div className="flex items-center gap-3">
              <svg className="w-6 h-6 text-yellow-600 dark:text-yellow-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
              <div className="flex-1">
                <p className="font-semibold text-yellow-900 dark:text-yellow-300">Low Balance Warning</p>
                <p className="text-sm text-yellow-800 dark:text-yellow-400">Your wallet balance is running low. Consider recharging to avoid interruption.</p>
              </div>
              <a href="/wallet" className="px-4 py-2 bg-yellow-600 hover:bg-yellow-700 text-white rounded-lg text-sm font-semibold transition-colors">
                Recharge Now
              </a>
            </div>
          </div>
        )}

        {/* Method Selection */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-6 mb-6">
          <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-4">Choose Verification Method</h2>
          <div className="flex gap-3">
            <button
              onClick={() => setMethod("manual")}
              className={`flex-1 px-4 py-3 rounded-lg border-2 transition-all flex items-center justify-center gap-2 ${
                method === "manual"
                  ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600"
                  : "border-gray-200 dark:border-gray-700 hover:border-indigo-300 text-gray-700 dark:text-gray-300"
              }`}
            >
              <FileText className="w-5 h-5" />
              <span className="font-semibold">Single Verify</span>
            </button>

            <button
              onClick={() => setMethod("bulk-file")}
              className={`flex-1 px-4 py-3 rounded-lg border-2 transition-all flex items-center justify-center gap-2 ${
                method === "bulk-file"
                  ? "border-indigo-600 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-600"
                  : "border-gray-200 dark:border-gray-700 hover:border-indigo-300 text-gray-700 dark:text-gray-300"
              }`}
            >
              <Users className="w-5 h-5" />
              <span className="font-semibold">Bulk Verify</span>
            </button>
          </div>
        </div>

        {/* Manual Entry Form */}
        {method === "manual" && (
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 mb-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">Enter Details</h2>
            <div className="space-y-4">
              {config.fields.filter(field => field.required || field.type !== 'hidden').map((field) => (
                <div key={field.name}>
                  <label className="block text-sm font-semibold text-gray-700 dark:text-gray-300 mb-2">
                    {field.label} {field.required && <span className="text-red-500">*</span>}
                  </label>
                  <input
                    type={field.type === 'hidden' ? 'text' : field.type}
                    placeholder={field.placeholder}
                    value={formData[field.name] || ""}
                    onChange={(e) => handleInputChange(field.name, field.type === 'date' ? e.target.value : e.target.value.toUpperCase())}
                    className="w-full px-4 py-3 border-2 border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 dark:bg-gray-700 dark:text-white outline-none uppercase"
                  />
                </div>
              ))}
            </div>

            <Button
              onClick={handleVerification}
              disabled={loading || priceLoading}
              className="w-full mt-6 bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:opacity-90 py-4 text-lg font-semibold rounded-xl disabled:opacity-50"
            >
              {loading ? "Verifying..." : priceLoading ? "Loading price..." : `Verify Now - ₹${userPrice !== null ? userPrice.toFixed(2) : config.price}`}
            </Button>
          </div>
        )}

        {/* File Upload */}
        {method === "bulk-file" && (
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 mb-6">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-6">
              Bulk Upload
            </h2>
            
            <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-xl p-8 text-center">
              <Upload className="w-16 h-16 mx-auto mb-4 text-gray-400" />
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                Upload CSV or Excel file with multiple records
              </p>
              <p className="text-sm text-gray-500 dark:text-gray-500 mb-4">
                Supported formats: {config.fileFormats?.join(", ")}
              </p>
              <input
                type="file"
                accept={config.fileFormats?.join(",")}
                onChange={handleFileChange}
                className="hidden"
                id="file-upload"
              />
              <button
                onClick={() => document.getElementById('file-upload')?.click()}
                className="bg-indigo-600 text-white hover:bg-indigo-700 px-6 py-3 rounded-xl font-semibold transition-all cursor-pointer inline-flex items-center gap-2"
              >
                <Upload className="w-5 h-5" />
                Choose File
              </button>
              {file && (
                <p className="mt-4 text-sm text-gray-700 dark:text-gray-300">
                  Selected: {file.name}
                </p>
              )}
            </div>

            <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl">
              <p className="text-sm text-blue-900 dark:text-blue-300 mb-2">
                <strong>Sample CSV Format:</strong>
              </p>
              <p className="text-xs text-blue-700 dark:text-blue-400 mb-3">
                Download a sample file with the correct format and example data for bulk verification.
              </p>
              <Button
                onClick={downloadSampleFile}
                className="bg-blue-600 text-white hover:bg-blue-700 text-sm"
              >
                <Download className="w-4 h-4 mr-2" />
                Download Sample CSV
              </Button>
            </div>

            <Button
              onClick={handleFileUpload}
              disabled={loading || !file}
              className="w-full mt-6 bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:opacity-90 py-4 text-lg font-semibold rounded-xl disabled:opacity-50"
            >
              {loading ? "Processing..." : "Upload & Verify"}
            </Button>
          </div>
        )}

        {/* Results Section */}
        {verificationResult && (
          <div id="verification-result" className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 border border-gray-100 dark:border-gray-700">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-gray-900 dark:text-white">
                Verification Result
              </h3>
              <button
                onClick={() => setViewMode(viewMode === "normal" ? "json" : "normal")}
                className="px-4 py-2 bg-indigo-100 dark:bg-indigo-900/30 hover:bg-indigo-200 dark:hover:bg-indigo-900/50 text-indigo-700 dark:text-indigo-300 rounded-lg text-sm font-semibold transition-all"
              >
                {viewMode === "normal" ? "Show JSON View" : "Show Normal View"}
              </button>
            </div>

            {walletInfo && (
              <div className="mb-6 p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-xl">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-blue-900 dark:text-blue-300">
                    Amount Deducted: ₹{walletInfo.amountDeducted}
                  </span>
                  <span className="text-sm font-medium text-blue-900 dark:text-blue-300">
                    New Balance: ₹{walletInfo.newBalance.toFixed(2)}
                  </span>
                </div>
              </div>
            )}

            {/* Normal View */}
            {viewMode === "normal" && (
              <div className="bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-800 rounded-xl p-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {Object.entries(verificationResult)
                    .filter(([key]) => {
                      const lowerKey = key.toLowerCase();
                      return !lowerKey.includes('deepvue') && 
                             !lowerKey.includes('transaction_id') && 
                             !lowerKey.includes('transactionid');
                    })
                    .map(([key, value]) => {
                      const renderValue = () => {
                        if (value === null || value === undefined) return 'N/A'
                        if (typeof value === 'object') {
                          if (Array.isArray(value)) {
                            return value.map((item, idx) => (
                              <div key={idx} className="mt-1 pl-3 border-l-2 border-gray-300 dark:border-gray-500">
                                {typeof item === 'object' ? (
                                  Object.entries(item)
                                    .filter(([k]) => {
                                      const lowerK = k.toLowerCase();
                                      return !lowerK.includes('deepvue') && 
                                             !lowerK.includes('transaction_id') && 
                                             !lowerK.includes('transactionid');
                                    })
                                    .map(([k, v]) => (
                                      <div key={k} className="text-sm">
                                        <span className="text-gray-600 dark:text-gray-400">{k}:</span> {String(v)}
                                      </div>
                                    ))
                                ) : String(item)}
                              </div>
                            ))
                          }
                          return Object.entries(value)
                            .filter(([k]) => {
                              const lowerK = k.toLowerCase();
                              return !lowerK.includes('deepvue') && 
                                     !lowerK.includes('transaction_id') && 
                                     !lowerK.includes('transactionid');
                            })
                            .map(([k, v]) => (
                              <div key={k} className="text-sm mt-1">
                                <span className="text-gray-600 dark:text-gray-400">{k.replace(/_/g, ' ')}:</span> {String(v)}
                              </div>
                            ))
                        }
                        return String(value)
                      }
                      
                      return (
                        <div key={key} className="bg-white dark:bg-gray-600 rounded-lg p-4 shadow-sm">
                          <p className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase mb-1">
                            {key.replace(/_/g, ' ')}
                          </p>
                          <div className="text-base font-bold text-gray-900 dark:text-white break-words">
                            {renderValue()}
                          </div>
                        </div>
                      )
                    })}
                </div>
              </div>
            )}

            {/* JSON View */}
            {viewMode === "json" && (
              <div className="bg-gray-900 rounded-xl p-6 overflow-hidden">
                <pre className="text-sm text-green-400 overflow-auto max-h-96 whitespace-pre-wrap font-mono">
                  {JSON.stringify(
                    (() => {
                      const filterDeepVueFields = (obj: any): any => {
                        if (obj === null || obj === undefined) return obj;
                        if (typeof obj !== 'object') return obj;
                        
                        if (Array.isArray(obj)) {
                          return obj.map(item => filterDeepVueFields(item));
                        }
                        
                        const filtered: any = {};
                        for (const [key, value] of Object.entries(obj)) {
                          const lowerKey = key.toLowerCase();
                          if (!lowerKey.includes('deepvue') && 
                              !lowerKey.includes('transaction_id') && 
                              !lowerKey.includes('transactionid')) {
                            filtered[key] = filterDeepVueFields(value);
                          }
                        }
                        return filtered;
                      };
                      
                      return filterDeepVueFields(verificationResult);
                    })(),
                    null,
                    2
                  )}
                </pre>
              </div>
            )}

            <div className="flex gap-4 mt-6">
              <Button
                onClick={() => {
                  setVerificationResult(null)
                  setWalletInfo(null)
                  setCacheHit(false)
                  setFormData({})
                  setFile(null)
                  setError(null)
                }}
                className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 text-white hover:shadow-lg py-3 rounded-xl font-semibold"
              >
                Verify Another
              </Button>
              <Button
                onClick={() => {
                  navigator.clipboard.writeText(JSON.stringify(verificationResult, null, 2))
                }}
                className="px-6 bg-gray-600 text-white hover:bg-gray-700 py-3 rounded-xl font-semibold"
              >
                Copy JSON
              </Button>
            </div>
          </div>
        )}

        {/* Error - Inline Display */}
        {error && (
          <div className="bg-gradient-to-r from-red-50 to-pink-50 dark:from-red-900/20 dark:to-pink-900/20 border-2 border-red-200 dark:border-red-800 rounded-xl p-6 mb-6 animate-fade-in">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 rounded-xl bg-red-100 dark:bg-red-900/50 flex items-center justify-center flex-shrink-0">
                <XCircle className="w-7 h-7 text-red-600 dark:text-red-400" />
              </div>
              <div className="flex-1">
                <p className="font-bold text-lg text-red-900 dark:text-red-300 mb-2">Verification Failed</p>
                <p className="text-sm text-red-700 dark:text-red-400 leading-relaxed">{error}</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
