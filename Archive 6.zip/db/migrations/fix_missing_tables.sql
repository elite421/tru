-- Fix Missing Tables Migration
-- Run this on your Ubuntu server to create missing tables

-- 1. Transactions table (FIXED: user_id should be INTEGER, not VARCHAR)
CREATE TABLE IF NOT EXISTS transactions (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    verification_type VARCHAR(100) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    base_amount DECIMAL(10, 2),
    gst_amount DECIMAL(10, 2),
    gst_percentage DECIMAL(5, 2) DEFAULT 18.00,
    deepvue_transaction_id VARCHAR(255),
    status VARCHAR(50) DEFAULT 'success',
    cache_hit BOOLEAN DEFAULT false,
    details JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create indexes on transactions
CREATE INDEX IF NOT EXISTS idx_transactions_user 
ON transactions(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_transactions_status 
ON transactions(status, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_transactions_deepvue_id 
ON transactions(deepvue_transaction_id);

-- 2. Verification history table (FIXED: user_id should be INTEGER, not VARCHAR)
CREATE TABLE IF NOT EXISTS verification_history (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL,
    verification_type VARCHAR(100) NOT NULL,
    status VARCHAR(50) NOT NULL,
    details JSONB,
    amount_charged DECIMAL(10, 2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Create index on verification_history
CREATE INDEX IF NOT EXISTS idx_verification_history_user 
ON verification_history(user_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_verification_history_type 
ON verification_history(verification_type);

-- 3. OTP Verification tables (email and phone)
CREATE TABLE IF NOT EXISTS email_verifications (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    otp VARCHAR(6) NOT NULL,
    verified BOOLEAN DEFAULT FALSE,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    verified_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS phone_verifications (
    id SERIAL PRIMARY KEY,
    phone_number VARCHAR(15) NOT NULL,
    otp VARCHAR(6) NOT NULL,
    verified BOOLEAN DEFAULT FALSE,
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    verified_at TIMESTAMP
);

-- Create indexes for OTP tables
CREATE INDEX IF NOT EXISTS idx_email_verifications_email 
ON email_verifications(email, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_phone_verifications_phone 
ON phone_verifications(phone_number, created_at DESC);

-- Verify tables were created
SELECT 
    'transactions' as table_name, 
    EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'transactions') as exists
UNION ALL
SELECT 
    'verification_history', 
    EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'verification_history')
UNION ALL
SELECT 
    'email_verifications', 
    EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'email_verifications')
UNION ALL
SELECT 
    'phone_verifications', 
    EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'phone_verifications');
