import { NextRequest, NextResponse } from "next/server";
import { deepvueService } from "@/lib/deepvue";
import { query } from "@/db/db";
import { getUserVerificationPrice } from "@/lib/pricing";
import { calculateGST } from "@/lib/gstCalculation";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, uanNumber } = body;

    if (!userId || !uanNumber) {
      return NextResponse.json(
        { success: false, error: "User ID and UAN number are required" },
        { status: 400 }
      );
    }

    const uanRegex = /^[0-9]{12}$/;
    if (!uanRegex.test(uanNumber)) {
      return NextResponse.json(
        { success: false, error: "Invalid UAN format. Must be 12 digits" },
        { status: 400 }
      );
    }

    const deepvueResponse = await deepvueService.uanToEmploymentHistory(uanNumber);

    // Get user-specific or default pricing from database
    const basePrice = await getUserVerificationPrice(userId, "uan-employment");
    if (basePrice === null) {
      return NextResponse.json(
        { success: false, error: "Pricing not available for this verification type" },
        { status: 500 }
      );
    }

    const gstBreakdown = calculateGST(basePrice);
    const walletResult = await query(
      "SELECT * FROM wallets WHERE user_id = $1",
      [userId]
    );

    if (walletResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "Wallet not found" },
        { status: 404 }
      );
    }

    const currentBalance = parseFloat(walletResult.rows[0].balance);

    if (currentBalance < gstBreakdown.totalAmount) {
      return NextResponse.json(
        { success: false, error: `Insufficient wallet balance. Required: ₹${gstBreakdown.totalAmount} (Base: ₹${gstBreakdown.baseAmount} + GST: ₹${gstBreakdown.gstAmount})` },
        { status: 400 }
      );
    }

    const wallet = walletResult.rows[0];
    const newBalance = currentBalance - gstBreakdown.totalAmount;

    await query(
      "UPDATE wallets SET balance = $1 WHERE id = $2",
      [newBalance, wallet.id]
    );

    await query(
      `INSERT INTO wallet_transactions (wallet_id, user_id, transaction_type, amount, base_amount, gst_amount, gst_percentage, balance_before, balance_after, description, reference_type, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`,
      [wallet.id, userId, "debit", gstBreakdown.totalAmount, gstBreakdown.baseAmount, gstBreakdown.gstAmount, gstBreakdown.gstPercentage, currentBalance, newBalance, "UAN to Employment History", "verification", "completed"]
    );

    return NextResponse.json(
      {
        success: true,
        data: deepvueResponse,
        wallet: {
          baseAmount: gstBreakdown.baseAmount,
          gstAmount: gstBreakdown.gstAmount,
          gstPercentage: gstBreakdown.gstPercentage,
          totalAmount: gstBreakdown.totalAmount,
          amountDeducted: gstBreakdown.totalAmount,
          newBalance,
        },
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("UAN to Employment History error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Service failed" },
      { status: 500 }
    );
  }
}
