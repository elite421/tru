import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");

    if (!userId) {
      return NextResponse.json(
        { success: false, error: "User ID is required" },
        { status: 400 }
      );
    }

    // Get user's pricing plan
    const userResult = await query(
      `SELECT pricing_plan_id FROM users WHERE id = $1`,
      [userId]
    );

    if (userResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "User not found" },
        { status: 404 }
      );
    }

    let pricingPlanId = userResult.rows[0].pricing_plan_id;

    // If user doesn't have a custom plan, fetch the default plan from database
    if (!pricingPlanId) {
      const defaultPlanResult = await query(
        "SELECT id FROM pricing_plans WHERE is_default = true AND is_active = true LIMIT 1"
      );

      if (defaultPlanResult.rows.length > 0) {
        pricingPlanId = defaultPlanResult.rows[0].id;
      }
    }

    if (!pricingPlanId) {
      return NextResponse.json(
        { success: false, error: "No pricing plan available" },
        { status: 404 }
      );
    }

    // Get pricing plan rates from database
    const ratesResult = await query(
      `SELECT verification_type, price 
       FROM pricing_plan_rates 
       WHERE pricing_plan_id = $1`,
      [pricingPlanId]
    );

    const rates = ratesResult.rows.map((row) => ({
      verification_type: row.verification_type,
      price: parseFloat(row.price),
    }));

    return NextResponse.json(
      { success: true, rates },
      { 
        status: 200,
        headers: {
          'Cache-Control': 'no-store, no-cache, must-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0',
        }
      }
    );
  } catch (error: any) {
    console.error("Pricing plans error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to fetch pricing plans" },
      { status: 500 }
    );
  }
}
