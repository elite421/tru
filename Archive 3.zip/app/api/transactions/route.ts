import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get("userId");

    if (!userId) {
      return NextResponse.json(
        { success: false, error: "User ID is required" },
        { status: 400 }
      );
    }

    // Fetch all transactions
    const result = await query(
      `SELECT 
        id, 
        user_id, 
        verification_type, 
        amount, 
        base_amount, 
        gst_amount, 
        gst_percentage,
        deepvue_transaction_id, 
        status, 
        cache_hit, 
        details, 
        response_time,
        created_at
       FROM transactions 
       WHERE user_id = $1
       ORDER BY created_at DESC 
       LIMIT 100`,
      [userId]
    );

    return NextResponse.json(
      {
        success: true,
        transactions: result.rows,
      },
      { status: 200 }
    );
  } catch (error: any) {
    console.error("Transactions fetch error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Failed to fetch transactions" },
      { status: 500 }
    );
  }
}
