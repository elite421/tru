import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";

// GET: Fetch pricing for the authenticated user
export async function GET(request: NextRequest) {
  try {
    // Get user ID from session/auth
    const userId = request.headers.get("x-user-id");
    
    if (!userId) {
      return NextResponse.json(
        { success: false, error: "User not authenticated" },
        { status: 401 }
      );
    }

    // Get user's pricing plan
    const userResult = await query(
      "SELECT pricing_plan_id, plan_expires_at FROM users WHERE id = $1",
      [userId]
    );

    if (userResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "User not found" },
        { status: 404 }
      );
    }

    const user = userResult.rows[0];
    let pricingPlanId = user.pricing_plan_id;

    // Check if plan is expired
    if (pricingPlanId && user.plan_expires_at) {
      const expiryDate = new Date(user.plan_expires_at);
      if (expiryDate < new Date()) {
        // Plan expired, use default pricing
        pricingPlanId = null;
      }
    }

    let prices: Record<string, number> = {};

    if (pricingPlanId) {
      // User has a custom pricing plan
      const ratesResult = await query(
        "SELECT verification_type, price FROM pricing_plan_rates WHERE pricing_plan_id = $1",
        [pricingPlanId]
      );

      ratesResult.rows.forEach((row) => {
        prices[row.verification_type] = parseFloat(row.price);
      });
    }

    // If no custom plan or missing rates, fetch default pricing
    if (Object.keys(prices).length === 0) {
      const defaultPlanResult = await query(
        "SELECT id FROM pricing_plans WHERE is_default = true AND is_active = true LIMIT 1"
      );

      if (defaultPlanResult.rows.length > 0) {
        const defaultPlanId = defaultPlanResult.rows[0].id;
        const defaultRatesResult = await query(
          "SELECT verification_type, price FROM pricing_plan_rates WHERE pricing_plan_id = $1",
          [defaultPlanId]
        );

        defaultRatesResult.rows.forEach((row) => {
          prices[row.verification_type] = parseFloat(row.price);
        });
      }
    }

    return NextResponse.json({
      success: true,
      prices,
      planId: pricingPlanId,
      hasCustomPlan: !!pricingPlanId
    }, {
      headers: {
        'Cache-Control': 'no-store, no-cache, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0',
      }
    });
  } catch (error: any) {
    console.error("Error fetching user pricing:", error);
    return NextResponse.json(
      { success: false, error: error.message },
      { status: 500 }
    );
  }
}
