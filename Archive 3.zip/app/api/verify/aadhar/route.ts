import { NextRequest, NextResponse } from "next/server";
import { deepvueService } from "@/lib/deepvue";
import { query } from "@/db/db";
import { getUserVerificationPrice } from "@/lib/pricing";
import { calculateGST } from "@/lib/gstCalculation";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { userId, aadhar, action, otp, referenceId } = body;

    if (!userId || !aadhar) {
      return NextResponse.json(
        { success: false, error: "User ID and Aadhar number are required" },
        { status: 400 }
      );
    }

    // Validate Aadhar format (12 digits)
    const aadharRegex = /^[0-9]{12}$/;
    if (!aadharRegex.test(aadhar.replace(/\s/g, ''))) {
      return NextResponse.json(
        { success: false, error: "Invalid Aadhar format. Must be 12 digits" },
        { status: 400 }
      );
    }

    // Step 1: Generate OTP
    if (!action || action === "generate_otp") {
      const otpResponse = await deepvueService.generateAadhaarOTP(aadhar);

      return NextResponse.json(
        {
          success: true,
          action: "otp_generated",
          referenceId: otpResponse.reference_id || otpResponse.data?.reference_id,
          message: "OTP sent to registered mobile number",
        },
        { status: 200 }
      );
    }

    // Step 2: Verify OTP
    if (action === "verify_otp") {
      if (!otp || !referenceId) {
        return NextResponse.json(
          { success: false, error: "OTP and reference ID are required" },
          { status: 400 }
        );
      }

      // Check cache first
      const cacheKey = aadhar.replace(/\s/g, '');
      const cacheResult = await query(
        "SELECT verification_data FROM verification_cache WHERE verification_type = $1 AND verification_key = $2",
        ["aadhar", cacheKey]
      );

      let deepvueResponse;
      let cacheHit = false;
      
      if (cacheResult.rows.length > 0) {
        deepvueResponse = cacheResult.rows[0].verification_data;
        cacheHit = true;
        await query(
          "UPDATE verification_cache SET access_count = access_count + 1, last_accessed_at = CURRENT_TIMESTAMP WHERE verification_type = $1 AND verification_key = $2",
          ["aadhar", cacheKey]
        );
      } else {
        // Verify OTP with DeepVue
        deepvueResponse = await deepvueService.verifyAadhaarOTP(otp, referenceId);
        
        // Store in cache
        await query(
          "INSERT INTO verification_cache (verification_type, verification_key, verification_data) VALUES ($1, $2, $3) ON CONFLICT (verification_type, verification_key) DO UPDATE SET verification_data = $3, last_accessed_at = CURRENT_TIMESTAMP",
          ["aadhar", cacheKey, JSON.stringify(deepvueResponse)]
        );
      }

      // Get user-specific or default pricing from database
      const basePrice = await getUserVerificationPrice(userId, "aadhar");
      if (basePrice === null) {
        return NextResponse.json(
          { success: false, error: "Pricing not available for this verification type" },
          { status: 500 }
        );
      }

      const gstBreakdown = calculateGST(basePrice);
      const walletResult = await query(
        "SELECT * FROM wallets WHERE user_id = $1",
        [userId]
      );

      if (walletResult.rows.length === 0) {
        return NextResponse.json(
          { success: false, error: "Wallet not found" },
          { status: 404 }
        );
      }

      const currentBalance = parseFloat(walletResult.rows[0].balance);

      if (currentBalance < gstBreakdown.totalAmount) {
        return NextResponse.json(
          { success: false, error: `Insufficient wallet balance. Required: ₹${gstBreakdown.totalAmount} (Base: ₹${gstBreakdown.baseAmount} + GST: ₹${gstBreakdown.gstAmount})` },
          { status: 400 }
        );
      }

      const wallet = walletResult.rows[0];
      const newBalance = currentBalance - gstBreakdown.totalAmount;

      // Deduct amount from wallet
      await query(
        "UPDATE wallets SET balance = $1 WHERE id = $2",
        [newBalance, wallet.id]
      );

      // Save wallet transaction
      await query(
        `INSERT INTO wallet_transactions (wallet_id, user_id, transaction_type, amount, base_amount, gst_amount, gst_percentage, balance_before, balance_after, description, reference_type, status) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`,
        [wallet.id, userId, "debit", gstBreakdown.totalAmount, gstBreakdown.baseAmount, gstBreakdown.gstAmount, gstBreakdown.gstPercentage, currentBalance, newBalance, `Aadhar verification${cacheHit ? ' (cached)' : ''}`, "verification", "completed"]
      );

      // Save transaction
      await query(
        `INSERT INTO transactions 
         (user_id, verification_type, amount, status, cache_hit, details) 
         VALUES ($1, $2, $3, $4, $5, $6)`,
        [userId, "aadhar", gstBreakdown.totalAmount, "success", cacheHit, JSON.stringify(deepvueResponse)]
      );

      return NextResponse.json(
        {
          success: true,
          data: deepvueResponse,
          cacheHit,
          wallet: {
            baseAmount: gstBreakdown.baseAmount,
            gstAmount: gstBreakdown.gstAmount,
            gstPercentage: gstBreakdown.gstPercentage,
            totalAmount: gstBreakdown.totalAmount,
            amountDeducted: gstBreakdown.totalAmount,
            newBalance,
          },
        },
        { status: 200 }
      );
    }

    return NextResponse.json(
      { success: false, error: "Invalid action. Use 'generate_otp' or 'verify_otp'" },
      { status: 400 }
    );
  } catch (error: any) {
    console.error("Aadhar verification error:", error);
    return NextResponse.json(
      { success: false, error: error.message || "Verification failed" },
      { status: 500 }
    );
  }
}
