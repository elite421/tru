import { NextRequest, NextResponse } from "next/server";
import { query } from "@/db/db";
import bcrypt from "bcryptjs";
import crypto from "crypto";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { token, email, newPassword } = body;

    if (!token || !email || !newPassword) {
      return NextResponse.json(
        { success: false, error: "Missing required fields" },
        { status: 400 }
      );
    }

    // Validate password
    if (newPassword.length < 6) {
      return NextResponse.json(
        { success: false, error: "Password must be at least 6 characters" },
        { status: 400 }
      );
    }

    // Hash the provided token to compare with stored hash
    const tokenHash = crypto.createHash("sha256").update(token).digest("hex");

    // Find user and verify token
    const resetResult = await query(
      `SELECT prt.user_id, prt.expires_at, u.email
       FROM password_reset_tokens prt
       JOIN users u ON prt.user_id = u.id
       WHERE prt.token_hash = $1 AND u.email = $2`,
      [tokenHash, email.toLowerCase()]
    );

    if (resetResult.rows.length === 0) {
      return NextResponse.json(
        { success: false, error: "Invalid or expired reset token" },
        { status: 400 }
      );
    }

    const resetRecord = resetResult.rows[0];

    // Check if token has expired
    if (new Date(resetRecord.expires_at) < new Date()) {
      // Delete expired token
      await query(
        "DELETE FROM password_reset_tokens WHERE user_id = $1",
        [resetRecord.user_id]
      );
      
      return NextResponse.json(
        { success: false, error: "Reset token has expired. Please request a new one." },
        { status: 400 }
      );
    }

    // Hash the new password
    const hashedPassword = await bcrypt.hash(newPassword, 10);

    // Update user password
    await query(
      "UPDATE users SET password = $1 WHERE id = $2",
      [hashedPassword, resetRecord.user_id]
    );

    // Delete the used reset token
    await query(
      "DELETE FROM password_reset_tokens WHERE user_id = $1",
      [resetRecord.user_id]
    );

    // Log in development only
    if (process.env.NODE_ENV === "development") {
      console.log(`Password reset successful for user: ${resetRecord.email}`);
    }

    return NextResponse.json({
      success: true,
      message: "Password reset successful"
    });

  } catch (error: any) {
    console.error("Reset password error:", error);
    return NextResponse.json(
      { success: false, error: "Failed to reset password" },
      { status: 500 }
    );
  }
}
