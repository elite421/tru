"use client"

import { useState } from "react"
import { ChevronDown, ChevronUp, Search, HelpCircle, Book, Zap, CreditCard, Shield, Code, Mail, MessageCircle } from "lucide-react"
import { useRouter } from "next/navigation"

export default function HelpCenterPage() {
  const router = useRouter()
  const [searchQuery, setSearchQuery] = useState("")
  const [openFaq, setOpenFaq] = useState<number | null>(0)

  const categories = [
    {
      icon: <Zap className="w-6 h-6" />,
      title: "Getting Started",
      color: "from-yellow-400 to-orange-500",
      faqs: [
        {
          question: "How do I get started with TruVerify?",
          answer: "Getting started is easy! Sign up for an account, generate your API key from the dashboard, and start making verification requests. Check our documentation for detailed integration guides and code examples in multiple programming languages."
        },
        {
          question: "Do I need technical knowledge to use TruVerify?",
          answer: "TruVerify offers both web-based interface and API integration. Non-technical users can use our dashboard to perform verifications manually. For API integration, basic programming knowledge is helpful, but our comprehensive documentation makes it accessible for developers of all skill levels."
        }
      ]
    },
    {
      icon: <Code className="w-6 h-6" />,
      title: "API & Integration",
      color: "from-blue-400 to-indigo-600",
      faqs: [
        {
          question: "Which programming languages are supported?",
          answer: "TruVerify APIs are RESTful and can be integrated with any programming language that supports HTTP requests. We provide code examples in JavaScript/Node.js, Python, PHP, Java, Ruby, and cURL."
        },
        {
          question: "What is the API response time?",
          answer: "Most verifications complete in under 2 seconds. Response times may vary slightly based on network conditions and the type of verification being performed."
        }
      ]
    },
    {
      icon: <CreditCard className="w-6 h-6" />,
      title: "Pricing & Billing",
      color: "from-green-400 to-emerald-600",
      faqs: [
        {
          question: "How does pay-as-you-go pricing work?",
          answer: "You only pay for successful verifications. No subscriptions, no monthly fees. Each verification type has a fixed per-API price displayed on our pricing page."
        },
        {
          question: "What payment methods do you accept?",
          answer: "We accept all major credit and debit cards (Visa, Mastercard, American Express), UPI, net banking, and bank transfers for enterprise customers."
        }
      ]
    },
    {
      icon: <Shield className="w-6 h-6" />,
      title: "Security & Privacy",
      color: "from-red-400 to-rose-600",
      faqs: [
        {
          question: "How secure is my data?",
          answer: "We employ bank-grade security with 256-bit SSL/TLS encryption for all data transmissions. Data at rest is encrypted using AES-256. Our infrastructure is ISO 27001 certified."
        },
        {
          question: "Is TruVerify GDPR compliant?",
          answer: "Yes, we are fully compliant with GDPR and Indian data protection regulations. We implement data minimization, purpose limitation, and provide users with rights to access, correct, and delete their data."
        }
      ]
    }
  ]

  const filteredCategories = categories.map(category => ({
    ...category,
    faqs: category.faqs.filter(faq =>
      faq.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
      faq.answer.toLowerCase().includes(searchQuery.toLowerCase())
    )
  })).filter(category => category.faqs.length > 0)

  const toggleFaq = (index: number) => {
    setOpenFaq(openFaq === index ? null : index)
  }

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-12 text-center animate-fade-in">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
            Help Center
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto mb-8">
            Find answers to frequently asked questions and learn how to make the most of TruVerify
          </p>

          {/* Search Bar */}
          <div className="max-w-2xl mx-auto relative animate-slide-in-down">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <input
              type="text"
              placeholder="Search for help..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-4 text-lg border-2 border-gray-300 dark:border-gray-600 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-800 dark:text-white outline-none"
            />
          </div>
        </div>

        {/* FAQ Categories */}
        {filteredCategories.length > 0 ? (
          <div className="space-y-8">
            {filteredCategories.map((category, categoryIndex) => (
              <div key={categoryIndex} className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8 hover-lift animate-scale-in">
                <div className="flex items-center gap-4 mb-6">
                  <div className={`bg-gradient-to-br ${category.color} rounded-xl p-3 text-white`}>
                    {category.icon}
                  </div>
                  <h2 className="text-3xl font-bold text-gray-900 dark:text-white">
                    {category.title}
                  </h2>
                </div>

                <div className="space-y-4">
                  {category.faqs.map((faq, faqIndex) => {
                    const globalIndex = categoryIndex * 100 + faqIndex
                    const isOpen = openFaq === globalIndex
                    
                    return (
                      <div
                        key={faqIndex}
                        className="border-2 border-gray-200 dark:border-gray-700 rounded-xl overflow-hidden transition-all duration-300 hover:border-blue-400 dark:hover:border-blue-600"
                      >
                        <button
                          onClick={() => toggleFaq(globalIndex)}
                          className="w-full flex items-center justify-between p-6 text-left bg-gray-50 dark:bg-gray-700/50 hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
                        >
                          <span className="font-semibold text-lg text-gray-900 dark:text-white pr-4">
                            {faq.question}
                          </span>
                          {isOpen ? (
                            <ChevronUp className="flex-shrink-0 text-blue-600 dark:text-blue-400" size={24} />
                          ) : (
                            <ChevronDown className="flex-shrink-0 text-gray-400" size={24} />
                          )}
                        </button>
                        
                        {isOpen && (
                          <div className="p-6 bg-white dark:bg-gray-800 border-t-2 border-gray-200 dark:border-gray-700 animate-slide-in-down">
                            <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                              {faq.answer}
                            </p>
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-12 text-center">
            <HelpCircle className="w-16 h-16 mx-auto mb-4 text-gray-400" />
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
              No results found
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              Try adjusting your search terms or browse all categories above
            </p>
          </div>
        )}

        {/* Support Tickets Section */}
        <div className="mt-12 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl shadow-2xl p-8 text-white animate-glow">
          <div className="text-center">
            <MessageCircle className="w-12 h-12 mx-auto mb-4" />
            <h2 className="text-3xl font-bold mb-4">Need More Help?</h2>
            <p className="text-xl text-white/90 mb-6 max-w-2xl mx-auto">
              Submit a support ticket or chat with our team for personalized assistance
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button
                onClick={() => router.push("/help-support")}
                className="bg-white text-blue-600 px-8 py-4 rounded-xl font-bold text-lg hover:bg-gray-100 transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105"
              >
                Submit Ticket
              </button>
              <button
                onClick={() => router.push("/contact")}
                className="bg-white/10 backdrop-blur-sm text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-white/20 transition-all duration-300 border-2 border-white/30"
              >
                Contact Support
              </button>
            </div>
            <div className="mt-8 space-y-2 text-white/90">
              <p>📧 Email: support@truverify.com</p>
              <p>📞 Phone: +91 8279439828 | +91 9756862551</p>
              <p>⏰ Available: Monday - Friday, 9:00 AM - 6:00 PM IST</p>
            </div>
          </div>
        </div>

        {/* Quick Links */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          <a
            href="/docs"
            className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 group hover:scale-105"
          >
            <Book className="w-10 h-10 text-blue-600 dark:text-blue-400 mb-3 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
              API Documentation
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              Comprehensive guides and code examples
            </p>
          </a>

          <a
            href="/features"
            className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 group hover:scale-105"
          >
            <Zap className="w-10 h-10 text-purple-600 dark:text-purple-400 mb-3 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
              Features
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              Explore all verification capabilities
            </p>
          </a>

          <a
            href="/pricing"
            className="bg-white dark:bg-gray-800 rounded-xl shadow-lg p-6 hover:shadow-xl transition-all duration-300 group hover:scale-105"
          >
            <CreditCard className="w-10 h-10 text-green-600 dark:text-green-400 mb-3 group-hover:scale-110 transition-transform" />
            <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-2">
              Pricing
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              Simple, transparent pricing plans
            </p>
          </a>
        </div>
      </div>
    </div>
  )
}
