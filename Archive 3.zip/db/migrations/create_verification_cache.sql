-- Migration: Create verification_cache table
-- This table stores cached verification results to avoid repeated API calls

-- Create verification_cache table if it doesn't exist
CREATE TABLE IF NOT EXISTS verification_cache (
    id SERIAL PRIMARY KEY,
    verification_type VARCHAR(100) NOT NULL,
    verification_key VARCHAR(500) NOT NULL,
    verification_data JSONB NOT NULL,
    first_verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_accessed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    access_count INTEGER DEFAULT 1,
    UNIQUE(verification_type, verification_key)
);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_verification_cache_lookup 
ON verification_cache(verification_type, verification_key);

-- Create index for type-based queries
CREATE INDEX IF NOT EXISTS idx_verification_cache_type 
ON verification_cache(verification_type);

-- Create index for cleanup/maintenance queries
CREATE INDEX IF NOT EXISTS idx_verification_cache_accessed 
ON verification_cache(last_accessed_at);

-- Add comment to table
COMMENT ON TABLE verification_cache IS 'Stores cached verification results to reduce API calls and costs';
COMMENT ON COLUMN verification_cache.verification_type IS 'Type of verification: pan, aadhar, rc, gst, etc.';
COMMENT ON COLUMN verification_cache.verification_key IS 'Unique identifier for the verification (e.g., PAN number, RC number)';
COMMENT ON COLUMN verification_cache.verification_data IS 'Complete verification response data in JSON format';
COMMENT ON COLUMN verification_cache.access_count IS 'Number of times this cached data has been accessed';
