-- Seed Default Pricing Plan
-- This script creates a default pricing plan with all verification types

-- Create default pricing plan if it doesn't exist
INSERT INTO pricing_plans (name, description, is_default, is_active)
VALUES ('Default Pricing', 'Standard pricing for all users without a custom plan', true, true)
ON CONFLICT (name) DO NOTHING;

-- Get the default plan ID
DO $$
DECLARE
    default_plan_id INTEGER;
BEGIN
    SELECT id INTO default_plan_id FROM pricing_plans WHERE is_default = true LIMIT 1;

    -- Insert all default rates
    -- Identity Documents - KYC
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'pan', 5) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'pan-plus', 7) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'aadhaar-ekyc', 8) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'driving-license', 8) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'rc', 7) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    
    -- Financial
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'bank-account', 6) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'ifsc', 2) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'upi', 4) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'upi-advanced', 6) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'credit-report', 50) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    
    -- Business & Tax - GST
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'gst', 7) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'gst-advanced', 10) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'gstin-by-pan', 6) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'track-gstr', 8) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    
    -- Business & Tax - MCA
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'cin', 8) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'din', 8) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    
    -- Business & Tax - TaxPayer
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'tan', 5) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'tds-compliance', 7) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    
    -- Business & Tax - MSME
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'udyam', 10) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'udyog', 10) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    
    -- EPFO Services
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'aadhaar-to-uan', 7) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'pan-to-uan', 7) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'uan-employment', 9) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    
    -- Mobile Intelligence
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'mobile-to-name', 6) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'mobile-to-pan', 8) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'mobile-to-dl', 8) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'mobile-to-uan', 7) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'mobile-digital-age', 6) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'mobile-network', 4) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'mobile-to-upi', 6) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    
    -- Document OCR
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'ocr-aadhaar', 10) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'ocr-pan', 8) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'ocr-dl', 10) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'ocr-voter-id', 10) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'ocr-cheque', 8) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'ocr-gstin', 10) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    
    -- Advanced Services - Biometric
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'face-match', 15) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'face-liveness', 12) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    
    -- Additional common verification types
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'email', 2) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'phone', 3) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'mobile-number', 3) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'email-validation', 2) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;
    INSERT INTO pricing_plan_rates (pricing_plan_id, verification_type, price) VALUES (default_plan_id, 'mobile-intelligence', 8) ON CONFLICT (pricing_plan_id, verification_type) DO NOTHING;

END $$;
