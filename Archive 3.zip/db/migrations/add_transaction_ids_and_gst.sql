-- Migration: Add DeepVue transaction ID, GST, and base amount columns

-- Add columns to transactions table
ALTER TABLE transactions ADD COLUMN IF NOT EXISTS deepvue_transaction_id VARCHAR(255);
ALTER TABLE transactions ADD COLUMN IF NOT EXISTS base_amount DECIMAL(10, 2);
ALTER TABLE transactions ADD COLUMN IF NOT EXISTS gst_amount DECIMAL(10, 2);
ALTER TABLE transactions ADD COLUMN IF NOT EXISTS gst_percentage DECIMAL(5, 2) DEFAULT 18.00;

-- Add columns to wallet_transactions table  
ALTER TABLE wallet_transactions ADD COLUMN IF NOT EXISTS deepvue_transaction_id VARCHAR(255);
ALTER TABLE wallet_transactions ADD COLUMN IF NOT EXISTS base_amount DECIMAL(10, 2);
ALTER TABLE wallet_transactions ADD COLUMN IF NOT EXISTS gst_amount DECIMAL(10, 2);
ALTER TABLE wallet_transactions ADD COLUMN IF NOT EXISTS gst_percentage DECIMAL(5, 2) DEFAULT 18.00;

-- Add columns to verification_cache table for tracking transaction ID
ALTER TABLE verification_cache ADD COLUMN IF NOT EXISTS deepvue_transaction_id VARCHAR(255);

-- Create index for faster DeepVue transaction ID lookups
CREATE INDEX IF NOT EXISTS idx_transactions_deepvue_id ON transactions(deepvue_transaction_id);
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_deepvue_id ON wallet_transactions(deepvue_transaction_id);

-- Add comment for clarity
COMMENT ON COLUMN transactions.deepvue_transaction_id IS 'Transaction ID from DeepVue API response';
COMMENT ON COLUMN transactions.base_amount IS 'Base amount before GST';
COMMENT ON COLUMN transactions.gst_amount IS 'GST amount (18% of base amount)';
COMMENT ON COLUMN transactions.gst_percentage IS 'GST percentage applied';
